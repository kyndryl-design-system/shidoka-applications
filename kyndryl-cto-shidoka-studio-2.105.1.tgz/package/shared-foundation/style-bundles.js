import { existsSync, readFileSync } from 'fs';

const STYLE_BUNDLE_JSON_URLS = [
  new URL('./style-bundles.json', import.meta.url),
  new URL('../content/shared-foundation/style-bundles.json', import.meta.url),
];

const resolvedStyleBundleUrl = STYLE_BUNDLE_JSON_URLS.find((url) => existsSync(url));

if (!resolvedStyleBundleUrl) {
  throw new Error('Unable to resolve style-bundles.json for shared-foundation runtime.');
}

const styleBundlesContract = JSON.parse(
  readFileSync(resolvedStyleBundleUrl, 'utf8')
);

export const STUDIO_STYLE_PACKAGE_ROOT = styleBundlesContract.packageRoot;

export const STUDIO_STYLE_BUNDLES = styleBundlesContract.bundleOrder.map((bundleId) => {
  const bundle = styleBundlesContract.bundles[bundleId];
  return {
    id: bundle.bundleId,
    outputName: bundle.outputName,
    packageImport: bundle.packageImport,
    description: bundle.description,
    provenance: bundle.provenance,
    provides: bundle.provides,
    requires: bundle.requires,
    conflictsWith: bundle.conflictsWith,
    targetRefs: bundle.targetRefs,
    tokens: bundle.tokens,
  };
});

export const STUDIO_STYLE_BUNDLE_IMPORTS = Object.freeze(
  Object.fromEntries(
    STUDIO_STYLE_BUNDLES.map((bundle) => [bundle.id, bundle.packageImport])
  )
);

export const STUDIO_STYLE_SURFACE_SELECTIONS = styleBundlesContract.surfaceSelections;

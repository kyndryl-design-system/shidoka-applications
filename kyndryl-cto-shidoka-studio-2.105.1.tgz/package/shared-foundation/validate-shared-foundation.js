import {
  EXPECTED_SCHEMA_IDS,
  REQUIRED_PATTERN_CONTRACT_IDS,
  REQUIRED_STYLE_LAYERS,
} from './constants.js';
import { sharedFoundationSchema } from './schema.js';

function pushIssue(issues, message) {
  issues.push(message);
}

export function validateSharedFoundation(
  foundation,
  { requireComponentRules = true } = {}
) {
  const issues = [];

  const schemaValidation = sharedFoundationSchema.safeParse(foundation);
  if (!schemaValidation.success) {
    for (const issue of schemaValidation.error.issues) {
      pushIssue(
        issues,
        `Schema validation failed at ${issue.path.join('.') || '<root>'}: ${issue.message}`
      );
    }
    return issues;
  }

  for (const [key, schemaId] of Object.entries(EXPECTED_SCHEMA_IDS)) {
    if (key === 'componentRules' && !requireComponentRules) {
      continue;
    }

    if (!foundation[key]) {
      pushIssue(issues, `Missing schema payload: ${key}`);
      continue;
    }

    if (foundation[key].schemaId !== schemaId) {
      pushIssue(
        issues,
        `Unexpected schemaId for ${key}: expected ${schemaId}, received ${foundation[key].schemaId}`
      );
    }
  }

  const orchestrationPolicy = foundation.orchestrationPolicy;
  const taskPolicies = orchestrationPolicy?.taskPolicies || {};
  const requiredOrchestrationPolicies = [
    {
      key: 'full-page-or-shell',
      laneId: 'canonical-full-page-seven-tool-lane',
      requiredTools: [
        'get_shidoka_design_context',
        'get_canonical_full_page_template',
        'get_canonical_full_page_recipe',
        'get_shidoka_full_page_snippets',
        'get_canonical_header_nav_template',
        'get_canonical_header_nav_recipe',
        'get_shidoka_header_nav_snippets',
      ],
      requiredAdapterFacts: [
        'framework',
        'router shape',
        'output file destination',
        'app entry',
        'global CSS location',
      ],
    },
    {
      key: 'header-nav-only',
      laneId: 'canonical-header-nav-trio',
      requiredTools: [
        'get_canonical_header_nav_template',
        'get_canonical_header_nav_recipe',
        'get_shidoka_header_nav_snippets',
      ],
      requiredAdapterFacts: [
        'framework',
        'output file destination',
        'app entry',
        'global CSS location',
      ],
    },
  ];

  if (orchestrationPolicy?.authorityBoundary?.adapterRole !== 'thinHostAdapter') {
    pushIssue(
      issues,
      `Orchestration policy adapterRole must be thinHostAdapter, received ${orchestrationPolicy?.authorityBoundary?.adapterRole}`
    );
  }

  for (const requiredPolicy of requiredOrchestrationPolicies) {
    const policy = taskPolicies[requiredPolicy.key];
    if (!policy) {
      pushIssue(
        issues,
        `Missing required orchestration task policy: ${requiredPolicy.key}`
      );
      continue;
    }

    const toolSelection = policy.toolSelection || {};
    const requiredTools = requiredPolicy.requiredTools;
    const requiredToolSet = new Set(requiredTools);
    const actualRequiredTools = toolSelection.requiredTools || [];
    const actualCallOrder = toolSelection.callOrder || [];
    const actualAdapterFacts = new Set(
      policy.repoInspection?.minimumAdapterFacts || []
    );

    if (toolSelection.laneId !== requiredPolicy.laneId) {
      pushIssue(
        issues,
        `Orchestration policy ${requiredPolicy.key} must use lane ${requiredPolicy.laneId}, received ${toolSelection.laneId}`
      );
    }

    if (
      toolSelection.minimumCallableToolCount !== requiredTools.length ||
      actualRequiredTools.length !== requiredTools.length ||
      actualCallOrder.length !== requiredTools.length
    ) {
      pushIssue(
        issues,
        `Orchestration policy ${requiredPolicy.key} must require exactly ${requiredTools.length} tools`
      );
    }

    if (JSON.stringify(actualRequiredTools) !== JSON.stringify(requiredTools)) {
      pushIssue(
        issues,
        `Orchestration policy ${requiredPolicy.key} requiredTools must stay aligned with the canonical lane`
      );
    }

    if (JSON.stringify(actualCallOrder) !== JSON.stringify(requiredTools)) {
      pushIssue(
        issues,
        `Orchestration policy ${requiredPolicy.key} callOrder must stay aligned with the canonical lane`
      );
    }

    if (toolSelection.failClosedWhenUnavailable !== true) {
      pushIssue(
        issues,
        `Orchestration policy ${requiredPolicy.key} must fail closed when required tools are unavailable`
      );
    }

    if (toolSelection.fallbackBehavior !== 'abort-with-remediation') {
      pushIssue(
        issues,
        `Orchestration policy ${requiredPolicy.key} fallbackBehavior must be abort-with-remediation`
      );
    }

    if (
      !actualRequiredTools.every((toolName) => requiredToolSet.has(toolName))
    ) {
      pushIssue(
        issues,
        `Orchestration policy ${requiredPolicy.key} references unexpected tools in requiredTools`
      );
    }

    for (const fact of requiredPolicy.requiredAdapterFacts) {
      if (!actualAdapterFacts.has(fact)) {
        pushIssue(
          issues,
          `Orchestration policy ${requiredPolicy.key} minimumAdapterFacts must include: ${fact}`
        );
      }
    }

    if (policy.repoInspection?.inspectOnlyAfterCanonicalPayloads !== true) {
      pushIssue(
        issues,
        `Orchestration policy ${requiredPolicy.key} must inspect the repo only after canonical payloads`
      );
    }

    if (policy.repoInspection?.forbidLocalDesignAuthorityForNewPage !== true) {
      pushIssue(
        issues,
        `Orchestration policy ${requiredPolicy.key} must forbid local design authority for new-page composition`
      );
    }

    if (
      policy.execution?.executeWithoutConsentGateWhenRequirementsAreSufficient !==
      true
    ) {
      pushIssue(
        issues,
        `Orchestration policy ${requiredPolicy.key} must execute without consent gating when requirements are sufficient`
      );
    }

    if (policy.execution?.forbidFallbackPolicyQuestions !== true) {
      pushIssue(
        issues,
        `Orchestration policy ${requiredPolicy.key} must forbid fallback policy questions`
      );
    }
  }

  const keepInAdapterClusters = new Set(
    orchestrationPolicy?.cursorRuleClassification?.keepInAdapter?.map(
      (entry) => entry.clusterId
    ) || []
  );
  const portableClusters = new Set(
    orchestrationPolicy?.cursorRuleClassification?.moveToPortablePolicy?.map(
      (entry) => entry.clusterId
    ) || []
  );

  if (!keepInAdapterClusters.has('frontmatterAndGlobTargeting')) {
    pushIssue(
      issues,
      'Orchestration policy must classify frontmatterAndGlobTargeting as adapter-local'
    );
  }

  if (!portableClusters.has('failClosedToolAvailability')) {
    pushIssue(
      issues,
      'Orchestration policy must classify failClosedToolAvailability as portable policy'
    );
  }

  const contracts = foundation.patternContracts?.contracts || {};
  for (const contractId of REQUIRED_PATTERN_CONTRACT_IDS) {
    if (!contracts[contractId]) {
      pushIssue(issues, `Missing required pattern contract: ${contractId}`);
    }
  }

  const headerNavCategoryHeading = contracts['header-nav']?.behavior?.globalSwitcherCategoryHeading;
  if (!headerNavCategoryHeading) {
    pushIssue(
      issues,
      'Pattern contract header-nav is missing behavior.globalSwitcherCategoryHeading'
    );
  } else {
    const requiredHeadedSectionIds = ['console', 'services', 'administration'];
    const requiredLayoutModes = ['grouped-column', 'masonry', 'tabbed-masonry'];
    const appliesToSectionIds = new Set(headerNavCategoryHeading.appliesToSectionIds || []);
    const appliesToLayoutModes = new Set(headerNavCategoryHeading.appliesToLayoutModes || []);

    if (headerNavCategoryHeading.attribute !== 'heading') {
      pushIssue(
        issues,
        `Pattern contract header-nav category headings must use attribute "heading", received ${headerNavCategoryHeading.attribute}`
      );
    }

    if (headerNavCategoryHeading.forbidSlot !== 'heading') {
      pushIssue(
        issues,
        `Pattern contract header-nav category headings must forbid slot "heading", received ${headerNavCategoryHeading.forbidSlot}`
      );
    }

    if (headerNavCategoryHeading.requiredIconSlot !== 'icon') {
      pushIssue(
        issues,
        `Pattern contract header-nav category headings must use icon slot "icon", received ${headerNavCategoryHeading.requiredIconSlot}`
      );
    }

    if (headerNavCategoryHeading.placeholderIcon !== 'circle-stroke') {
      pushIssue(
        issues,
        `Pattern contract header-nav category headings must use placeholder icon "circle-stroke", received ${headerNavCategoryHeading.placeholderIcon}`
      );
    }

    if (headerNavCategoryHeading.preserveVisibleHeadingText !== true) {
      pushIssue(
        issues,
        'Pattern contract header-nav category headings must preserve visible heading text'
      );
    }

    for (const sectionId of requiredHeadedSectionIds) {
      if (!appliesToSectionIds.has(sectionId)) {
        pushIssue(
          issues,
          `Pattern contract header-nav category headings must apply to section: ${sectionId}`
        );
      }
    }

    for (const layoutMode of requiredLayoutModes) {
      if (!appliesToLayoutModes.has(layoutMode)) {
        pushIssue(
          issues,
          `Pattern contract header-nav category headings must apply to layout mode: ${layoutMode}`
        );
      }
    }
  }

  const styleLayers = foundation.stylePolicy?.layers || {};
  const stylePolicies = foundation.stylePolicy?.targetPolicies || [];
  const styleBundles = foundation.styleBundles?.bundles || {};
  const styleBundleIds = new Set(Object.keys(styleBundles));
  for (const layerId of REQUIRED_STYLE_LAYERS) {
    if (!styleLayers[layerId]) {
      pushIssue(issues, `Missing required style layer: ${layerId}`);
    }
  }

  const componentMap = foundation.componentRules?.components || {};
  const stylePolicyByKey = new Map();
  for (const policy of stylePolicies) {
    const key = `${policy.targetType}:${policy.targetId}`;
    if (stylePolicyByKey.has(key)) {
      pushIssue(issues, `Duplicate style policy target: ${key}`);
      continue;
    }
    stylePolicyByKey.set(key, policy);
  }

  for (const bundleId of foundation.styleBundles?.bundleOrder || []) {
    if (!styleBundles[bundleId]) {
      pushIssue(issues, `Style bundle order references unknown bundle: ${bundleId}`);
    }
  }

  for (const [bundleId, bundle] of Object.entries(styleBundles)) {
    if (bundle.bundleId !== bundleId) {
      pushIssue(
        issues,
        `Style bundle key ${bundleId} must match bundleId ${bundle.bundleId}`
      );
    }

    if (
      !bundle.packageImport.startsWith(`${foundation.styleBundles.packageRoot}/`)
    ) {
      pushIssue(
        issues,
        `Style bundle ${bundleId} import must start with ${foundation.styleBundles.packageRoot}`
      );
    }

    if (!bundle.packageImport.endsWith(`/${bundle.outputName}`)) {
      pushIssue(
        issues,
        `Style bundle ${bundleId} import must end with /${bundle.outputName}`
      );
    }

    for (const dependencyId of bundle.requires || []) {
      if (!styleBundleIds.has(dependencyId)) {
        pushIssue(
          issues,
          `Style bundle ${bundleId} requires missing bundle: ${dependencyId}`
        );
      }
    }

    for (const conflictId of bundle.conflictsWith || []) {
      if (!styleBundleIds.has(conflictId)) {
        pushIssue(
          issues,
          `Style bundle ${bundleId} conflicts with missing bundle: ${conflictId}`
        );
      }
    }

    for (const targetRef of bundle.targetRefs || []) {
      if (!stylePolicyByKey.has(targetRef)) {
        pushIssue(
          issues,
          `Style bundle ${bundleId} references missing style target: ${targetRef}`
        );
      }
    }

    for (const targetRef of bundle.provenance?.styleTargetRefs || []) {
      if (!stylePolicyByKey.has(targetRef)) {
        pushIssue(
          issues,
          `Style bundle ${bundleId} provenance references missing style target: ${targetRef}`
        );
      }
    }

    for (const contractRef of bundle.provenance?.patternContractRefs || []) {
      if (!contracts[contractRef]) {
        pushIssue(
          issues,
          `Style bundle ${bundleId} provenance references missing pattern contract: ${contractRef}`
        );
      }
    }

    if (requireComponentRules) {
      for (const componentRef of bundle.provenance?.componentRefs || []) {
        if (!componentMap[componentRef]) {
          pushIssue(
            issues,
            `Style bundle ${bundleId} provenance references missing component rule: ${componentRef}`
          );
        }
      }
    }
  }

  for (const [surfaceId, surfaceSelection] of Object.entries(
    foundation.styleBundles?.surfaceSelections || {}
  )) {
    if (surfaceSelection.surfaceId !== surfaceId) {
      pushIssue(
        issues,
        `Style bundle surface key ${surfaceId} must match surfaceId ${surfaceSelection.surfaceId}`
      );
    }

    for (const bundleId of surfaceSelection.requiredBundleIds || []) {
      if (!styleBundleIds.has(bundleId)) {
        pushIssue(
          issues,
          `Style bundle surface ${surfaceId} references missing required bundle: ${bundleId}`
        );
      }
    }

    for (const bundleId of surfaceSelection.optionalBundleIds || []) {
      if (!styleBundleIds.has(bundleId)) {
        pushIssue(
          issues,
          `Style bundle surface ${surfaceId} references missing optional bundle: ${bundleId}`
        );
      }
    }

    for (const conditional of surfaceSelection.conditionalBundleIds || []) {
      if (!styleBundleIds.has(conditional.bundleId)) {
        pushIssue(
          issues,
          `Style bundle surface ${surfaceId} references missing conditional bundle: ${conditional.bundleId}`
        );
      }
    }

    for (const contractRef of surfaceSelection.provenance?.patternContractRefs || []) {
      if (!contracts[contractRef]) {
        pushIssue(
          issues,
          `Style bundle surface ${surfaceId} provenance references missing pattern contract: ${contractRef}`
        );
      }
    }

    for (const pageSpecRef of surfaceSelection.provenance?.pageSpecRefs || []) {
      if (pageSpecRef !== foundation.pageSpec?.initialDocument?.specId) {
        pushIssue(
          issues,
          `Style bundle surface ${surfaceId} provenance references unknown page spec: ${pageSpecRef}`
        );
      }
    }
  }

  function requireStyleTarget(targetType, targetId, reason) {
    const key = `${targetType}:${targetId}`;
    if (!stylePolicyByKey.has(key)) {
      pushIssue(issues, `${reason} is missing a style policy target: ${key}`);
    }
  }

  if (requireComponentRules) {
    for (const [contractId, contract] of Object.entries(contracts)) {
      for (const componentRef of contract.sources?.cemComponentRefs || []) {
        if (!componentMap[componentRef]) {
          pushIssue(
            issues,
            `Pattern contract ${contractId} references missing component rule: ${componentRef}`
          );
        }
      }
    }
  }

  for (const [contractId, contract] of Object.entries(contracts)) {
    requireStyleTarget(
      'patternContract',
      contractId,
      `Pattern contract ${contractId}`
    );

    if (requireComponentRules) {
      for (const componentRef of contract.sources?.cemComponentRefs || []) {
        requireStyleTarget(
          'component',
          componentRef,
          `Pattern contract ${contractId} component ${componentRef}`
        );
      }
    }
  }

  const pageContract = foundation.pageSpec?.contract;
  const initialDocument = foundation.pageSpec?.initialDocument;

  if (!pageContract) {
    pushIssue(issues, 'Missing pageSpec contract');
  }

  if (!initialDocument) {
    pushIssue(issues, 'Missing pageSpec initialDocument');
  } else {
    for (const contractRef of [
      initialDocument.frame?.shellContractRef,
      initialDocument.frame?.headerContractRef,
    ].filter(Boolean)) {
      if (!contracts[contractRef]) {
        pushIssue(
          issues,
          `Page spec initialDocument references missing frame contract: ${contractRef}`
        );
      }
    }

    if (
      requireComponentRules &&
      initialDocument.frame?.footerComponentRef &&
      !componentMap[initialDocument.frame.footerComponentRef]
    ) {
      pushIssue(
        issues,
        `Page spec initialDocument references missing footer component rule: ${initialDocument.frame.footerComponentRef}`
      );
    }

    for (const region of initialDocument.regions || []) {
      requireStyleTarget(
        'region',
        region.regionId,
        `Page spec region ${region.regionId}`
      );

      if (
        requireComponentRules &&
        region.source?.sourceType === 'component' &&
        !componentMap[region.source.ref]
      ) {
        pushIssue(
          issues,
          `Page spec region ${region.regionId} references missing component rule: ${region.source.ref}`
        );
      }

      if (
        ['patternContract', 'bodyModesContract'].includes(region.source?.sourceType) &&
        !contracts[region.source.ref]
      ) {
        pushIssue(
          issues,
          `Page spec region ${region.regionId} references missing contract: ${region.source.ref}`
        );
      }
    }

    if (initialDocument.styling?.stylePolicyRef !== 'stylePolicy') {
      pushIssue(
        issues,
        `Page spec initialDocument should reference stylePolicy, received ${initialDocument.styling?.stylePolicyRef}`
      );
    }

    if (initialDocument.styling?.styleBundlesRef !== 'styleBundles') {
      pushIssue(
        issues,
        `Page spec initialDocument should reference styleBundles, received ${initialDocument.styling?.styleBundlesRef}`
      );
    }

    if (
      initialDocument.styling?.surfaceId &&
      !foundation.styleBundles?.surfaceSelections?.[initialDocument.styling.surfaceId]
    ) {
      pushIssue(
        issues,
        `Page spec initialDocument references unknown style-bundle surface: ${initialDocument.styling?.surfaceId}`
      );
    }

    if (initialDocument.audit?.auditRulesRef !== 'auditRules') {
      pushIssue(
        issues,
        `Page spec initialDocument should reference auditRules, received ${initialDocument.audit?.auditRulesRef}`
      );
    }

    const allowedBodyModeIds = new Set(pageContract?.enums?.bodyModeIds || []);
    if (
      initialDocument.semantics?.bodyModeId &&
      !allowedBodyModeIds.has(initialDocument.semantics.bodyModeId)
    ) {
      pushIssue(
        issues,
        `Page spec initialDocument uses unknown body mode: ${initialDocument.semantics.bodyModeId}`
      );
    }

    for (const targetRef of initialDocument.styling?.targetRefs || []) {
      if (!stylePolicyByKey.has(targetRef)) {
        pushIssue(
          issues,
          `Page spec initialDocument references missing style target: ${targetRef}`
        );
      }
    }
  }

  requireStyleTarget('appGlue', 'shell-global', 'Shared foundation');

  const auditRuleSets = foundation.auditRules?.ruleSets || [];
  const knownSchemaIds = new Set(Object.values(EXPECTED_SCHEMA_IDS));
  for (const ruleSet of auditRuleSets) {
    for (const rule of ruleSet.rules || []) {
      for (const schemaRef of rule.schemaRefs || []) {
        if (!knownSchemaIds.has(schemaRef)) {
          pushIssue(
            issues,
            `Audit rule ${rule.ruleId} references unknown schema: ${schemaRef}`
          );
        }
      }
    }
  }

  return issues;
}

export function assertValidSharedFoundation(foundation, options) {
  const issues = validateSharedFoundation(foundation, options);

  if (issues.length > 0) {
    throw new Error(`Invalid shared foundation:\n- ${issues.join('\n- ')}`);
  }

  return foundation;
}

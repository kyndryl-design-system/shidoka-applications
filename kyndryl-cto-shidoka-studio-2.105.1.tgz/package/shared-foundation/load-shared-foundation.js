import { existsSync, readFileSync } from 'fs';
import { join } from 'path';
import {
  SHARED_FOUNDATION_AUTHORED_DIR,
  SHARED_FOUNDATION_SCHEMA_FILES,
} from './constants.js';

function readJson(path) {
  return JSON.parse(readFileSync(path, 'utf8'));
}

function resolveExistingPath(root, candidates) {
  return candidates.map((parts) => join(root, ...parts)).find((path) => existsSync(path));
}

function resolveSchemaPath(root, schemaKey, { preferAuthored = false } = {}) {
  const fileName = SHARED_FOUNDATION_SCHEMA_FILES[schemaKey];
  const candidates = preferAuthored
    ? [
        [...SHARED_FOUNDATION_AUTHORED_DIR, fileName],
        ['context', fileName],
        ['context-src', fileName],
      ]
    : [
        ['context', fileName],
        ['context-src', fileName],
        [...SHARED_FOUNDATION_AUTHORED_DIR, fileName],
      ];
  const resolvedPath = resolveExistingPath(root, candidates);

  if (!resolvedPath) {
    throw new Error(`Shared foundation schema not found: ${fileName}`);
  }

  return resolvedPath;
}

export function loadSharedFoundation(
  root,
  { includeComponentRules = true, preferAuthored = false } = {}
) {
  const schemaKeys = [
    ...(includeComponentRules ? ['componentRules'] : []),
    'orchestrationPolicy',
    'patternContracts',
    'stylePolicy',
    'styleBundles',
    'pageSpec',
    'auditRules',
  ];
  const paths = Object.fromEntries(
    schemaKeys.map((schemaKey) => [
      schemaKey,
      resolveSchemaPath(root, schemaKey, { preferAuthored }),
    ])
  );

  return {
    paths,
    ...(paths.componentRules
      ? { componentRules: readJson(paths.componentRules) }
      : {}),
    orchestrationPolicy: readJson(paths.orchestrationPolicy),
    patternContracts: readJson(paths.patternContracts),
    stylePolicy: readJson(paths.stylePolicy),
    styleBundles: readJson(paths.styleBundles),
    pageSpec: readJson(paths.pageSpec),
    auditRules: readJson(paths.auditRules),
  };
}

export const SHARED_FOUNDATION_SCHEMA_FILES = {
  componentRules: 'component-rules.json',
  orchestrationPolicy: 'orchestration-policy.json',
  patternContracts: 'pattern-contracts.json',
  stylePolicy: 'style-policy.json',
  styleBundles: 'style-bundles.json',
  pageSpec: 'page-spec.json',
  auditRules: 'audit-rules.json',
};

export const SHARED_FOUNDATION_AUTHORED_DIR = ['src', 'content', 'shared-foundation'];

export const EXPECTED_SCHEMA_IDS = {
  componentRules: 'componentRules',
  orchestrationPolicy: 'orchestrationPolicy',
  patternContracts: 'patternContracts',
  stylePolicy: 'stylePolicy',
  styleBundles: 'styleBundles',
  pageSpec: 'pageSpec',
  auditRules: 'auditRules',
};

export const REQUIRED_PATTERN_CONTRACT_IDS = [
  'shell',
  'header-nav',
  'workspace-switcher',
  'dashboard-body-modes',
  'ai-input-query',
];

export const REQUIRED_STYLE_LAYERS = [
  'component',
  'patternLayout',
  'appGlueGlobal',
];

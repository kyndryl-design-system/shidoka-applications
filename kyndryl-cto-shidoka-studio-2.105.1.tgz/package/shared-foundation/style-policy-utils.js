function unique(values) {
  return [...new Set(values.filter(Boolean))];
}

function formatList(values) {
  if (!values || values.length === 0) return 'none';
  return values.map((value) => `\`${value}\``).join(', ');
}

export function getStylePolicyTarget(stylePolicy, targetType, targetId) {
  return (stylePolicy?.targetPolicies || []).find(
    (policy) =>
      policy.targetType === targetType
      && policy.targetId === targetId
  ) || null;
}

export function getDocumentedComponentStyling(componentRule, targetPolicy) {
  const apiCssProperties = (componentRule?.api?.cssProperties || []).map(
    (entry) => entry.name
  );
  const apiCssParts = (componentRule?.api?.cssParts || []).map(
    (entry) => entry.name
  );

  return {
    cssProperties: unique([
      ...apiCssProperties,
      ...(targetPolicy?.allowedCssProperties || []),
    ]),
    cssParts: unique([
      ...apiCssParts,
      ...(targetPolicy?.allowedCssParts || []),
    ]),
  };
}

function buildComponentPolicySummary(foundation, componentId) {
  const componentRule = foundation?.componentRules?.components?.[componentId];
  const targetPolicy = getStylePolicyTarget(
    foundation?.stylePolicy,
    'component',
    componentId
  );
  const documentedStyling = getDocumentedComponentStyling(
    componentRule,
    targetPolicy
  );

  if (!componentRule || !targetPolicy) {
    return null;
  }

  return {
    componentId,
    ownerLayer: componentRule?.supplemental?.styling?.ownerLayer || null,
    stylingMode: targetPolicy.stylingMode,
    allowedScopes: targetPolicy.allowedScopes || [],
    forbiddenSelectorCategories: targetPolicy.forbiddenSelectorCategories || [],
    cssProperties: documentedStyling.cssProperties,
    cssParts: documentedStyling.cssParts,
  };
}

function buildPatternPolicySummary(foundation, contractId) {
  const contract = foundation?.patternContracts?.contracts?.[contractId];
  const targetPolicy = getStylePolicyTarget(
    foundation?.stylePolicy,
    'patternContract',
    contractId
  );

  if (!contract || !targetPolicy) {
    return null;
  }

  return {
    contractId,
    stylingMode: targetPolicy.stylingMode,
    allowedScopes: targetPolicy.allowedScopes || [],
    allowedCssProperties: targetPolicy.allowedCssProperties || [],
    forbiddenSelectorCategories: targetPolicy.forbiddenSelectorCategories || [],
    relatedComponents: contract.sources?.cemComponentRefs || [],
  };
}

export function buildStylePolicyRecipeSummary(foundation, surface) {
  const stylePolicy = foundation?.stylePolicy;
  if (!stylePolicy) return undefined;

  const componentTargetsBySurface = {
    'header-nav': [
      'kyn-header',
      'kyn-header-nav',
      'kyn-header-flyouts',
      'kyn-header-flyout',
      'kyn-workspace-switcher',
    ],
    'full-page': [
      'kyn-ui-shell',
      'kyn-header',
      'kyn-header-nav',
      'kyn-header-flyouts',
      'kyn-header-flyout',
      'kyn-workspace-switcher',
      'kyn-local-nav',
      'kyn-footer',
      'kyn-widget-gridstack',
      'kyn-widget',
    ],
  };
  const patternTargetsBySurface = {
    'header-nav': ['header-nav', 'workspace-switcher'],
    'full-page': ['shell', 'header-nav', 'workspace-switcher', 'dashboard-body-modes'],
  };

  return {
    projectionType: 'derived',
    authorityRefs: {
      stylePolicy: 'style-policy.json',
      componentRules: 'component-rules.json',
      patternContracts: 'pattern-contracts.json',
    },
    resolutionOrder: stylePolicy.resolutionOrder || [],
    generationIntent: stylePolicy.generationIntent?.primary || [],
    componentTargets: (componentTargetsBySurface[surface] || [])
      .map((componentId) => buildComponentPolicySummary(foundation, componentId))
      .filter(Boolean),
    patternTargets: (patternTargetsBySurface[surface] || [])
      .map((contractId) => buildPatternPolicySummary(foundation, contractId))
      .filter(Boolean),
    regionTargets: (stylePolicy.targetPolicies || []).filter(
      (policy) =>
        policy.targetType === 'region'
        && (surface === 'full-page' || policy.targetId === 'main')
    ),
    appGlueTargets: (stylePolicy.targetPolicies || []).filter(
      (policy) => policy.targetType === 'appGlue'
    ),
  };
}

export function buildStylePolicyMarkdownLines(foundation, surface) {
  const summary = buildStylePolicyRecipeSummary(foundation, surface);
  if (!summary) return [];

  const componentLines = summary.componentTargets.map((target) => {
    const partsText = target.cssParts.length
      ? formatList(target.cssParts)
      : 'no documented `cssParts` contract';
    const cssPropsText = target.cssProperties.length
      ? formatList(target.cssProperties)
      : 'component defaults only';
    return `- \`${target.componentId}\` stays ${target.stylingMode}. Prefer component defaults, tokens, and documented host hooks first. Allowed host hooks: ${cssPropsText}; ${partsText}. Forbidden selector categories: ${formatList(target.forbiddenSelectorCategories)}.`;
  });
  const patternLines = summary.patternTargets.map((target) =>
    `- Pattern/layout CSS for \`${target.contractId}\` belongs in wrapper/helper classes and shared pattern assets. Use it for layout, spacing, and positioning only. Allowed scopes: ${formatList(target.allowedScopes)}. Common allowed properties: ${formatList(target.allowedCssProperties)}.`
  );
  const appGlueLines = summary.appGlueTargets.map((target) =>
    `- App glue target \`${target.targetId}\` belongs in one app-level global stylesheet. Use it for shell clearance, overlay stacking, and cross-pattern coordination. Allowed scopes: ${formatList(target.allowedScopes)}.`
  );

  return [
    '## Styling policy',
    '',
    '- Derived summary only: the authority remains the packaged `context/style-policy.json`, `context/component-rules.json`, and `context/pattern-contracts.json` contracts (authored from `src/content/shared-foundation/` and related source inputs).',
    `- Resolve styling ownership in this order: ${formatList(summary.resolutionOrder)}.`,
    ...(summary.generationIntent || []).map((line) => `- ${line}`),
    '- Do not write custom CSS for Shidoka component internals by default. Avoid descendant/internal selectors, undocumented `::part(...)` hooks, and page-local visual reskins of `kyn-*` hosts.',
    ...componentLines,
    ...patternLines,
    ...appGlueLines,
  ];
}

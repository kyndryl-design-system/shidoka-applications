function getPageSpecRegion(pageSpec, regionId) {
  return (pageSpec?.regions || []).find((region) => region.regionId === regionId);
}

function getInitialDocumentRegion(initialDocument, regionId) {
  return (initialDocument?.regions || []).find((region) => region.regionId === regionId);
}

function getStyleBundleSelection(foundation, surfaceId) {
  if (!surfaceId) return null;
  return foundation?.styleBundles?.surfaceSelections?.[surfaceId] || null;
}

function buildResolvedStyleBundleProjection(foundation, surfaceSelection) {
  if (!surfaceSelection) return null;
  const bundles = foundation?.styleBundles?.bundles || {};
  return {
    surfaceId: surfaceSelection.surfaceId,
    description: surfaceSelection.description,
    requiredBundles: (surfaceSelection.requiredBundleIds || [])
      .map((bundleId) => bundles[bundleId])
      .filter(Boolean),
    optionalBundles: (surfaceSelection.optionalBundleIds || [])
      .map((bundleId) => bundles[bundleId])
      .filter(Boolean),
    conditionalBundles: (surfaceSelection.conditionalBundleIds || [])
      .map((selection) => ({
        ...selection,
        bundle: bundles[selection.bundleId] || null,
      }))
      .filter((selection) => selection.bundle),
  };
}

function resolveStarterProfiles(archetype) {
  const starterProfiles = archetype?.starterProfiles || {};
  const defaultStarterProfileId =
    archetype?.defaultStarterProfileId ||
    Object.keys(starterProfiles)[0] ||
    null;

  return {
    defaultStarterProfileId,
    selectedStarterProfileId: defaultStarterProfileId,
    selectedStarterProfile: defaultStarterProfileId
      ? starterProfiles[defaultStarterProfileId] || null
      : null,
    supportedStarterProfiles: Object.values(starterProfiles),
    selectionRules: archetype?.starterProfileSelectionRules || [],
  };
}

export function deriveSharedPagePlanning(archetype, foundation) {
  const contracts = foundation?.patternContracts?.contracts || {};
  const starterProfiles = resolveStarterProfiles(archetype);
  const legacyPageSpec =
    foundation?.pageSpec?.pageSpecs?.[archetype.sharedPageSpecId || 'shidokaAppPage'];

  if (legacyPageSpec) {
    const shellRegion = getPageSpecRegion(legacyPageSpec, 'shell');
    const headerRegion = getPageSpecRegion(legacyPageSpec, 'header');
    const mainRegion = getPageSpecRegion(legacyPageSpec, 'main');
    const footerRegion = getPageSpecRegion(legacyPageSpec, 'footer');
    const bodyModesContract = mainRegion?.bodyModesContractRef
      ? contracts[mainRegion.bodyModesContractRef]
      : null;
    const selectedVariantId =
      archetype.pageSpecVariantId || legacyPageSpec.defaults?.variantId || 'dashboard';
    const selectedVariant = legacyPageSpec.variants?.[selectedVariantId] || {};
    const selectedBodyModeId =
      selectedVariant.bodyModeId ||
      legacyPageSpec.defaults?.bodyModeId ||
      bodyModesContract?.defaultModeId ||
      null;
    const supportedBodyModes = Object.values(bodyModesContract?.modes || {});

    return {
      pageSpecId: legacyPageSpec.pageSpecId,
      description: legacyPageSpec.description,
      intendedUse: legacyPageSpec.intendedUse,
      patternContractRefs: legacyPageSpec.patternContractRefs || [],
      defaults: legacyPageSpec.defaults || {},
      planning: {
        ...(legacyPageSpec.planning || {}),
        starterProfileSelectionRules: starterProfiles.selectionRules,
      },
      selectedVariantId,
      selectedVariant,
      shell: {
        contractId: shellRegion?.patternContractRef || null,
        contract: shellRegion?.patternContractRef
          ? contracts[shellRegion.patternContractRef]
          : null,
      },
      header: {
        contractId: headerRegion?.patternContractRef || null,
        contract: headerRegion?.patternContractRef
          ? contracts[headerRegion.patternContractRef]
          : null,
      },
      main: {
        bodyModesContractId: mainRegion?.bodyModesContractRef || null,
        bodyModesContract,
        selectedBodyModeId,
        selectedBodyMode: bodyModesContract?.modes?.[selectedBodyModeId] || null,
        supportedBodyModes,
        defaultStarterProfileId: starterProfiles.defaultStarterProfileId,
        selectedStarterProfileId: starterProfiles.selectedStarterProfileId,
        selectedStarterProfile: starterProfiles.selectedStarterProfile,
        supportedStarterProfiles: starterProfiles.supportedStarterProfiles,
      },
      footer: {
        componentRef: footerRegion?.componentRef || null,
      },
      stylePolicy: {
        ref: legacyPageSpec.stylePolicyRef,
        resolutionOrder: foundation?.stylePolicy?.resolutionOrder || [],
      },
      styleBundles: null,
    };
  }

  const contract = foundation?.pageSpec?.contract;
  const initialDocument = foundation?.pageSpec?.initialDocument;
  if (!contract || !initialDocument) return null;

  const mainRegion = getInitialDocumentRegion(initialDocument, 'main');
  const bodyModesContract = mainRegion?.source?.ref
    ? contracts[mainRegion.source.ref]
    : null;
  const selectedBodyModeId =
    archetype.pageSpecBodyModeId ||
    initialDocument.semantics?.bodyModeId ||
    bodyModesContract?.defaultModeId ||
    null;
  const supportedBodyModes = Object.values(bodyModesContract?.modes || {});
  const workspaceContractRef =
    contracts['header-nav']?.behavior?.composeWorkspaceFlyoutFromPatternContract || null;
  const styleBundleSelection = getStyleBundleSelection(
    foundation,
    initialDocument.styling?.surfaceId
  );
  const patternContractRefs = [
    initialDocument.frame?.shellContractRef,
    initialDocument.frame?.headerContractRef,
    workspaceContractRef,
    mainRegion?.source?.ref,
  ].filter(Boolean);

  return {
    pageSpecId: initialDocument.specId,
    description: contract.description || foundation?.pageSpec?.description,
    intendedUse: contract.intendedUse,
    patternContractRefs,
    defaults: {
      headLine: archetype.defaults?.headLine,
      pageTitle: archetype.defaults?.pageTitle,
      subTitle: archetype.defaults?.subTitle,
      bodyModeId: selectedBodyModeId,
      starterProfileId: starterProfiles.selectedStarterProfileId,
    },
    planning: {
      pageSpecDriven: true,
      shellAndBodyDecoupled: true,
      recipeOwnsPlanning: true,
      compatibilityNotes: initialDocument.compatibilityNotes || [],
      todo: initialDocument.todo || [],
      starterProfileSelectionRules: starterProfiles.selectionRules,
    },
    selectedVariantId: archetype.pageSpecVariantId || 'default',
    selectedVariant: {},
    shell: {
      contractId: initialDocument.frame?.shellContractRef || null,
      contract: initialDocument.frame?.shellContractRef
        ? contracts[initialDocument.frame.shellContractRef]
        : null,
    },
    header: {
      contractId: initialDocument.frame?.headerContractRef || null,
      contract: initialDocument.frame?.headerContractRef
        ? contracts[initialDocument.frame.headerContractRef]
        : null,
    },
    main: {
      bodyModesContractId: mainRegion?.source?.ref || null,
      bodyModesContract,
      selectedBodyModeId,
      selectedBodyMode: bodyModesContract?.modes?.[selectedBodyModeId] || null,
      supportedBodyModes,
      defaultStarterProfileId: starterProfiles.defaultStarterProfileId,
      selectedStarterProfileId: starterProfiles.selectedStarterProfileId,
      selectedStarterProfile: starterProfiles.selectedStarterProfile,
      supportedStarterProfiles: starterProfiles.supportedStarterProfiles,
    },
    footer: {
      componentRef: initialDocument.frame?.footerComponentRef || null,
    },
    stylePolicy: {
      ref: initialDocument.styling?.stylePolicyRef,
      resolutionOrder: foundation?.stylePolicy?.resolutionOrder || [],
    },
    styleBundles: {
      ref: initialDocument.styling?.styleBundlesRef || null,
      packageRoot: foundation?.styleBundles?.packageRoot || null,
      selection: buildResolvedStyleBundleProjection(foundation, styleBundleSelection),
    },
  };
}

export function buildPlanningInvariants(archetype, sharedPagePlanning) {
  const workspaceFlyout = archetype.header.flyouts?.[0];
  const workspacePattern = archetype.header.patterns?.workspaceSwitcher;
  const selectedBodyMode = sharedPagePlanning?.main.selectedBodyMode;
  const contentGrid = archetype.layout?.contentGrid;

  return {
    shell: {
      mainAndFooterRemainDirectShellChildren: true,
      mainPaddingStyle: archetype.layout.mainPaddingStyle,
      stackStyle: archetype.layout.stackStyle,
      localNavShellClassesApplyWhen:
        sharedPagePlanning?.shell.contract?.behavior?.localNavShellClassesApplyWhen
        || 'localNavPresentAndPinned',
      localNavPinnedShellClasses:
        sharedPagePlanning?.shell.contract?.behavior?.localNavShellClasses || [],
      snippetBackedDetails: [
        'global CSS stacking coordination',
        'local-nav/footer clearance classing edge cases',
      ],
    },
    workspaceSwitcher: {
      requiredCurrentBlock: Boolean(
        sharedPagePlanning?.header.contract?.behavior?.composeWorkspaceFlyoutFromPatternContract
      ),
      requiredInitialPopulation: {
        leftList: workspaceFlyout?.panelContract?.requirePopulatedLeftListOnFirstRender || false,
        rightList:
          workspaceFlyout?.panelContract?.requirePopulatedRightListOnFirstRender || false,
      },
      copyFeedbackRequired:
        workspaceFlyout?.panelContract?.requireCopyableAccountIdFeedback || false,
      defaultPatternRef: workspaceFlyout?.panelContract?.defaultPatternRef || null,
      currentBlockContract: workspacePattern?.current || null,
    },
    flyouts: {
      requiredFlyoutIds:
        sharedPagePlanning?.header.contract?.structure?.requiredFlyoutIds || [],
      hideMenuLabelByDefault:
        false,
      hideMenuLabelFlyoutIds:
        sharedPagePlanning?.header.contract?.behavior?.hideMenuLabelFlyoutIds || [],
      panelDefaults: {
        notifications:
          sharedPagePlanning?.header.contract?.behavior?.notificationsPanelStyle || null,
        help: sharedPagePlanning?.header.contract?.behavior?.helpPanelStyle || null,
        userCenteredProfileBlock:
          sharedPagePlanning?.header.contract?.behavior
            ?.userPanelRequiresCenteredProfileBlock || false,
      },
    },
    body: {
      selectedBodyModeId: sharedPagePlanning?.main.selectedBodyModeId || null,
      selectedStarterProfileId:
        sharedPagePlanning?.main.selectedStarterProfileId || null,
      selectedStarterProfile:
        sharedPagePlanning?.main.selectedStarterProfile || null,
      gridstack:
        contentGrid && selectedBodyMode?.modeId === 'canonicalWidgetGrid'
          ? {
              requiresDeclarativeConfig:
                selectedBodyMode.invariants?.requiresDeclarativeGridstackConfig || false,
              omitExplicitCoordinatesByDefault:
                selectedBodyMode.invariants?.omitExplicitCoordinatesByDefault || false,
              config: contentGrid.gridstackConfig,
              itemWidth: contentGrid.itemWidth,
              itemHeight: contentGrid.itemHeight,
              itemContentClassName: contentGrid.itemContentClassName,
            }
          : null,
      editorialLayout:
        selectedBodyMode?.modeId === 'editorialLayout'
          ? selectedBodyMode.invariants
          : null,
    },
  };
}

export function buildSnippetBackedInvariantList() {
  return [
    'Exact workspace-switcher CURRENT block class hierarchy and framework wiring helpers still require snippets.',
    'Global CSS imports, overlay stacking coordination, and shell glue remain snippet-backed.',
    'Framework-specific binding and custom-event details remain outside core planning and stay in snippets/template prose for now.',
  ];
}

export function buildRecipePageSpecProjection(archetype, foundation) {
  const sharedPagePlanning = deriveSharedPagePlanning(archetype, foundation);
  if (!sharedPagePlanning) return undefined;

  return {
    pageSpecId: sharedPagePlanning.pageSpecId,
    description: sharedPagePlanning.description,
    selectedVariantId: sharedPagePlanning.selectedVariantId,
    selectionSource: {
      archetypeId: archetype.id,
      primaryContentPattern: archetype.primaryContentPattern,
      derivedFromStructuredInputs: [
        'archetype',
        'patternContracts',
        'pageSpec',
        'stylePolicy',
        'styleBundles',
      ],
    },
    defaults: sharedPagePlanning.defaults,
    patternContractRefs: sharedPagePlanning.patternContractRefs,
    shellBodySeparation: {
      shellContractId: sharedPagePlanning.shell.contractId,
      bodyModesContractId: sharedPagePlanning.main.bodyModesContractId,
    },
    shell: {
      contractId: sharedPagePlanning.shell.contractId,
      headerContractId: sharedPagePlanning.header.contractId,
      footerComponentRef: sharedPagePlanning.footer.componentRef,
    },
    main: {
      bodyModesContractId: sharedPagePlanning.main.bodyModesContractId,
      selectedBodyModeId: sharedPagePlanning.main.selectedBodyModeId,
      supportedBodyModes: sharedPagePlanning.main.supportedBodyModes.map((mode) => ({
        modeId: mode.modeId,
        description: mode.description,
        intendedFor: mode.intendedFor,
        implementationStatus: mode.implementationStatus || 'implemented',
        componentRefs: [
          ...(mode.componentRefs || []),
          ...(mode.cemComponentRefs || []),
          ...(mode.nonCemRuntimeRefs || []),
        ],
        patternAssetRefs: mode.patternAssetRefs,
        invariants: mode.invariants || mode.behavior,
      })),
      defaultStarterProfileId: sharedPagePlanning.main.defaultStarterProfileId,
      selectedStarterProfileId: sharedPagePlanning.main.selectedStarterProfileId,
      selectedStarterProfile: sharedPagePlanning.main.selectedStarterProfile,
      supportedStarterProfiles: sharedPagePlanning.main.supportedStarterProfiles,
    },
    stylePolicy: sharedPagePlanning.stylePolicy,
    styleBundles: sharedPagePlanning.styleBundles,
    planning: sharedPagePlanning.planning,
    invariants: buildPlanningInvariants(archetype, sharedPagePlanning),
    snippetBackedInvariants: buildSnippetBackedInvariantList(),
  };
}

import * as z from 'zod/v4';

const sourceRefsSchema = z.object({
  cemComponentRefs: z.array(z.string()).default([]),
  nonCemRuntimeRefs: z.array(z.string()).optional(),
  authoredRefs: z.array(z.string()).default([]),
  generatedRefs: z.array(z.string()).default([]),
});

const intendedUseSchema = z.object({
  generation: z.boolean(),
  auditing: z.boolean(),
});

const patternContractSchema = z.object({
  contractId: z.string(),
  description: z.string(),
  sources: sourceRefsSchema,
  intendedUse: intendedUseSchema,
  structure: z.record(z.string(), z.unknown()).optional(),
  behavior: z.record(z.string(), z.unknown()).optional(),
  supplementalAssets: z.record(z.string(), z.unknown()).optional(),
  allowedModeIds: z.array(z.string()).optional(),
  defaultModeId: z.string().optional(),
  modes: z
    .record(
      z.string(),
      z.object({
        modeId: z.string(),
        description: z.string(),
        cemComponentRefs: z.array(z.string()).default([]),
        nonCemRuntimeRefs: z.array(z.string()).optional(),
        patternAssetRefs: z.array(z.string()).default([]),
        invariants: z.record(z.string(), z.unknown()).optional(),
        behavior: z.record(z.string(), z.unknown()).optional(),
        intendedFor: z.array(z.string()).optional(),
        implementationStatus: z.string().optional(),
        componentRefs: z.array(z.string()).optional(),
      })
    )
    .optional(),
  stylePolicyRefs: z.array(z.string()),
  auditFocus: z.array(z.string()).default([]),
});

const styleLayerSchema = z.object({
  layerId: z.string(),
  description: z.string(),
  sources: z.object({
    cemDerived: z.boolean(),
    authored: z.boolean(),
    generated: z.boolean(),
  }),
  allowed: z.array(z.string()),
  forbidden: z.array(z.string()),
});

const styleTargetPolicySchema = z.object({
  targetType: z.string(),
  targetId: z.string(),
  stylingMode: z.string(),
  allowedCssProperties: z.array(z.string()),
  allowedCssParts: z.array(z.string()),
  forbiddenSelectorCategories: z.array(z.string()),
  allowedScopes: z.array(z.string()),
});

const styleBundleSchema = z.object({
  bundleId: z.string(),
  outputName: z.string(),
  packageImport: z.string(),
  description: z.string(),
  provenance: z.object({
    componentRefs: z.array(z.string()).default([]),
    patternContractRefs: z.array(z.string()).default([]),
    styleTargetRefs: z.array(z.string()).default([]),
    authoredRefs: z.array(z.string()).default([]),
    rationale: z.string(),
  }),
  provides: z.array(z.string()).min(1),
  requires: z.array(z.string()).default([]),
  conflictsWith: z.array(z.string()).default([]),
  targetRefs: z.array(z.string()).default([]),
  tokens: z.array(z.string()).default([]),
});

const conditionalBundleSchema = z.object({
  bundleId: z.string(),
  whenFeatureFlag: z.string(),
  description: z.string().optional(),
});

const styleBundleSurfaceSelectionSchema = z.object({
  surfaceId: z.string(),
  description: z.string(),
  provenance: z.object({
    pageSpecRefs: z.array(z.string()).default([]),
    patternContractRefs: z.array(z.string()).default([]),
    rationale: z.string(),
  }),
  requiredBundleIds: z.array(z.string()).default([]),
  optionalBundleIds: z.array(z.string()).default([]),
  conditionalBundleIds: z.array(conditionalBundleSchema).default([]),
});

const orchestrationToolSelectionSchema = z.object({
  laneId: z.string(),
  requiredTools: z.array(z.string()).min(1),
  callOrder: z.array(z.string()).min(1),
  minimumCallableToolCount: z.number().int().positive(),
  failClosedWhenUnavailable: z.boolean(),
  fallbackBehavior: z.string(),
  remediationSteps: z.array(z.string()).min(1),
});

const orchestrationRepoInspectionSchema = z.object({
  minimumAdapterFacts: z.array(z.string()).min(1),
  inspectOnlyAfterCanonicalPayloads: z.boolean(),
  allowedPurposes: z.array(z.string()).min(1),
  forbidLocalDesignAuthorityForNewPage: z.boolean(),
  inspectExistingPatternWhenNamed: z.boolean(),
  preserveExistingPatternWhenExplicitlyEditing: z.boolean(),
});

const orchestrationExecutionPolicySchema = z.object({
  executeWithoutConsentGateWhenRequirementsAreSufficient: z.boolean(),
  forbidWorkflowNarrationAfterExplicitExecution: z.boolean(),
  forbidInternalWorkflowArtifacts: z.boolean(),
  forbidFallbackPolicyQuestions: z.boolean(),
});

const orchestrationTaskPolicySchema = z.object({
  policyId: z.string(),
  scope: z.string(),
  signals: z.array(z.string()).min(1),
  toolSelection: orchestrationToolSelectionSchema,
  repoInspection: orchestrationRepoInspectionSchema,
  execution: orchestrationExecutionPolicySchema,
});

const orchestrationClassificationEntrySchema = z.object({
  clusterId: z.string(),
  summary: z.string(),
  destination: z.string().optional(),
  reason: z.string(),
});

const pageSpecRegionNodeSchema = z.object({
  regionId: z.string(),
  regionKind: z.string(),
  required: z.boolean(),
  source: z.object({
    sourceType: z.string(),
    ref: z.string(),
  }),
});

const pageSpecContractSchema = z.object({
  documentType: z.string(),
  documentVersion: z.string(),
  description: z.string(),
  sources: sourceRefsSchema,
  intendedUse: intendedUseSchema,
  requiredTopLevelFields: z.array(z.string()).min(1),
  enums: z.record(z.string(), z.array(z.string()).min(1)),
  fieldSchema: z.record(
    z.string(),
    z.object({
      type: z.string(),
      enumRef: z.string().optional(),
      requiredFields: z.array(z.string()).optional(),
      minItems: z.number().int().nonnegative().optional(),
      itemSchemaRef: z.string().optional(),
    })
  ),
  nodeSchemas: z.record(
    z.string(),
    z.object({
      requiredFields: z.array(z.string()).min(1),
      properties: z.record(
        z.string(),
        z.object({
          type: z.string(),
          enumRef: z.string().optional(),
          requiredFields: z.array(z.string()).optional(),
        })
      ),
    })
  ),
  invariants: z.array(z.string()),
});

const pageSpecInitialDocumentSchema = z.object({
  specId: z.string(),
  pageType: z.string(),
  frame: z.object({
    shellContractRef: z.string(),
    headerContractRef: z.string(),
    footerComponentRef: z.string(),
  }),
  regions: z.array(pageSpecRegionNodeSchema).min(1),
  styling: z.object({
    stylePolicyRef: z.string(),
    styleBundlesRef: z.string(),
    surfaceId: z.string(),
    targetRefs: z.array(z.string()).min(1),
  }),
  audit: z.object({
    auditRulesRef: z.string(),
    focus: z.array(z.string()).min(1),
  }),
  semantics: z.object({
    pageRole: z.string(),
    bodyModeId: z.string(),
  }),
  nonGoals: z.array(z.string()).optional(),
});

export const componentRulesSchema = z.object({
  schemaId: z.literal('componentRules'),
  schemaVersion: z.string(),
  description: z.string(),
  authority: z.object({
    cemDerived: z.object({
      source: z.string(),
      normalizedVia: z.string(),
      fields: z.array(z.string()).min(1),
    }),
    supplementalAuthored: z.object({
      sourceRef: z.string(),
      fields: z.array(z.string()).min(1),
    }),
    generated: z.object({
      artifact: z.string(),
      generatedBy: z.string(),
    }),
  }),
  intendedUse: intendedUseSchema,
  componentCount: z.number().int().positive(),
  supplementalComponentCount: z.number().int().nonnegative(),
  components: z.record(
    z.string(),
    z.object({
      tagName: z.string(),
      sources: z.object({
        api: z.literal('cemDerived'),
        supplemental: z.literal('supplementalAuthored').optional(),
      }),
      api: z.object({
        importPath: z.string(),
        attributes: z.array(z.string()),
        slots: z.array(z.string()),
        slotDescriptions: z.record(z.string(), z.string()).optional(),
        cssParts: z
          .array(
            z.object({
              name: z.string(),
              description: z.string().optional(),
            })
          )
          .optional(),
        cssProperties: z
          .array(
            z.object({
              name: z.string(),
              description: z.string().optional(),
            })
          )
          .optional(),
        events: z.array(z.string()),
        description: z.string().optional(),
      }),
      supplemental: z
        .object({
          roles: z.array(z.string()).optional(),
          usage: z
            .object({
              generation: z.array(z.string()).optional(),
              auditing: z.array(z.string()).optional(),
              forbidden: z.array(z.string()).optional(),
            })
            .optional(),
          styling: z
            .object({
              ownerLayer: z.string(),
              notes: z.array(z.string()).optional(),
            })
            .optional(),
          relatedPatternContracts: z.array(z.string()).optional(),
        })
        .optional(),
    })
  ),
});

export const patternContractsSchema = z.object({
  schemaId: z.literal('patternContracts'),
  schemaVersion: z.string(),
  description: z.string(),
  contracts: z.record(z.string(), patternContractSchema),
});

export const stylePolicySchema = z.object({
  schemaId: z.literal('stylePolicy'),
  schemaVersion: z.string(),
  description: z.string(),
  targetPolicyShape: z.object({
    requiredFields: z.array(z.string()).min(1),
    fieldDescriptions: z.record(z.string(), z.string()),
  }),
  layers: z.record(z.string(), styleLayerSchema),
  resolutionOrder: z.array(z.string()).min(1),
  targetPolicies: z.array(styleTargetPolicySchema).min(1),
  generationIntent: z.object({
    primary: z.array(z.string()).min(1),
  }),
  auditIntent: z.object({
    primary: z.array(z.string()).min(1),
  }),
});

export const styleBundlesSchema = z.object({
  schemaId: z.literal('styleBundles'),
  schemaVersion: z.string(),
  description: z.string(),
  packageRoot: z.string(),
  bundleOrder: z.array(z.string()).min(1),
  bundles: z.record(z.string(), styleBundleSchema),
  surfaceSelections: z.record(z.string(), styleBundleSurfaceSelectionSchema),
});

export const orchestrationPolicySchema = z.object({
  schemaId: z.literal('orchestrationPolicy'),
  schemaVersion: z.string(),
  description: z.string(),
  sources: sourceRefsSchema,
  intendedUse: intendedUseSchema,
  authorityBoundary: z.object({
    adapterRole: z.literal('thinHostAdapter'),
    authoritativeTierRefs: z.array(z.string()).min(1),
    adapterOwns: z.array(z.string()).min(1),
    adapterMustNotOwn: z.array(z.string()).min(1),
  }),
  taskPolicies: z.record(z.string(), orchestrationTaskPolicySchema),
  cursorRuleClassification: z.object({
    keepInAdapter: z.array(orchestrationClassificationEntrySchema).min(1),
    moveToPortablePolicy: z.array(orchestrationClassificationEntrySchema).min(1),
  }),
});

export const pageSpecSchema = z.object({
  schemaId: z.literal('pageSpec'),
  schemaVersion: z.string(),
  description: z.string(),
  contract: pageSpecContractSchema,
  initialDocument: pageSpecInitialDocumentSchema,
});

export const auditRulesSchema = z.object({
  schemaId: z.literal('auditRules'),
  schemaVersion: z.string(),
  description: z.string(),
  ruleSets: z.array(
    z.object({
      ruleSetId: z.string(),
      rules: z.array(
        z.object({
          ruleId: z.string(),
          title: z.string().optional(),
          category: z.string().optional(),
          scope: z.string().optional(),
          severity: z.string(),
          implementationStatus: z.string(),
          schemaRefs: z.array(z.string()).min(1),
          intendedFor: z.array(z.string()).min(1),
          description: z.string(),
          rationale: z.string().optional(),
          authorityRefs: z
            .array(
              z.object({
                schemaId: z.string(),
                componentId: z.string().optional(),
                contractId: z.string().optional(),
                pageSpecId: z.string().optional(),
                targetType: z.string().optional(),
                targetId: z.string().optional(),
              })
            )
            .optional(),
          safeAutofix: z
            .object({
              supported: z.boolean(),
              note: z.string(),
            })
            .optional(),
        })
      ),
    })
  ),
});

export const sharedFoundationSchema = z.object({
  componentRules: componentRulesSchema.optional(),
  orchestrationPolicy: orchestrationPolicySchema,
  patternContracts: patternContractsSchema,
  stylePolicy: stylePolicySchema,
  styleBundles: styleBundlesSchema,
  pageSpec: pageSpecSchema,
  auditRules: auditRulesSchema,
});

# Styling for consuming applications

When you use Shidoka (e.g. via Shidoka Studio–generated pages) in your own app, you need to load the design system’s global styles and ensure your application’s CSS does not override Shidoka tokens and component styling.

## Required styles

Your app must load these **before** or as part of your main entry so that `kyn-*` components and layout look correct.

**Every Shidoka-consuming project (including all Shidoka Studio–generated projects) must include these three baseline Foundation imports** in a single global CSS file (e.g. `src/app.css`) and load that file from the app entry or root layout:

```css
@import '@kyndryl-design-system/shidoka-foundation/css/root.css';
@import '@kyndryl-design-system/shidoka-foundation/css/index.css';
@import '@kyndryl-design-system/shidoka-foundation/css/grid.css';
```

If the page uses `kyn-widget-gridstack`, add this **fourth** import as well:

```css
@import '@kyndryl-design-system/shidoka-applications/common/css/gridstack-shidoka.css';
```

### Studio-managed shell bundles

When your app uses a Shidoka shell, prefer the published Studio CSS bundles over copying large shell/layout blocks into each app.

```css
@import '@kyndryl-cto/shidoka-studio/styles/shell-base.css';
@import '@kyndryl-cto/shidoka-studio/styles/shell-overlays.css';
@import '@kyndryl-cto/shidoka-studio/styles/header-flyouts.css';
@import '@kyndryl-cto/shidoka-studio/styles/workspace-switcher.css';
/* Add when the shell includes local nav clearance: */
@import '@kyndryl-cto/shidoka-studio/styles/shell-local-nav.css';
```

- `shell-base.css`: base page/shell glue such as `body` reset and footer host treatment.
- `shell-overlays.css`: header, flyout, drawer, and modal stacking.
- `header-flyouts.css`: console/services wrappers plus right-side flyout layout helpers.
- `workspace-switcher.css`: workspace trigger, CURRENT block, and canonical two-pane sizing.
- `shell-local-nav.css`: pinned local-nav clearance. Omit this for header-only or footerless minimal shells.

1. **Shidoka Foundation** (tokens, reset, typography, layout)

   - Install: `npm install @kyndryl-design-system/shidoka-foundation`
   - In your app entry (e.g. `main.ts`, `App.vue`, `_app.tsx`, `index.html`):
     ```js
     import '@kyndryl-design-system/shidoka-foundation/css/root.css';
     import '@kyndryl-design-system/shidoka-foundation/css/index.css';
     import '@kyndryl-design-system/shidoka-foundation/css/grid.css';
     ```
   - `grid.css` is the contract for `kd-grid` and `kd-grid__col--*`. Studio-generated pages keep ordinary interior `<main>` content on that Foundation grid by default.

2. **Shidoka Applications** (if you use components from `@kyndryl-design-system/shidoka-applications`)

   - Component-level styles are encapsulated in shadow DOM, but some components require **external CSS** for layout in the light DOM.
   - **Gridstack CSS (REQUIRED for `kyn-widget-gridstack`):** If your page uses `kyn-widget-gridstack` for dashboard widget grids, you MUST import the gridstack layout CSS. Without it, widgets will have no positioning, no spacing, and will not wrap on resize:
     ```js
     import '@kyndryl-design-system/shidoka-applications/common/css/gridstack-shidoka.css';
     ```
     This file includes gridstack's core positioning CSS (absolute positioning, margin variables) plus Shidoka overrides (max-width, overflow, resize handles). The `kyn-widget-gridstack` component does NOT bundle this CSS in its shadow DOM because the grid items are in the light DOM (slotted content).
   - Any other global styles or utility SCSS the applications package exposes (see its README or dist).

3. **Shidoka Charts** (if you use chart components)
   - Install and import any global CSS the charts package documents.

## Preventing your app from overwriting Shidoka

Application styles (e.g. Tailwind, app-specific CSS, framework defaults) can override design system variables and layout if they come later in the cascade or use higher specificity. Use **CSS cascade layers** so that Shidoka has higher precedence than your app’s global styles.

### How layers work

- **Unlayered styles** always win over **layered** styles.
- Among layers, **later-declared layers** win over earlier ones.
- So: declare an **app** layer first and a **shidoka** layer second. Put your app’s global styles in the **app** layer and Shidoka in the **shidoka** layer. Shidoka will then win when both target the same thing, and you can still override intentionally with unlayered or higher-specificity CSS when needed.

### Recommended setup

**1. Establish layer order** in a single, early-loaded CSS file (e.g. `src/styles/layers.css` or your app entry):

```css
/* Layer order: app first (lower priority), shidoka second (higher priority). */
@layer app, shidoka;
```

**2. Load Shidoka into the `shidoka` layer.**  
If your bundler supports `@import` with `layer()`:

```css
@layer app, shidoka;

@import '@kyndryl-design-system/shidoka-foundation/css/root.css' layer(shidoka);
@import '@kyndryl-design-system/shidoka-foundation/css/index.css' layer(shidoka);
```

Or in JS (e.g. Vite, Webpack), import the foundation CSS and wrap it in a layer in a small wrapper file:

```css
/* shidoka-layer.css */
@layer shidoka {
  @import '@kyndryl-design-system/shidoka-foundation/css/root.css';
  @import '@kyndryl-design-system/shidoka-foundation/css/index.css';
}
```

(Note: some bundlers may not support `@import` inside `@layer`; in that case, use a build step or load foundation first and put only your app styles in `@layer app` so they have lower priority.)

**3. Put your app’s global styles in the `app` layer** so they don’t override Shidoka:

```css
@layer app {
  /* Your app resets, layout, typography overrides, etc. */
  body {
    font-family: var(--kd-font-family, sans-serif);
  }
  .my-page {
    padding: 1rem;
  }
}
```

**4. Intentional overrides** (e.g. a page-specific tweak) can stay **unlayered** or use a later layer so they still win when needed.

### Overlay stacking (drawer, modal)

If `kyn-side-drawer` or `kyn-modal` open but their overlay/panel appears **behind** main content (or flyouts stack incorrectly), import `@kyndryl-cto/shidoka-studio/styles/shell-overlays.css` in your app-level global CSS first. If you cannot import the Studio bundle directly, use this equivalent fallback:

```css
kyn-side-drawer,
kyn-modal {
  position: relative;
  z-index: 0;
}

kyn-header-flyout,
kyn-side-drawer[open],
kyn-modal[open] {
  position: relative;
  z-index: 22;
}
```

Use a value higher than your main content. Keep drawer/modal hosts at `z-index: 0` when closed, then lift only `[open]` so anchor buttons stay in normal stacking and do not sit above expanded local-nav panels.

**If your Svelte app looks much worse than the in-repo consumer fixture** (e.g. wrong layout, flyouts/charts/workspace switcher not matching), see **SVELTE-CONSUMER-ALIGNMENT.md** for a step-by-step checklist (deps, global CSS, layout load order, runes, and page markup) so you can align the external repo with the reference fixture.

### Summary

- **Required:** Load foundation `root.css` and `index.css` (and any applications/charts globals you use).
- **Protection:** Use `@layer app, shidoka` and put Shidoka in `shidoka`, your globals in `app`, so Shidoka isn’t overwritten by app styles.
- **Overlays/Flyouts:** Prefer `@kyndryl-cto/shidoka-studio/styles/shell-overlays.css`; it keeps `kyn-side-drawer` and `kyn-modal` at `z-index: 0` by default, then elevates `kyn-header-flyout`, `kyn-side-drawer[open]`, and `kyn-modal[open]` to `z-index: 22`.
- **Browser support:** `@layer` is supported in all modern browsers (2022+).

For more on cascade layers, see [MDN: @layer](https://developer.mozilla.org/en-US/docs/Web/CSS/@layer).

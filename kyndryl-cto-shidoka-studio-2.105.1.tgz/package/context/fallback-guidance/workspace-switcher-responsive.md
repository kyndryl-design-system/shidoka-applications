# Workspace-switcher fallback responsive guidance

This file is additive fallback guidance derived from local `shidoka-applications` evidence.
It is not a replacement for the canonical MCP artifacts.

## Scope

- Pattern: `workspace-switcher`
- Stage: `phase-2-artifact`
- Additive only: `true`

## Responsive breakpoints observed

- `(max-width: calc(52rem - 0.001px))` from `workspaceSwitcherStyles`
- `(min-width: 52rem)` from `workspaceSwitcherStyles`
- `(max-width: calc(42rem - 0.001px))` from `workspaceSwitcherStyles`
- `(max-width: calc(52rem - 0.001px))` from `workspaceSwitcherMenuItemStyles`
- `(max-width: calc(52rem - 0.001px))` from `workspaceSwitcherStory:decorators`
- `(max-width: calc(42rem - 0.001px))` from `workspaceSwitcherStory:decorators`

## Helper classes observed

- `workspace-switcher__back` from `workspaceSwitcherStyles`: margin-bottom: 8px
- `workspace-switcher__account-meta-name` from `workspaceSwitcherStyles`: max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-weight: 500; color: var(--kd-color-text-level-primary)
- `menu-item--workspace .menu-item__name` from `workspaceSwitcherMenuItemStyles`: max-width: 25ch

## Composition facts observed

- slots: `left`, `left-list`, `mobile-trigger-icon`, `account-status-icon`, `right`, `right-list`
- story exports observed: `UIImplementation`, `FullWorkspaceInfo`, `SimpleWorkspaceInfo`, `WithSearch`

## Runtime-behavior support observed

- mobile presentation event: `kyn-internal-flyout-mobile-presentation`
- emits summary from accountMeta: true
- back button resets root view: true
- left-list selection wiring present in story: true

## Review notes

- No review-only deltas detected during extraction.

## Confidence

- overall: `medium`
- Artifact is derived from local DS workspace-switcher stories, implementation files, and styles.
- Responsive and drilldown behavior is source-backed.
- Promotion into canonical guidance should still wait for runtime validation.

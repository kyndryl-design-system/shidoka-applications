# Fallback Promotability Review

This report summarizes which fallback-derived facts are currently eligible for controlled promotion into canonical guidance.
It is a maintainer review surface only. It does not change the default generation lane.

## header-nav

- supported gap categories: `responsive-structure-gap`, `mobile-overflow-gap`
- ready for canonical review: yes
- promotable gaps: `responsive-structure-gap`, `mobile-overflow-gap`
- review-only facts: 1

### responsive-structure-gap
- Header-flyouts overflow toggle is hidden on desktop and visible on mobile in the local Storybook runtime.
- Workspace trigger chevron remains visible on desktop (flex).
- Workspace trigger chevron hides on mobile in the DS runtime.

### mobile-overflow-gap
- The Help flyout keeps a visible mobile menu label in the current DS runtime when opened.
- Observed mobile top-level labels: Very Long Name That …, Notifications, Help, User Profile

## workspace-switcher

- supported gap categories: `responsive-structure-gap`, `runtime-behavior-gap`
- ready for canonical review: yes
- promotable gaps: `responsive-structure-gap`, `runtime-behavior-gap`
- review-only facts: 1

### responsive-structure-gap
- The workspace-switcher back control is hidden on desktop.
- The workspace-switcher back control is visible on mobile detail view.

### runtime-behavior-gap
- The workspace switcher enters detail view on mobile after selecting a workspace item.
- Activating the mobile back control returns the workspace switcher to root view.

## local-nav

- supported gap categories: `responsive-structure-gap`, `runtime-behavior-gap`
- ready for canonical review: yes
- promotable gaps: `responsive-structure-gap`, `runtime-behavior-gap`
- review-only facts: none

### responsive-structure-gap
- The local-nav renders as a fixed desktop rail and hides the mobile toggle at desktop widths.
- The mobile toggle adds nav--expanded-mobile and expands the local-nav links region.

### runtime-behavior-gap
- Expanding a nested local-nav link on mobile shows a visible go-back control inside the submenu.
- Using the submenu go-back control collapses the expanded nested local-nav link on mobile.

# Local-nav fallback responsive guidance

This file is additive fallback guidance derived from local `shidoka-applications` evidence.
It is not a replacement for the canonical MCP artifacts.

## Scope

- Pattern: `local-nav`
- Stage: `phase-2-artifact`
- Additive only: `true`

## Responsive breakpoints observed

- `(max-width: calc(42rem - 0.001px))` from `localNavStyles`
- `(min-width: 42rem)` from `localNavStyles`
- `(min-width: 42rem)` from `localNavLinkStyles`
- `(max-width: calc(42rem - 0.001px))` from `localNavLinkStyles`

## Helper classes observed

- `mobile-toggle` from `localNavStyles`: background: none; border: none; border-radius: 4px; outline: 2px solid transparent; outline-offset: -2px; font: inherit; color: var(--kd-color-text-level-primary); padding: 8px 12px; cursor: pointer; display: flex; align-items: center; justify-content: space-between; width: 100%; height: 40px; transition: background-color 150ms ease-out, color 150ms ease-out, outline-color 150ms ease-out
- `links` from `localNavStyles`: visibility: hidden; flex-direction: column; gap: 2px; list-style: none; padding: 0 8px; margin: 0; overflow-y: hidden; overflow-x: hidden; position: absolute; top: 100%; left: 0; width: 100%; background-color: var(--kd-color-background-menu-state-default); padding-top: 4px; transition: height 250ms ease-out, visibility 250ms ease-out; height: 0
- `go-back` from `localNavLinkStyles`: display: flex; position: relative; align-items: center; padding: 8px 16px 8px 8px; cursor: pointer; background: none; border: none; margin: 0; border-radius: 4px; width: 100%; transition: background-color 150ms ease-out, color 150ms ease-out, outline-color 150ms ease-out; outline: 2px solid transparent; outline-offset: -2px; color: var(--kd-color-text-level-primary)

## Composition facts observed

- slots: `default`, `search`, `icon`, `links`
- level-one icons required: true
- story exports observed: `LocalNav`, `WithDivider`, `WithSearch`, `ManualToggleVariant`, `ManualToggleVariantCollapsedByDefault`

## Runtime-behavior support observed

- toggle event: `on-toggle`
- link-active event: `null`
- breakpoint state reset present: true
- nested back resets expanded: true

## Review notes

- No review-only deltas detected during extraction.

## Confidence

- overall: `medium`
- Artifact is derived from local DS local-nav stories, implementation files, and styles.
- Responsive layout and nested mobile submenu behavior are source-backed.
- Promotion into canonical guidance should still wait for runtime validation.

# Header-nav fallback responsive guidance

This file is additive fallback guidance derived from local `shidoka-applications` evidence.
It is not a replacement for the canonical MCP artifacts.

## Scope

- Pattern: `header-nav`
- Stage: `phase-2-artifact`
- Additive only: `true`

## Responsive breakpoints observed

- `(min-width: 42rem)` from `headerFlyoutsStyles`
- `(min-width: 42rem)` from `headerFlyoutStyles`
- `(max-width: calc(42rem - 0.001px))` from `headerFlyoutStyles`
- `(max-width: calc(52rem - 0.001px))` from `workspaceSwitcherStyles`
- `(min-width: 52rem)` from `workspaceSwitcherStyles`
- `(max-width: calc(42rem - 0.001px))` from `workspaceSwitcherStyles`
- `(max-width: calc(52rem - 0.001px))` from `workspaceSwitcherStory:UIImplementation`
- `(max-width: calc(42rem - 0.001px))` from `workspaceSwitcherStory:UIImplementation`

## Helper classes observed in DS story composition

- `.account-name` from `workspaceSwitcherStory:UIImplementation`: max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap
- `.account-chevron` from `workspaceSwitcherStory:UIImplementation`: display: flex; transition: transform 0.2s
- `.ui-impl-switcher` from `workspaceSwitcherStory:UIImplementation`: width: 625px

## Flyout composition observed in workspace UIImplementation story

- `workspace`: label mode = selectedItemName; hideMenuLabel = true; hideButtonLabel = true; noPadding = true
- `notifications`: label mode = static (`Notifications`); hideMenuLabel = true; hideButtonLabel = false
- `help`: label mode = static (`Help`); hideMenuLabel = false; hideButtonLabel = false
- `user`: label mode = static (`User Profile`); hideMenuLabel = true; hideButtonLabel = false

## Internal mobile presentation support observed

- event: `kyn-internal-flyout-mobile-presentation`
- config fields: `buttonIconSvg`, `summaryIconSvg`, `summaryLabel`, `summaryDetails`, `mobileLabel`, `hideButtonContentOnMobile`

## Review notes

- The local DS UIImplementation story leaves the Help flyout without hideMenuLabel, unlike the workspace, notifications, and user flyouts in that same story. Treat this as review-only evidence until runtime validation decides whether it should affect canonical guidance.

## Confidence

- overall: `medium`
- Artifact is derived from local DS stories, implementation files, and styles rather than from published package metadata alone.
- Responsive breakpoint and helper-class facts are source-backed.
- Promotion into canonical guidance should still wait for runtime validation in Phase 3.

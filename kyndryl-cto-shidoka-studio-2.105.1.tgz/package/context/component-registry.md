# Shidoka Component Registry

**Source of truth: custom-elements.json.** This registry is generated from it.

119 components. ONLY these kyn-* tags exist. Never use <my-button>, <button>, or invented tags.

## Tag → Import mapping

| Tags | Import |
|---|---|
| `<kyn-ai-launch-btn>` | `import '../../components/ai/aiLaunchButton/index';` |
| `<kyn-ai-sources-feedback>` | `import '../../components/ai/sourcesFeedback/index';` |
| `<kyn-footer>` | `import '../../components/global/footer/index';` |
| `<kyn-header>`, `<kyn-header-categories>`, `<kyn-header-category>`, `<kyn-header-divider>`, `<kyn-header-flyout>`, `<kyn-header-flyouts>`, `<kyn-header-link>`, `<kyn-header-nav>`, `<kyn-header-notification-panel>`, `<kyn-header-panel-link>`, `<kyn-header-user-profile>` | `import '../../components/global/header/index';` |
| `<kyn-local-nav>`, `<kyn-local-nav-divider>`, `<kyn-local-nav-link>` | `import '../../components/global/localNav/index';` |
| `<kyn-ui-shell>` | `import '../../components/global/uiShell/index';` |
| `<kyn-workspace-switcher>`, `<kyn-workspace-switcher-menu-item>` | `import '../../components/global/workspaceSwitcher/index';` |
| `<kyn-accordion>`, `<kyn-accordion-item>` | `import '../../components/reusable/accordion/index';` |
| `<kyn-avatar>` | `import '../../components/reusable/avatar/index';` |
| `<kyn-badge>` | `import '../../components/reusable/badge/index';` |
| `<kyn-block-code-view>` | `import '../../components/reusable/blockCodeView/index';` |
| `<kyn-breadcrumbs>` | `import '../../components/reusable/breadcrumbs/index';` |
| `<kyn-button>` | `import '../../components/reusable/button/index';` |
| `<kyn-button-group>` | `import '../../components/reusable/buttonGroup/index';` |
| `<kyn-card>`, `<kyn-info-card-skeleton>`, `<kyn-vital-card-skeleton>` | `import '../../components/reusable/card/index';` |
| `<kyn-checkbox>`, `<kyn-checkbox-group>`, `<kyn-checkbox-subgroup>` | `import '../../components/reusable/checkbox/index';` |
| `<kyn-color-input>` | `import '../../components/reusable/colorInput/index';` |
| `<kyn-date-picker>` | `import '../../components/reusable/datePicker/index';` |
| `<kyn-date-range-picker>` | `import '../../components/reusable/daterangepicker/index';` |
| `<kyn-divider>` | `import '../../components/reusable/divider/index';` |
| `<kyn-dropdown>`, `<kyn-dropdown-category>`, `<kyn-dropdown-option>`, `<kyn-enhanced-dropdown-option>` | `import '../../components/reusable/dropdown/index';` |
| `<kyn-error-block>` | `import '../../components/reusable/errorBlock/index';` |
| `<kyn-file-uploader>`, `<kyn-file-uploader-list-container>` | `import '../../components/reusable/fileUploader/index';` |
| `<kyn-button-float-container>` | `import '../../components/reusable/floatingContainer/index';` |
| `<kyn-global-filter>` | `import '../../components/reusable/globalFilter/index';` |
| `<kyn-icon-selector>`, `<kyn-icon-selector-group>` | `import '../../components/reusable/iconSelector/index';` |
| `<kyn-inline-code-view>` | `import '../../components/reusable/inlineCodeView/index';` |
| `<kyn-inline-confirm>` | `import '../../components/reusable/inlineConfirm/index';` |
| `<kyn-link>` | `import '../../components/reusable/link/index';` |
| `<kyn-ai-loader>`, `<kyn-loader-inline>`, `<kyn-loader>`, `<kyn-skeleton>`, `<kyn-spinner>` | `import '../../components/reusable/loaders/index';` |
| `<kyn-meta-data>` | `import '../../components/reusable/metaData/index';` |
| `<kyn-modal>` | `import '../../components/reusable/modal/index';` |
| `<kyn-multi-input-field>` | `import '../../components/reusable/multiInputField/index';` |
| `<kyn-notification>`, `<kyn-notification-container>` | `import '../../components/reusable/notification/index';` |
| `<kyn-number-input>` | `import '../../components/reusable/numberInput/index';` |
| `<kyn-overflow-menu>`, `<kyn-overflow-menu-item>` | `import '../../components/reusable/overflowMenu/index';` |
| `<kyn-page-title>`, `<kyn-pagetitle-option>` | `import '../../components/reusable/pagetitle/index';` |
| `<kyn-pagination>`, `<kyn-pagination-items-range>`, `<kyn-pagination-navigation-buttons>`, `<kyn-pagination-page-size-dropdown>`, `<kyn-pagination-skeleton>` | `import '../../components/reusable/pagination/index';` |
| `<kyn-popover>` | `import '../../components/reusable/popover/index';` |
| `<kyn-progress-bar>` | `import '../../components/reusable/progressBar/index';` |
| `<kyn-query-builder>`, `<kyn-qb-group>`, `<kyn-qb-rule>` | `import '../../components/reusable/queryBuilder/index';` |
| `<kyn-radio-button>`, `<kyn-radio-button-group>` | `import '../../components/reusable/radioButton/index';` |
| `<kyn-search>` | `import '../../components/reusable/search/index';` |
| `<kyn-side-drawer>` | `import '../../components/reusable/sideDrawer/index';` |
| `<kyn-slider-input>` | `import '../../components/reusable/sliderInput/index';` |
| `<kyn-split-btn>`, `<kyn-splitbutton-option>` | `import '../../components/reusable/splitButton/index';` |
| `<kyn-split-view>` | `import '../../components/reusable/splitView/index';` |
| `<kyn-status-btn>` | `import '../../components/reusable/statusButton/index';` |
| `<kyn-stepper>`, `<kyn-stepper-item>`, `<kyn-stepper-item-child>` | `import '../../components/reusable/stepper/index';` |
| `<kyn-tbody>`, `<kyn-td>`, `<kyn-table-container>`, `<kyn-expanded-tr>`, `<kyn-tfoot>`, `<kyn-table-footer>`, `<kyn-thead>`, `<kyn-th-group>`, `<kyn-header-tr>`, `<kyn-th>`, `<kyn-table-legend-item>`, `<kyn-table-legend>`, `<kyn-tr>`, `<kyn-table-toolbar>`, `<kyn-table-skeleton>`, `<kyn-table>` | `import '../../components/reusable/table/index';` |
| `<kyn-tab>`, `<kyn-tab-panel>`, `<kyn-tabs>` | `import '../../components/reusable/tabs/index';` |
| `<kyn-tag-skeleton>`, `<kyn-tag>`, `<kyn-tag-group>` | `import '../../components/reusable/tag/index';` |
| `<kyn-text-area>` | `import '../../components/reusable/textArea/index';` |
| `<kyn-text-input>` | `import '../../components/reusable/textInput/index';` |
| `<kyn-time-picker>` | `import '../../components/reusable/timepicker/index';` |
| `<kyn-toggle-button>` | `import '../../components/reusable/toggleButton/index';` |
| `<kyn-tooltip>` | `import '../../components/reusable/tooltip/index';` |
| `<kyn-widget>`, `<kyn-widget-drag-handle>`, `<kyn-widget-gridstack>` | `import '../../components/reusable/widget/index';` |

## Key attributes (from CEM — most-used components)

- `<kyn-button>`: description, type, kind, href, target, size, iconPosition, disabled, value, name, isFloating, showOnScroll, selected, formmethod, splitLayout
- `<kyn-text-input>`: value, name, invalidText, label, type, size, caption, placeholder, required, disabled, readonly, pattern, maxLength, minLength, iconRight, hideLabel, textStrings, autoComplete
- `<kyn-dropdown>`: value, name, invalidText, label, size, kind, inline, caption, placeholder, open, searchable, searchThreshold, enhanced, readonly, filterSearch, multiple, required, hideLabel, disabled, hideTags, selectAll, selectAllText, menuMinWidth, openDirection, textStrings, allowAddOption, preventDuplicateAddOption, allowDuplicateSelections, searchText
- `<kyn-modal>`: open, size, titleText, labelText, okText, cancelText, destructive, okDisabled, secondaryDisabled, hideFooter, secondaryButtonText, showSecondaryButton, hideCancelButton, closeText, gradientBackground, aiConnected, disableScroll
- `<kyn-card>`: type, href, rel, target, hideBorder, aiConnected, highlight, compact, variant
- `<kyn-table>`: checkboxSelection, striped, stickyHeader, dense, fixedLayout
- `<kyn-ui-shell>`: (none)
- `<kyn-header>`: rootUrl, appTitle
- `<kyn-header-flyout>`: open, anchorLeft, hideArrow, label, hideMenuLabel, hideButtonLabel, assistive-text, href, backText, noPadding
- `<kyn-footer>`: rootUrl, logoAriaLabel
- `<kyn-side-drawer>`: open, size, titleText, labelText, submitBtnText, cancelBtnText, closeBtnDescription, submitBtnDisabled, gradientBackground, hideFooter, destructive, secondaryButtonText, showSecondaryButton, hideCancelButton, aiConnected, noBackdrop, resizable
- `<kyn-workspace-switcher>`: textStrings, hideCurrentTitle, hideWorkspacesTitle, hide-left-divider
- `<kyn-accordion>`: showNumbers, startNumber, filledHeaders, compact, expandLabel, collapseLabel
- `<kyn-tabs>`: tabSize, vertical, aiConnected, disableAutoFocusUpdate, scrollablePanels
- `<kyn-tab>`: id, selected, disabled, vertical, data-aiconnected, role, tabIndex, 'aria-selected', 'aria-controls', 'aria-disabled'
- `<kyn-tab-panel>`: tabId, visible, noPadding

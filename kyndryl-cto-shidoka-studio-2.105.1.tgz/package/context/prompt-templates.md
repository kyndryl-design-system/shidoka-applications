# Standalone prompt templates

This document describes the **standalone prompt template** surface in **Shidoka Studio**.

These templates are:
- opt-in
- pre-baked
- scaffold-oriented
- isolated from the normal day-to-day Shidoka Studio prompting flow

They exist for cases where a user wants a compact, named shortcut such as a dashboard scaffold or data-table scaffold, without changing the default MCP-backed generation path.

---

## Design goals

- Keep normal Shidoka Studio prompting unchanged.
- Offer a smaller, explicit shortcut surface for common scaffold requests.
- Return stable, structured data that an MCP client or LLM can consume directly.
- Reduce ambiguity more than computation: the main benefit is repeatability and less prompt parsing work, not a guarantee of dramatic latency reduction.

---

## Tooling

The standalone surface is exposed by dedicated MCP tools:

- `get_shidoka_prompt_template_catalog`
- `get_shidoka_prompt_template`
- `resolve_shidoka_prompt_template_alias`

These tools are intentionally separate from the existing canonical generation tools.

They do **not** replace:

- `get_shidoka_design_context`
- `get_canonical_full_page_template`
- `get_canonical_full_page_recipe`
- `get_shidoka_full_page_snippets`
- `get_canonical_header_nav_template`
- `get_canonical_header_nav_recipe`
- `get_shidoka_header_nav_snippets`

The current full-page and header-nav flows remain the authoritative default for normal prompting.

---

## Current templates

The initial standalone catalog includes:

- `dashboardPage`
- `dataTablePage`
- `detailWorkflowPage`

**Roadmap:** The catalog is expected to grow toward **9–12** templates so that, taken together, they cover the **majority of internal** front-end scaffold cases for Shidoka Studio. In the source repo, see `docs/generation-enhancements/PROMPT-TEMPLATING-ACTION-PLAN.md` for the longer rollout plan.

Each template carries:

- a stable template id
- an archetype id
- recommended MCP toolchain
- derived defaults from the underlying archetype
- a user-facing prompt template
- usage notes that make the opt-in boundary explicit

---

## Non-interference rule

Standalone prompt templates must never silently take over normal prompting.

That means:

- no automatic preference in the main Cursor rule
- no default replacement of the existing 7-tool flow
- no hidden prompt rewriting during ordinary Shidoka Studio use

If the user does not explicitly ask for a standalone template or scaffold shortcut, the normal Shidoka Studio flow should be used.

---

## Performance expectations

Standalone templates may reduce token usage and latency somewhat when they let the model fetch a narrower payload.

However, the primary benefit is **consistency**:

- less prompt ambiguity
- less re-derivation of scaffold defaults
- more reliable mapping from short request to known archetype

They should be treated as a compact scaffold entrypoint, not as a replacement for the broader design-system context.

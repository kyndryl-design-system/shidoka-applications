# Svelte consumer alignment: why external repos look different

The in-repo consumer fixture (`consumer-fixtures/sveltekit-dashboard`) is the reference. If your external Svelte app looks noticeably worse (e.g. “40%” vs “80%”), it’s usually because one or more of the following don’t match the fixture.

## Why the disparity happens

- **No single bootstrap** – Shidoka Studio doesn’t ship a “Svelte starter repo.” The fixture is the de facto spec, but external apps are created separately (different versions, different layout, different page markup).
- **Version drift** – Different `@kyndryl-design-system/*` versions can change tokens, component behavior, and CSS.
- **Missing or different global setup** – CSS import order, missing imports, or missing layout logic (e.g. when and how design-system JS is loaded) change how the shell and widgets render.
- **Markup and events** – Generated or hand-written pages in the external repo may use wrong event names (`onflyout-toggle` vs `on:on-flyout-toggle`), wrong grid attributes (`data-gs-w` vs `gs-w`), or missing props (`chartTitle`, `description`, `style` on `kd-chart`), so behavior and layout diverge.

To get an external Svelte app to look and behave like the in-repo instance, align it point-by-point with the fixture.

---

## 1. Dependencies (match versions if you can)

In-repo fixture uses:

```json
"dependencies": {
  "@kyndryl-design-system/shidoka-applications": "^2.90.3",
  "@kyndryl-design-system/shidoka-charts": "^2.8.11",
  "@kyndryl-design-system/shidoka-foundation": "^2.8.10",
  "@kyndryl-design-system/shidoka-icons": "^2.21.0"
}
```

Svelte 5 + runes:

```json
"svelte": "^5.53.11"
```

Use at least these packages; pin to these ranges (or current patch versions) to minimize visual/behavioral drift.

---

## 2. Global CSS (`app.css` or equivalent)

The fixture has **one** global CSS file imported from the root layout. It must contain, in this order:

1. The three required Foundation imports, plus Gridstack only when the page actually uses `kyn-widget-gridstack`.
2. **Shidoka Studio shell bundles**. The canonical shell glue lives in published Studio CSS bundles, not in app-specific code:
   - **In-repo fixture:** import the published Studio bundles directly from `@kyndryl-cto/shidoka-studio/styles/*` in `consumer-fixtures/sveltekit-dashboard/src/app.css`.
   - **External apps:** import the published bundles directly from `@kyndryl-cto/shidoka-studio/styles/*`. Do not maintain shell layout rules only in your app.css; the canonical source is the Studio bundle set.

```css
@import '@kyndryl-design-system/shidoka-foundation/css/root.css';
@import '@kyndryl-design-system/shidoka-foundation/css/index.css';
@import '@kyndryl-design-system/shidoka-foundation/css/grid.css';
@import '@kyndryl-cto/shidoka-studio/styles/shell-base.css';
@import '@kyndryl-cto/shidoka-studio/styles/shell-local-nav.css';
@import '@kyndryl-cto/shidoka-studio/styles/shell-overlays.css';
@import '@kyndryl-cto/shidoka-studio/styles/header-flyouts.css';
@import '@kyndryl-cto/shidoka-studio/styles/workspace-switcher.css';
```

Add this only when the page uses `kyn-widget-gridstack`:

```css
@import '@kyndryl-design-system/shidoka-applications/common/css/gridstack-shidoka.css';
```

- Missing or reordered imports → wrong tokens, layout, or grid.
- Missing `grid.css` → `kd-grid`/`kd-grid__col--*` classes do not exist, so the default Studio page layout contract breaks even before any framework-specific code runs.
- Missing shell layout (local-nav clearance, overlay z-index) → main/footer misalign or drawer/modal render behind the trigger. Use the Studio-managed bundles as the single source of truth.

**If "Open Drawer" or "Modal" (toolbar buttons) overlay the page when the drawer/modal is closed:** the overlay bundle should keep `kyn-side-drawer` and `kyn-modal` at the base layer (`z-index: 0`) and lift only `[open]` to `z-index: 22`. So the anchor stays in flow when closed; when open, the overlay can sit on top. Ensure your app imports `@kyndryl-cto/shidoka-studio/styles/shell-overlays.css`. **If the workspace switcher or other header flyouts open behind the main content:** that same bundle also keeps `kyn-header-flyout { position: relative; z-index: 22; }`. No parent of the toolbar or main content should have a higher `z-index` or `position` that creates a stacking context above the overlay or flyouts.

---

## 3. Root layout: load design-system JS before first paint

The fixture’s `+layout.svelte` does two things:

1. **Imports the global CSS**  
   `import '../app.css';` (or your path to the file from step 2).

2. **In `onMount` (browser only):**  
   Dynamically loads the design-system entry points, then (optionally) applies the flyout stacking patch:

```js
import { browser } from '$app/environment';
import { onMount, tick } from 'svelte';
import '../app.css';

let { children } = $props();

onMount(async () => {
  if (!browser) return;

  // Optional: patch flyout shadow roots so menu content stacks correctly
  const patchRoot = (flyout) => {
    const root = flyout.shadowRoot;
    if (!root || root.querySelector('[data-fixture-flyout-stacking-patch]')) return;
    const style = document.createElement('style');
    style.setAttribute('data-fixture-flyout-stacking-patch', '');
    style.textContent = `.menu.open .menu__content { z-index: 1 !important; }`;
    root.append(style);
  };
  const patchExistingFlyouts = () => {
    document.querySelectorAll('kyn-header-flyout').forEach(patchRoot);
  };

  await import('@kyndryl-design-system/shidoka-applications');
  await import('@kyndryl-design-system/shidoka-charts/components/chart');
  await customElements.whenDefined('kyn-header-flyout');
  await tick();

  patchExistingFlyouts();
  const observer = new MutationObserver(patchExistingFlyouts);
  observer.observe(document.body, { childList: true, subtree: true });
  return () => observer.disconnect();
});
```

If your external app doesn’t load these two modules (and optionally wait for `kyn-header-flyout` + patch), custom elements may not be defined or styled in time, and flyouts can stack wrong.

---

## 4. Svelte config (runes)

Fixture has:

```js
// svelte.config.js
compilerOptions: { runes: true },
```

Without `runes: true`, Svelte 5 runes (`$state`, `$derived`, `$effect`, `$props`) won’t compile and you get runtime or layout issues.

---

## 5. Page-level markup and behavior

These must match the fixture’s patterns; otherwise layout and interactions drift.

| Area | Fixture / correct | Common external mistakes |
|------|-------------------|---------------------------|
| **Flyout toggle** | `onon-flyout-toggle={handleWorkspaceFlyoutToggle}` | `onflyout-toggle` / `on-flyout-toggle` (wrong name) or legacy `on:on-flyout-toggle` (deprecated) |
| **Workspace/account items** | `onon-click={() => selectWorkspace(workspace.id)}` and `onon-click={() => selectAccount(account.id)}` | Missing `onon-click`, malformed `on-click`, or legacy `on:on-click` (deprecated) |
| **Account ID copy** | `kyn-link` with `onclick`, `onkeydown`, `data-copy-state={copiedAccountId ? 'copied' : 'idle'}` | No handlers, no `data-copy-state`, or legacy `on:click` / `on:keydown` (deprecated) |
| **CURRENT block** | Uses `selectedAccount` (from state) for name, accountId, country | Static text → doesn’t reflect selection |
| **Trigger label** | `{selectedAccount?.name ?? 'Select workspace'}` | Static text → doesn’t update on selection |
| **Gridstack items** | `gs-w="4" gs-h="1"` on the grid item div | `data-gs-w` / `data-gs-h` → grid doesn’t lay out correctly |
| **gridstackConfig** | Plain `const` (not `$state`) | `$state` can cause re-init issues |
| **kd-chart** | `chartTitle`, `description`, `options={createChartOptions(preset.type)}`, `style="width: 100%; display: block;"`, and real-element `labels` / `datasets` / `options` property hydration when upgrade timing races | Missing any of these, or serializing rich props as plain attributes, → charts look wrong or truncated |
| **Workspace state** | `selectedWorkspaceId`, `selectedAccountId`, `currentAccounts` ($derived), `selectedAccount` ($derived) | Missing or wrong state → CURRENT and list don’t track selection |

Use the fixture’s Dashboard1 page and `$lib/dashboard-data.js` (workspaces, accountsByWorkspace, createChartOptions, etc.) as the reference implementation.

---

## 6. Quick checklist for “match the in-repo instance”

- [ ] Same four Shidoka packages and similar versions.
- [ ] Single global CSS file with the three `@import`s, body styles, and `kyn-side-drawer` / `kyn-modal` z-index.
- [ ] Root layout imports that CSS and in `onMount` loads `shidoka-applications` and `shidoka-charts/components/chart` (and optionally flyout patch).
- [ ] `compilerOptions: { runes: true }` in `svelte.config.js` if using Svelte 5.
- [ ] All flyout and workspace events use `onon-flyout-toggle` and `onon-click`; copy link has `onclick` and `onkeydown` and `data-copy-state`.
- [ ] CURRENT and trigger driven by `selectedAccount` (and workspace/account state).
- [ ] Grid items use `gs-w` / `gs-h`; `kd-chart` has `chartTitle`, `description`, `options`, `style="width: 100%; display: block;"`, and `labels` / `datasets` / `options` reach the real chart element.

Once these match, the external Svelte app should be much closer to the “80%” in-repo look and behavior. Remaining gaps are usually due to small markup or state differences; compare your page and layout side-by-side with the fixture file-by-file.

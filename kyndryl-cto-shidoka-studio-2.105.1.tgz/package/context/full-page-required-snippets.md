# Required full-page snippets (generated from archetype spec)
Use this payload for full-page generation and refinement. Do not shorten, simplify, or substitute different patterns.
These notes intentionally focus on the highest-risk implementation details that tend to drift in consuming apps: global-switcher composition, all-four-flyouts behavior, workspace-switcher trigger/wiring, the Foundation-grid-vs-gridstack boundary, and the fixed main-content rhythm.
Use the recipe/pageSpec for framework-neutral shell/body planning first. This snippets payload remains required until every high-risk invariant is fully modeled structurally.
## Deterministic default shell — same output every time
Unless the user **explicitly** asks for a reduced/minimal shell, the **default** `kyn-ui-shell` + header + footer is **fixed**: same component set, same order, same Bridge logo, same `kyn-header-nav` JSONSwitcher structure, same four flyouts (workspace, notifications, help, user), same workspace-switcher pattern, and **`kyn-footer` with `slot="copyright"`** carrying **Copyright © [year] Kyndryl Inc. All rights reserved.** (plus footer Bridge logo per template). **Only translate** the canonical template into the target framework—**do not** invent alternatives (initials logo, text-only masthead, empty flyout region, hamburger+search header, decorative left strip instead of the real header, or a footer that only shows a prototype subtitle with **no** legal copyright line). Product-specific body content (catalog, forms, tables) goes **inside `main`**; it does not replace or simplify the shell.
**REGRESSION CHECK — Full shell: header + charts + footer.** The page MUST include **(1) the top header bar** (kyn-header with logo, kyn-header-nav, kyn-header-flyouts with all four flyouts)—not just a left icon rail; **(2) charts that render** (every kyn-widget in a chart grid must contain a `kd-chart` with `labels` and `datasets`; empty card bodies are wrong; when a framework does not deliver object props declaratively, hydrate chart data on the real element after mount); **(3) the footer** (`kyn-footer` as the last child of kyn-ui-shell with `<span slot="copyright">Copyright © [year] Kyndryl Inc. All rights reserved.</span>`). If the prompt explicitly asks for local nav, the page must also include a populated `kyn-local-nav` between the header and main regions. Missing the top header, rendering only the logo/appTitle without the workspace + notifications + help + user flyout triggers, leaving chart cells empty, omitting a requested local nav, or omitting the footer are regressions.
## Planning boundary
- Planning authority: shared page spec `shidokaAppPage` with shell contract `shell` and body-modes contract `dashboard-body-modes`.
- Snippet-only or snippet-first details still include exact CURRENT block markup/classes, app-level CSS glue, and framework binding/event adapters.
- Compatibility note: Main padding and local-nav clearance wording still differs across some authored docs and generated prose. When those surfaces disagree, treat the shared foundation pageSpec/patternContracts and the generated recipe projection as the planning authority until the prose is reconciled.
## Styling policy
- Derived summary only: the authority remains the packaged `context/style-policy.json`, `context/component-rules.json`, and `context/pattern-contracts.json` contracts (authored from `src/content/shared-foundation/` and related source inputs).
- Resolve styling ownership in this order: `component`, `patternLayout`, `appGlueGlobal`.
- Choose the narrowest styling layer that can satisfy the requirement.
- Prefer component defaults, design tokens, documented cssProperties, and documented cssParts before authoring CSS.
- Prefer component API truth first, then authored pattern/layout truth, then app glue.
- Do not style component internals or reskin component hosts unless the shared policy explicitly allows the host hook.
- Do not write custom CSS for Shidoka component internals by default. Avoid descendant/internal selectors, undocumented `::part(...)` hooks, and page-local visual reskins of `kyn-*` hosts.
- `kyn-ui-shell` stays appGlueCoordinatedHost. Prefer component defaults, tokens, and documented host hooks first. Allowed host hooks: component defaults only; no documented `cssParts` contract. Forbidden selector categories: `shadowInternalSelectors`, `pageScopedShellVisualReskins`.
- `kyn-header` stays componentApiOnly. Prefer component defaults, tokens, and documented host hooks first. Allowed host hooks: `--kyn-header-logo-width`; no documented `cssParts` contract. Forbidden selector categories: `shadowInternalSelectors`, `storyOnlyImplementationClasses`, `pageScopedStackingOverrides`.
- `kyn-header-nav` stays componentApiOnly. Prefer component defaults, tokens, and documented host hooks first. Allowed host hooks: `--kyn-global-switcher-max-height`; no documented `cssParts` contract. Forbidden selector categories: `shadowInternalSelectors`, `storyOnlyImplementationClasses`, `pageScopedStructurePatches`.
- `kyn-header-flyouts` stays appGlueCoordinatedHost. Prefer component defaults, tokens, and documented host hooks first. Allowed host hooks: `z-index`, `position`; no documented `cssParts` contract. Forbidden selector categories: `shadowInternalSelectors`, `pageScopedStackingOverrides`, `storyOnlyImplementationClasses`.
- `kyn-header-flyout` stays componentApiOnly. Prefer component defaults, tokens, and documented host hooks first. Allowed host hooks: component defaults only; no documented `cssParts` contract. Forbidden selector categories: `shadowInternalSelectors`, `storyOnlyImplementationClasses`.
- `kyn-workspace-switcher` stays componentPlusPatternWrapper. Prefer component defaults, tokens, and documented host hooks first. Allowed host hooks: `--kyn-workspace-switcher-max-height`, `--kyn-workspace-switcher-left-panel-width`; no documented `cssParts` contract. Forbidden selector categories: `shadowInternalSelectors`, `pageScopedStructurePatches`.
- `kyn-local-nav` stays appGlueCoordinatedHost. Prefer component defaults, tokens, and documented host hooks first. Allowed host hooks: component defaults only; no documented `cssParts` contract. Forbidden selector categories: `shadowInternalSelectors`, `pageScopedShellVisualReskins`.
- `kyn-footer` stays componentApiOnly. Prefer component defaults, tokens, and documented host hooks first. Allowed host hooks: component defaults only; no documented `cssParts` contract. Forbidden selector categories: `shadowInternalSelectors`, `pageScopedStructurePatches`, `pageScopedShellVisualReskins`.
- `kyn-widget-gridstack` stays patternOwnedHostLayout. Prefer component defaults, tokens, and documented host hooks first. Allowed host hooks: component defaults only; no documented `cssParts` contract. Forbidden selector categories: `shadowInternalSelectors`, `componentVisualReskins`, `gridstackInternalOverrides`.
- `kyn-widget` stays componentApiOnly. Prefer component defaults, tokens, and documented host hooks first. Allowed host hooks: component defaults only; no documented `cssParts` contract. Forbidden selector categories: `shadowInternalSelectors`, `componentVisualReskins`.
- Pattern/layout CSS for `shell` belongs in wrapper/helper classes and shared pattern assets. Use it for layout, spacing, and positioning only. Allowed scopes: `sharedAppGlue`. Common allowed properties: `position`, `z-index`, `padding-left`, `padding-right`, `box-sizing`.
- Pattern/layout CSS for `header-nav` belongs in wrapper/helper classes and shared pattern assets. Use it for layout, spacing, and positioning only. Allowed scopes: `patternWrapper`, `sharedAppGlue`. Common allowed properties: `display`, `flex-direction`, `gap`, `padding`, `min-width`, `max-width`, `box-sizing`, `white-space`.
- Pattern/layout CSS for `workspace-switcher` belongs in wrapper/helper classes and shared pattern assets. Use it for layout, spacing, and positioning only. Allowed scopes: `patternWrapper`, `sharedAppGlue`. Common allowed properties: `width`, `min-width`, `max-width`, `display`, `gap`, `padding`, `margin`, `font-size`, `line-height`, `color`, `transition`.
- Pattern/layout CSS for `dashboard-body-modes` belongs in wrapper/helper classes and shared pattern assets. Use it for layout, spacing, and positioning only. Allowed scopes: `patternWrapper`, `pageRegion`. Common allowed properties: `width`, `min-width`, `min-height`, `margin`, `display`, `grid-template-columns`, `gap`.
- App glue target `shell-global` belongs in one app-level global stylesheet. Use it for shell clearance, overlay stacking, and cross-pattern coordination. Allowed scopes: `sharedAppGlue`.
## Required global CSS (every generated project)
Every consuming app that uses the Shidoka shell or page-level Foundation grid MUST have a global CSS file (e.g. `src/app.css`, `src/styles/global.css`, or the framework equivalent) that contains these baseline imports. Create or update that file when generating a new page or shell; do not omit them.
```css
@import '@kyndryl-design-system/shidoka-foundation/css/root.css';
@import '@kyndryl-design-system/shidoka-foundation/css/index.css';
@import '@kyndryl-design-system/shidoka-foundation/css/grid.css';
@import '@kyndryl-cto/shidoka-studio/styles/shell-base.css';
@import '@kyndryl-cto/shidoka-studio/styles/shell-overlays.css';
@import '@kyndryl-cto/shidoka-studio/styles/header-flyouts.css';
@import '@kyndryl-cto/shidoka-studio/styles/workspace-switcher.css';
/* Add only when using `kyn-widget-gridstack`: @import '@kyndryl-design-system/shidoka-applications/common/css/gridstack-shidoka.css'; */
/* Add when the shell includes local nav: @import '@kyndryl-cto/shidoka-studio/styles/shell-local-nav.css'; */
```
- Load this file from the app entry or root layout (e.g. `import '../app.css'` in the root layout, or in `main.ts` / `App.vue` / `_app.tsx`).
- Without `root.css` and `index.css`, tokens and typography break. Without `grid.css`, the `kd-grid` / `kd-grid__col--*` classes do not exist. Add `gridstack-shidoka.css` only when you intentionally use `kyn-widget-gridstack`.
- Shidoka Studio now ships capability-based shell bundles. Import the bundle(s) that match the shell features you are emitting instead of reauthoring the same shell CSS in every app.
- `shell-base.css` provides neutral shell/page glue; `shell-overlays.css` covers header, flyout, drawer, and modal stacking; `header-flyouts.css` covers console/services/flyout helper wrappers; `workspace-switcher.css` owns the CURRENT block and two-pane sizing; `shell-local-nav.css` is only needed when the shell includes local nav clearance behavior.
- For reduced shells, omit bundle imports for features that are not present. Example: a minimal header-only shell normally keeps `shell-base.css`, `shell-overlays.css`, and only the specific header helper bundles it actually uses.
- **In-repo fixture compatibility:** `consumer-fixtures/shared/shell-layout.css` now delegates to the published Studio bundles; external apps should import the package bundle paths directly rather than copying raw CSS into `app.css`.
## Downstream thought process rubric
- Good: identify only the minimum adapter facts first (framework, router, output file path, app entry, and global CSS location). Do not read local app entry/layout or existing page/layout files before the canonical payloads except to confirm those adapter facts.
- Good: then call all 7 Shidoka Studio generation tools before deeper repo exploration.
- Good: once those MCP payloads are loaded, stop using repo exploration to make design decisions. Move from canonical planning straight into framework translation and implementation.
- Good: do not frame local layout review as "replace or extend it cleanly" until the canonical shell/page structure is already fixed from the MCP payloads.
- Good: plan from `get_canonical_full_page_recipe` first, especially the shared-foundation-backed `pageSpec`, before falling back to long-form snippets.
- Good: use the MCP payloads as the design authority for shell structure, global switcher, workspace switcher, body-mode selection, chart defaults, and layout rules.
- Good: rely on component defaults, tokens, documented `cssProperties`, and documented `cssParts` before writing CSS.
- Good: inspect the consuming repo only for framework syntax, route/file placement, required app-level imports, and integration constraints.
- Good: translate the bundled canonical assets directly instead of re-deriving behavior from local examples.
- Bad: inspect existing local pages, layouts, generated routes, story files, or component source as design authority for a new page.
- Bad: write custom CSS against `kyn-*` internals or reskin component hosts when wrapper/pattern CSS or app-glue CSS would satisfy the requirement.
- Bad: investigate workspace-switcher or global-switcher behavior from the consuming repo instead of translating the canonical pattern assets.
- Bad: rediscover widget-grid, chart, footer, or local-nav behavior from local code when the MCP already defines the canonical structure.
- Bad: spend multiple exploration steps on repo structure after MCP context is already loaded. Once route/framework facts are known, move to generation.
- Bad: global switcher Services or Administration masonry with only circle-stroke icons and links—no visible red category headings—because `kyn-header-category` never received a real DOM `heading` attribute (especially React `heading={...}` without `setAttribute`).
- Bad: catalog or agent listing cards with a bottom row of three undifferentiated plain-text tokens for status, deployment, and type—users read that as broken ghost buttons; use tags/badges/status treatments and clear metadata hierarchy instead.
- Bad: **catalog** cards that **repeat the same description** twice, or add a **second tag row** that only duplicates the first row as **#hashtags**—that is redundant filler, not a richer layout.
- Bad: **success/checkmark** icons on **every** category/tag pill when those pills are **keywords** (not task completion); that reads like a broken checklist or stepper. Use neutral tags for taxonomy and **one** status treatment for lifecycle state.
- Bad: **Agent catalog** (or similar) pages that **omit search, filters, and sort** when the user prompt **explicitly** required those features—only a title + card grid is incomplete.
- Bad: **listing card** bodies with **no vertical `gap`** between description and status/badge (or only random margins on some children)—the badge reads **stuck** to the copy. **Right:** one flex column with **`gap: 1rem`** (or `1.5rem`) for the whole card body.
- Bad: desktop wizard or admin pages with full-width block buttons (e.g. `width: 100%` Back/Next) spanning the content column—use content-sized buttons or a horizontal action row unless the prompt targets mobile-only layouts.
- Bad: wizard “chimney” layout—a full-width horizontal stepper in `main` with the fields squeezed into a small centered `max-width` card and empty whitespace on both sides; keep stepper, body, and actions in one centered column (same `width: min(100%, 1536px)` rhythm).
- Bad: Back/Next pinned to the far left and right of the **viewport** (or placed in `kyn-footer`) instead of in an action row directly under the fields inside `main`; `space-between` belongs on the form column, not a full-bleed bar.
- Good: for setup / multi-step flows, follow the base wizard layout in page-template-builder §3b and full-page-required-snippets §6a — one centered column for title + `kyn-stepper` + fields + actions; no chimney card; wizard actions only in `main`.
- Bad: full-page single-column wizards with `vertical` on `kyn-stepper` stacked above the form—default **horizontal** stepper for that layout; reserve **vertical** for side-by-side (left rail + right body), modals, or explicit user request.
- Bad: wizard step navigation built from a **row of `kyn-badge`**, `kyn-tag`, tertiary buttons, or custom pill `div`s—those read as **metadata or filters** (and drift toward catalog-card patterns), not the design-system stepper. **Right:** `kyn-stepper` with one `kyn-stepper-item` per step.
- Bad: using **`stepperType="status"`** on `kyn-stepper` for ordinary registration/setup wizards with named steps—that Storybook mode is the **status/lifecycle** rail (icon circles), not the default numbered step rail. **Right:** omit `stepperType` or use the default/progress variant for typical wizards; reserve `status` only when the spec explicitly requires that rail.
## 6a. Setup / multi-step wizard (base layout)
**When to use:** Registration, deploy/configure flows, agent setup, or any **multi-step** screen with Back/Next (or Submit/Cancel).
### Use the design-system stepper, not badges
- **Right:** `kyn-stepper` containing one `kyn-stepper-item` per step (import from `@kyndryl-design-system/shidoka-applications`). Drive `current-index` / `currentIndex` and each item’s `step-state` from app state.
- **Wrong:** a horizontal row of **`kyn-badge`**, **`kyn-tag`**, plain ghost buttons, or hand-rolled flex “chips” for step labels. That mimics **catalog/metadata** treatments (page-template-builder §3e) and does **not** satisfy wizard navigation—it will not match Shidoka’s stepper behavior or visuals.
### `stepperType` (do not confuse modes)
- For **typical** named steps (e.g. Basics → Schema → Submit), **omit `stepperType`** or use the Storybook **default / progress** stepper so the rail matches ordinary multi-step flows.
- **`stepperType="status"`** is the **status/lifecycle** variant from Storybook (icon-based steps). Use it only when the product or prompt **explicitly** calls for that rail—not as a default for generic forms.
- **Do not** treat Storybook’s status stepper and a **badge row** as interchangeable; neither replaces **`kyn-stepper` + `kyn-stepper-item`** for standard wizards.
### Horizontal vs vertical
- **Default — horizontal:** single-column full-page wizard: `kyn-page-title` → horizontal `kyn-stepper` → fields → action row. Do **not** set `vertical` on `kyn-stepper` for that layout unless the prompt asks for vertical steps or a documented two-column split (left rail + right body).
**Minimal markup (bind indices/state in app code):**
```html
<kyn-stepper current-index="0">
  <kyn-stepper-item step-name="1" step-title="Basics" step-state="active"></kyn-stepper-item>
  <kyn-stepper-item step-name="2" step-title="Schema" step-state="inactive"></kyn-stepper-item>
  <!-- one kyn-stepper-item per step -->
</kyn-stepper>
```
## 1. Header and flyouts
- Use `kyn-header-nav` with `GlobalSwitcher.stories.js#JSONSwitcher` defaults. Treat the bundled structure as the canonical Slotted HTML / JSON pattern for generation.
- Use `global-switcher-scaffold.json` as the machine-readable scaffold for root sections, root icons, categories, and links. It is the packaged equivalent of `GlobalSwitcher.stories.js#JSONSwitcher`.
- The default global switcher sections are Favorites, Recently Viewed, Console, Services, Catalogs, Administration.
- `kyn-header-nav` is the left/global-nav child of `kyn-header`. In frameworks where slot assignment must be explicit, use `slot="left"` on `kyn-header-nav`. Do not invent `slot="nav"`.
- Do not set `auto-open-flyout` in consuming apps. The switcher should start closed so it does not block the page before the user opens it.
- Keep `appTitle` concise when present (default dashboard pages: `Dashboard`), and do not derive it from route/file labels such as `Dashboard1`.
- **Logo:** Unless otherwise specified, render the Kyndryl bridge logo (`bridge-logo-large.svg`) from @kyndryl-design-system/shidoka-foundation/assets/svg/ in the logo slot, with `--kyn-header-logo-width: 120px;`. render the asset inside a wrapper such as `<span slot="logo" style="--kyn-header-logo-width: 120px; display: inline-flex; align-items: center; width: var(--kyn-header-logo-width); max-width: 100%;">`; in consuming apps, prefer a normal asset import plus `<img src={bridgeLogo} ...>` / `<img :src="bridgeLogo" ...>` for the actual logo asset (`bridge-logo-large.svg` by default; same sizing treatment for approved Kyndryl masthead logo asset) with `display: block; width: 100%; max-width: 100%; height: auto;`; do not rely on the SVG intrinsic width, do not use raw inline SVG as the default logo treatment, and do not render plain text "kyndryl" / "Bridge".
- Visible headings are required in horizontal/tabbed and masonry flyouts.
- **Red category headers:** Every `kyn-header-category` in Console, Services, and Administration MUST have BOTH the `heading` attribute (e.g. `heading="Kyndryl Services"`) AND `<span slot="icon">` with circle-stroke.svg from shidoka-icons. Without both, the red category header text does not display.
- Root global-switcher sections must keep their approved inline icons. If a parent-nav row renders without its root icon, it is wrong.
- Canonical root icon assets are `Favorites` -> `recommend-filled.svg`, `Recently Viewed` -> `history.svg`, `Console` -> `console.svg`, `Services` -> `services.svg`, `Catalogs` -> `catalog-management.svg`, `Administration` -> `user-settings.svg`. Use those exact Shidoka icon assets rather than generic menu, chevron-only, or local app icons.
- Do not satisfy parent-nav icon requirements with plain text in `.icon-slot` such as `Recently`, `Console`, `Services`, `Catalogs`, or `Admin`, and do not use glyphs like `★` or `○` as substitutes. Those are regressions; use approved Shidoka icon assets.
- Unless the user explicitly provides custom nav JSON, preserve the bundled default scaffold exactly. Do not reduce the Services tabs, headed categories, or default links.
- Use the `heading` attribute on `kyn-header-category` and keep the `circle-stroke` placeholder icon in `slot="icon"`. This headed-category rule applies to layout modes `grouped-column`, `masonry`, `tabbed-masonry`.
- **Framework adapter rule:** `kyn-header-category` must end up with a real DOM `heading` attribute in any framework. If template syntax does not preserve it, reflect it after mount. Do not switch to fake heading text nodes or a `slot="heading"` workaround.
- **Regression symptom to fix directly:** If Services or Administration masonry shows circle icons plus links but no red heading labels, the DOM `heading` attribute is still missing. Do not work around it with plain text nodes; reflect the attribute on every headed category instead.
- React/custom-element adapter: if `heading={...}` on `kyn-header-category` does not yield a real DOM `heading` attribute, reflect it explicitly after mount (for example with a ref callback/effect calling `element.setAttribute('heading', heading)`).
- Svelte/Vue/custom-element adapter: same **DOM `heading` attribute** requirement—use a `use:` action, `$effect`, or `onMounted` + `setAttribute` on each headed `kyn-header-category` in masonry/tabbed flyouts or red category headers will not render.
- Never emit `<span slot="heading">...</span>`; that slot does not exist.
- Keep Favorites, Recently Viewed, and Catalogs populated instead of leaving them as empty top-level links.
- Console must use slot="links" content with top links plus categories. Default top links are `Bridge Home`, followed by headed categories `Dashboards` -> `All Dashboards`, `Actionable Insights`, `AIOps IT Health Indicators Dashboard`, `Business Console (legacy)`, `Business Service Insights (legacy)`.
- Services must use kyn-tabs with kyn-tab-panel and headed categories. Default tab examples: `Kyndryl Services`: `Applications, Data, & AI` -> `Business Intelligence`, `Storage Migration`, `Visualization, Exploration and Semantic Analytics`; `Cloud Services` -> `Assessment for Microsoft Azure Stack Hyper Converged Infrastructure`, `Private Cloud IaaS/PaaS`, `Rapid Assessments for Enterprise Sustainability`; `Core Enterprise & Z Cloud` -> `Application Management Services for IBM Z and IBM i`, `Managed Extended Cloud IaaS for IBM i on Skytap`, `Managed Extended Cloud IaaS for IBM Z (zCloud)`; `Digital Workplace` -> `Connected Experience`, `Digital Experience Management`, `Modern Device Management Services`; `Network & Edge` -> `Managed Network Services`; `Security & Resiliency` -> `Continuous Controls Monitoring & Management`, `Enterprise Security Compliance Management`, `Intelligent Recovery Service`, `Mass Recovery Model`, `Recovery Retainer Service`, `Security & Network Operations`, `Security Operations as a Platform`, `Sustainability Advisor`, `Vulnerability Management Service` | `Platform Services`: `Application & Business Services` -> `Application Modernization Intelligence`; `Change Management` -> `Guided Change Manager (legacy)`; `Cloud Management` -> `Container Cluster Management`, `FinOps & Cost Optimization Intelligence`; `Data Analytics` -> `Data Fabric`; `Discovery` -> `Discovered Data`, `Discovered Management`; `Inventory` -> `Applications & Resources (legacy)`, `Application Inventory`, `Infrastructure & Cloud Inventory (legacy)`, `Inventory Insights (legacy)`, `Location Dictionary (legacy)`, `Product Dictionary (legacy)`, `Tagging Compliance Report`, `Topology`, `Workstation Inventory (legacy)`; `Knowledge & AI` -> `Agentic AI Designer`, `Artificial Intelligence for IT Operations (legacy)`, `Bridge AI Assist Configuration`, `Knowledge Foundation`; `Provisioning Orchestration & Automation` -> `Actions (legacy)`, `Automation (legacy)`, `Scheduler (legacy)`, `Workflow Executions`; `Toolchain & Pipeline` -> `DevOps Intelligence`, `Machine Learning Operations Pipeline`, `Tool Chain Management`.
- Administration must use kyn-header-categories layout="masonry" with headed categories such as `Access Management` -> `Access Request Management System (ARMS)`, `Bridge Access Management`, `Service Access Management`; `Policy Service` -> `Policy Management (Bundles)`; `Provisioning Orchestration & Administration` -> `Orchestration Administration`; `Service Operations` -> `Auditing`, `Connections Management`, `Logging & Monitoring`, `Sunrise Insights Administration (legacy)`; `Tag Management` -> `AIOps Tagging (legacy)`, `Bridge Tag Management`.
- Do not replace these section skeletons with generic two-column link lists. The right-hand panel should visibly preserve headings, tabs, and masonry/category structure.
- If the Services flyout opens without a visible tab strip containing both `Kyndryl Services` and `Platform Services`, it is wrong.
- If the Services or Administration flyout is missing any bundled default categories or links when the user did not provide custom nav JSON, it is wrong.
- Do not read local story files to recover this pattern. Translate the bundled HTML reference below directly and treat it as more authoritative than higher-level summaries.
- When header composition needs CSS, keep it in wrapper/helper classes such as `.console-links-column`, `.console-links-category`, `.services-tabs-fill`, `.flyout-action-list`, `.user-flyout-card`, and `.ui-impl-switcher`. Do not style Shidoka component internals directly.
- `kyn-header-flyouts` belongs in the right/default slot of `kyn-header`. Do not add `slot="flyouts"`; if a framework requires explicit slotting, keep the flyouts in the component default slot.
## 1b. Complete global-switcher HTML reference (mirrors GlobalSwitcher.stories.js#JSONSwitcher)
This is the exact HTML structure the AI must translate into the target framework. Every section, category heading, icon slot, and nesting level is intentional. Do NOT simplify, flatten, omit category headings, or reduce the default tabs/categories/links when nav JSON is unspecified. Do not attempt to read the Storybook source file at generation time; use the structure below as the self-contained source of truth.
Use only approved icon assets from `@kyndryl-design-system/shidoka-icons`. Canonical root-section icon map: `Favorites` -> `recommend-filled.svg`, `Recently Viewed` -> `history.svg`, `Console` -> `console.svg`, `Services` -> `services.svg`, `Catalogs` -> `catalog-management.svg`, `Administration` -> `user-settings.svg`. Workspace/flyout icon map: trigger chevron -> `chevron-down.svg`, CURRENT status -> `checkmark-filled.svg`, account copy -> `copy.svg`, copied feedback -> `checkmark-filled.svg`. In the workspace switcher **CURRENT** block (account-meta-info), use **16×16** icons only: `shidoka-icons/svg/monochrome/16/checkmark-filled.svg` and `.../16/copy.svg` (inline or import so the checkmark and copy icons render at 16×16).
```html
<kyn-header-nav truncate-links>
  <!-- FAVORITES — simple section: kyn-header-category slot="links" (no heading needed for single-category simple sections) -->
  <kyn-header-link id="favorites" href="javascript:void(0)" hideSearch>
    <span><!-- recommend-filled.svg from @kyndryl-design-system/shidoka-icons --></span>
    Favorites
    <kyn-header-category slot="links">
      <kyn-header-link href="#"><span>Connections Management</span></kyn-header-link>
      <kyn-header-link href="#"><span>Discovered Data</span></kyn-header-link>
      <kyn-header-link href="#"><span>Visualization, Exploration and Semantic Analytics</span></kyn-header-link>
      <kyn-header-link href="#"><span>Topology</span></kyn-header-link>
      <kyn-header-link href="#"><span>Menu item five</span></kyn-header-link>
      <kyn-header-link href="#"><span>Menu item six</span></kyn-header-link>
      <kyn-header-link href="#"><span>Menu Item seven</span></kyn-header-link>
    </kyn-header-category>
  </kyn-header-link>
  <!-- RECENTLY VIEWED — simple section -->
  <kyn-header-link id="recently-viewed" href="javascript:void(0)" hideSearch>
    <span><!-- history.svg from @kyndryl-design-system/shidoka-icons --></span>
    Recently Viewed
    <kyn-header-category slot="links">
      <kyn-header-link href="#"><span>Topology</span></kyn-header-link>
      <kyn-header-link href="#"><span>Discovered Data</span></kyn-header-link>
      <kyn-header-link href="#"><span>Connections Management</span></kyn-header-link>
      <kyn-header-link href="#"><span>Sustainability Advisor</span></kyn-header-link>
      <kyn-header-link href="#"><span>Discovered Data</span></kyn-header-link>
      <kyn-header-link href="#"><span>Private Cloud IaaS/PaaS</span></kyn-header-link>
      <kyn-header-link href="#"><span>Mass Recovery Model</span></kyn-header-link>
      <kyn-header-link href="#"><span>Assessment for Microsoft Azure Stack Hyper Converged Infrastructure</span></kyn-header-link>
      <kyn-header-link href="#"><span>Private Cloud IaaS/PaaS</span></kyn-header-link>
      <kyn-header-link href="#"><span>Rapid Assessments for Enterprise Sustainability</span></kyn-header-link>
    </kyn-header-category>
  </kyn-header-link>
  <kyn-header-divider></kyn-header-divider>
  <!-- CONSOLE — single-column with top links + headed category -->
  <kyn-header-link id="console" href="javascript:void(0)" hideSearch>
    <span><!-- console.svg from @kyndryl-design-system/shidoka-icons --></span>
    Console
    <div slot="links" class="console-links-column">
      <kyn-header-link href="#"><span>Bridge Home</span></kyn-header-link>
      <kyn-header-category heading="Dashboards" class="console-links-category">
        <span slot="icon"><!-- circle-stroke.svg (16×16) from @kyndryl-design-system/shidoka-icons/svg/monochrome/16/ --></span>
        <kyn-header-link href="#"><span>All Dashboards</span></kyn-header-link>
        <kyn-header-link href="#"><span>Actionable Insights</span></kyn-header-link>
        <kyn-header-link href="#"><span>AIOps IT Health Indicators Dashboard</span></kyn-header-link>
        <kyn-header-link href="#"><span>Business Console (legacy)</span></kyn-header-link>
        <kyn-header-link href="#"><span>Business Service Insights (legacy)</span></kyn-header-link>
      </kyn-header-category>
    </div>
  </kyn-header-link>
  <!-- SERVICES — tabbed layout with masonry categories per tab -->
  <kyn-header-link id="services" href="javascript:void(0)">
    <span><!-- services.svg from @kyndryl-design-system/shidoka-icons --></span>
    Services
    <kyn-tabs tabSize="md" slot="links" class="services-tabs-fill">
      <kyn-tab slot="tabs" id="kyndryl" selected>Kyndryl Services</kyn-tab>
      <kyn-tab slot="tabs" id="platform">Platform Services</kyn-tab>
      <kyn-tab-panel tabId="kyndryl" noPadding visible>
        <kyn-header-categories layout="masonry" .limitRootLinks=${false}>
          <kyn-header-category heading="Applications, Data, & AI">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Business Intelligence</span></kyn-header-link>
            <kyn-header-link href="#"><span>Storage Migration</span></kyn-header-link>
            <kyn-header-link href="#"><span>Visualization, Exploration and Semantic Analytics</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Cloud Services">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Assessment for Microsoft Azure Stack Hyper Converged Infrastructure</span></kyn-header-link>
            <kyn-header-link href="#"><span>Private Cloud IaaS/PaaS</span></kyn-header-link>
            <kyn-header-link href="#"><span>Rapid Assessments for Enterprise Sustainability</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Core Enterprise & Z Cloud">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Application Management Services for IBM Z and IBM i</span></kyn-header-link>
            <kyn-header-link href="#"><span>Managed Extended Cloud IaaS for IBM i on Skytap</span></kyn-header-link>
            <kyn-header-link href="#"><span>Managed Extended Cloud IaaS for IBM Z (zCloud)</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Digital Workplace">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Connected Experience</span></kyn-header-link>
            <kyn-header-link href="#"><span>Digital Experience Management</span></kyn-header-link>
            <kyn-header-link href="#"><span>Modern Device Management Services</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Network & Edge">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Managed Network Services</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Security & Resiliency">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Continuous Controls Monitoring & Management</span></kyn-header-link>
            <kyn-header-link href="#"><span>Enterprise Security Compliance Management</span></kyn-header-link>
            <kyn-header-link href="#"><span>Intelligent Recovery Service</span></kyn-header-link>
            <kyn-header-link href="#"><span>Mass Recovery Model</span></kyn-header-link>
            <kyn-header-link href="#"><span>Recovery Retainer Service</span></kyn-header-link>
            <kyn-header-link href="#"><span>Security & Network Operations</span></kyn-header-link>
            <kyn-header-link href="#"><span>Security Operations as a Platform</span></kyn-header-link>
            <kyn-header-link href="#"><span>Sustainability Advisor</span></kyn-header-link>
            <kyn-header-link href="#"><span>Vulnerability Management Service</span></kyn-header-link>
          </kyn-header-category>
        </kyn-header-categories>
      </kyn-tab-panel>
      <kyn-tab-panel tabId="platform" noPadding>
        <kyn-header-categories layout="masonry" .limitRootLinks=${false}>
          <kyn-header-category heading="Application & Business Services">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Application Modernization Intelligence</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Change Management">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Guided Change Manager (legacy)</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Cloud Management">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Container Cluster Management</span></kyn-header-link>
            <kyn-header-link href="#"><span>FinOps & Cost Optimization Intelligence</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Data Analytics">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Data Fabric</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Discovery">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Discovered Data</span></kyn-header-link>
            <kyn-header-link href="#"><span>Discovered Management</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Inventory">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Applications & Resources (legacy)</span></kyn-header-link>
            <kyn-header-link href="#"><span>Application Inventory</span></kyn-header-link>
            <kyn-header-link href="#"><span>Infrastructure & Cloud Inventory (legacy)</span></kyn-header-link>
            <kyn-header-link href="#"><span>Inventory Insights (legacy)</span></kyn-header-link>
            <kyn-header-link href="#"><span>Location Dictionary (legacy)</span></kyn-header-link>
            <kyn-header-link href="#"><span>Product Dictionary (legacy)</span></kyn-header-link>
            <kyn-header-link href="#"><span>Tagging Compliance Report</span></kyn-header-link>
            <kyn-header-link href="#"><span>Topology</span></kyn-header-link>
            <kyn-header-link href="#"><span>Workstation Inventory (legacy)</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Knowledge & AI">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Agentic AI Designer</span></kyn-header-link>
            <kyn-header-link href="#"><span>Artificial Intelligence for IT Operations (legacy)</span></kyn-header-link>
            <kyn-header-link href="#"><span>Bridge AI Assist Configuration</span></kyn-header-link>
            <kyn-header-link href="#"><span>Knowledge Foundation</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Provisioning Orchestration & Automation">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Actions (legacy)</span></kyn-header-link>
            <kyn-header-link href="#"><span>Automation (legacy)</span></kyn-header-link>
            <kyn-header-link href="#"><span>Scheduler (legacy)</span></kyn-header-link>
            <kyn-header-link href="#"><span>Workflow Executions</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Toolchain & Pipeline">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>DevOps Intelligence</span></kyn-header-link>
            <kyn-header-link href="#"><span>Machine Learning Operations Pipeline</span></kyn-header-link>
            <kyn-header-link href="#"><span>Tool Chain Management</span></kyn-header-link>
          </kyn-header-category>
        </kyn-header-categories>
      </kyn-tab-panel>
    </kyn-tabs>
  </kyn-header-link>
  <!-- CATALOGS — simple section -->
  <kyn-header-link id="catalogs" href="javascript:void(0)" hideSearch>
    <span><!-- catalog-management.svg from @kyndryl-design-system/shidoka-icons --></span>
    Catalogs
    <kyn-header-category slot="links">
      <kyn-header-link href="#"><span>Bridge Private Catalog</span></kyn-header-link>
      <kyn-header-link href="#"><span>Bridge Service Catalog</span></kyn-header-link>
      <kyn-header-link href="#"><span>Enablement Catalog</span></kyn-header-link>
      <kyn-header-link href="#"><span>Orchestration Catalog</span></kyn-header-link>
    </kyn-header-category>
  </kyn-header-link>
  <!-- ADMINISTRATION — masonry layout with headed categories -->
  <kyn-header-link id="administration" href="javascript:void(0)" hideSearch>
    <span><!-- user-settings.svg from @kyndryl-design-system/shidoka-icons --></span>
    Administration
    <kyn-header-categories slot="links" layout="masonry" maxColumns="2" .limitRootLinks=${false}>
      <kyn-header-category heading="Access Management">
        <span slot="icon"><!-- circle-stroke icon SVG --></span>
        <kyn-header-link href="#"><span>Access Request Management System (ARMS)</span></kyn-header-link>
        <kyn-header-link href="#"><span>Bridge Access Management</span></kyn-header-link>
        <kyn-header-link href="#"><span>Service Access Management</span></kyn-header-link>
      </kyn-header-category>
      <kyn-header-category heading="Policy Service">
        <span slot="icon"><!-- circle-stroke icon SVG --></span>
        <kyn-header-link href="#"><span>Policy Management (Bundles)</span></kyn-header-link>
      </kyn-header-category>
      <kyn-header-category heading="Provisioning Orchestration & Administration">
        <span slot="icon"><!-- circle-stroke icon SVG --></span>
        <kyn-header-link href="#"><span>Orchestration Administration</span></kyn-header-link>
      </kyn-header-category>
      <kyn-header-category heading="Service Operations">
        <span slot="icon"><!-- circle-stroke icon SVG --></span>
        <kyn-header-link href="#"><span>Auditing</span></kyn-header-link>
        <kyn-header-link href="#"><span>Connections Management</span></kyn-header-link>
        <kyn-header-link href="#"><span>Logging & Monitoring</span></kyn-header-link>
        <kyn-header-link href="#"><span>Sunrise Insights Administration (legacy)</span></kyn-header-link>
      </kyn-header-category>
      <kyn-header-category heading="Tag Management">
        <span slot="icon"><!-- circle-stroke icon SVG --></span>
        <kyn-header-link href="#"><span>AIOps Tagging (legacy)</span></kyn-header-link>
        <kyn-header-link href="#"><span>Bridge Tag Management</span></kyn-header-link>
      </kyn-header-category>
    </kyn-header-categories>
  </kyn-header-link>
</kyn-header-nav>
```
**Key structural rules from this pattern:**
- **Simple sections** (Favorites, Recently Viewed, Catalogs): `kyn-header-category slot="links"` as a direct child of `kyn-header-link`. No `heading` attribute needed for single-category simple sections.
- **Headed categories / red category headers** (Console, Services, Administration): To get the red category header text to display, each `kyn-header-category` MUST have BOTH (1) the `heading` attribute (e.g. `heading="Kyndryl Services"`) AND (2) `<span slot="icon">` with circle-stroke.svg from @kyndryl-design-system/shidoka-icons. If either is missing, the red categorical header does not display.
- **Framework adapter rule:** Lit reads the **DOM `heading` attribute**. If `heading="…"` / `:heading` / `{heading}` does not produce a real attribute on the element, **reflect it after mount** (`element.setAttribute('heading', heading)`) for every headed category in Console, Services, and Administration. The visible red heading depends on the DOM attribute, not just framework syntax.
- **React implementation preference:** In React consuming apps, do not render headed categories as raw `<kyn-header-category heading={category.heading}>...</kyn-header-category>` and assume the DOM attribute will survive. Use a tiny wrapper/helper that always reflects the `heading` DOM attribute on mount/ref for every masonry/tabbed headed category.
- **Svelte / Vue implementation preference:** In Svelte, use a `use:` action or `$effect` + `bind:this`; in Vue, use `onMounted` + template ref or a small wrapper component. Every masonry/tabbed headed category must keep a real DOM `heading` attribute or the red category header will not render.
**React — paste this wrapper (required if red headings are missing):** Lit reads the **`heading` DOM attribute**; React’s `heading={...}` prop often never sets it. Use one wrapper for all headed categories:
```tsx
import { useLayoutEffect, useRef, type ReactNode } from 'react';
export function HeadedHeaderCategory({
  heading,
  className,
  children,
}: {
  heading: string;
  className?: string;
  children: ReactNode;
}) {
  const ref = useRef<HTMLElement | null>(null);
  useLayoutEffect(() => {
    ref.current?.setAttribute('heading', heading);
  }, [heading]);
  return (
    <kyn-header-category ref={ref} className={className}>
      {children}
    </kyn-header-category>
  );
}
```
Then render Services/Administration/Console categories as `<HeadedHeaderCategory heading="…"><span slot="icon">…circle-stroke…</span>…links…</HeadedHeaderCategory>` instead of raw `<kyn-header-category heading={…}>`.
**Svelte — use this action for headed categories when needed:** If template binding does not leave a real DOM `heading` attribute, reflect it with a `use:` action:
```svelte
function reflectHeading(node, heading) {
  const apply = (value) => {
    if (value != null && value !== '') node.setAttribute('heading', String(value));
    else node.removeAttribute('heading');
  };
  apply(heading);
  return {
    update(nextHeading) {
      apply(nextHeading);
    },
  };
}
```
Then render Services/Administration/Console categories as `<kyn-header-category use:reflectHeading={category.heading}>...</kyn-header-category>` while still keeping `<span slot="icon">…circle-stroke…</span>` inside each category.
- **Category heading icon = circle-stroke SVG only.** For every headed category, `slot="icon"` must contain the **circle-stroke** icon from `@kyndryl-design-system/shidoka-icons/svg/monochrome/16/circle-stroke.svg` rendered from an imported package asset (16×16). **WRONG:** A bullet character (•), a dash, or any text glyph in `slot="icon"` — that produces a bullet instead of the placeholder circle. **WRONG:** Empty `<span slot="icon"></span>` — the component may fall back to a bullet. **WRONG:** `const CIRCLE_ICON = '<svg ...>'`. **CORRECT:** Import circle-stroke.svg from the package and render its SVG markup inside `<span slot="icon">` so the design-system placeholder circle appears next to the red category heading.
- **Console** uses a `div slot="links"` wrapper for single-column layout with top links and a headed category below.
- **Services** uses `kyn-tabs` + `kyn-tab-panel` + `kyn-header-categories layout="masonry"` inside each panel.
- **Administration** uses `kyn-header-categories slot="links" layout="masonry" maxColumns="2"` directly.
- **Do not normalize canonical root sections through one generic renderer.** Console, Services, Catalogs, and Administration have different required DOM shapes; a single generic category/section renderer must not erase those section-specific structures.
- **Acceptance check — Services:** the Services flyout must render a visible tab strip with `Kyndryl Services` and `Platform Services`, and each tab panel must contain masonry headed categories. If Services degrades into a flat list, a single cluster, or a generic category wrapper, it is wrong.
- **Acceptance check — categorical cluster dividers:** the last or only categorical menu cluster in a flyout must not render a trailing divider/border below it. Treat an extra divider under the final Console/Services/Administration cluster as a regression.
- **Icons** use `<span slot="icon">` with inline SVG, NOT `<kd-icon>`. Import icons from `@kyndryl-design-system/shidoka-icons` (or an official Shidoka re-export surface already provided by the consuming app) and never substitute lucide, heroicons, font-awesome, emoji, text glyphs, copied `<svg>` string constants, or custom SVGs.
- **Inline SVG rendering rule:** render approved Shidoka SVG assets inline so they can inherit `currentColor`, but do not globally force both `fill` and `stroke` on those SVGs. Preserve each asset's authored drawing model so icons do not render heavier than designed.
- **Canonical root icon assets:** `Favorites` -> `recommend-filled.svg`, `Recently Viewed` -> `history.svg`, `Console` -> `console.svg`, `Services` -> `services.svg`, `Catalogs` -> `catalog-management.svg`, `Administration` -> `user-settings.svg`.
- **Wrong root-icon treatment:** text placeholders such as `Recently`, `Services`, `Console`, `Admin`, or glyphs like `★` / `○` inside `.icon-slot`. **Correct:** inline/import the matching Shidoka SVG asset for each root section.
- **WRONG:** Links directly inside `slot="links"` without `kyn-header-category` — no grouping or headings. **WRONG:** `<kd-icon>` instead of `<span slot="icon">`. **WRONG:** `<span slot="heading">` — that slot does not exist. **WRONG:** Missing `heading` attribute on `kyn-header-category` in sections that need red headers. **WRONG:** Reducing the default Services or Administration scaffold to fewer categories/links than the bundled reference when the user did not provide custom nav JSON.
Pattern-layout helper CSS:
```css
.console-links-column {
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.console-links-category {
  margin-top: 8px;
}
.services-tabs-fill {
  width: 100%;
  max-width: none;
}
```
## 2. hideMenuLabel where the DS runtime uses it
- Keep `hideMenuLabel` on the workspace, notifications, and user flyouts. The Help flyout is the current DS runtime exception: when Help itself opens on mobile, its panel label remains visible.
- **Mobile flyout labels are required:** set a concise `label` on every `kyn-header-flyout` so the mobile overflow menu renders named top-level rows instead of blank icon-only entries. Default labels: `Workspaces`, `Notifications`, `Help`, `User Profile`.
- Treat that `label` as **mobile-overflow metadata only**. Do not replace, restyle, or remove the desktop `slot="button"` trigger because desktop rendering must remain driven by the existing workspace name + chevron or icon-only trigger.
- Keep `hideMenuLabel` on the panel only where the canonical DS runtime actually hides the panel label. The `label` still drives the mobile overflow menu entry for every flyout.
- **Right-side flyout trigger buttons (notifications, help, user) MUST use these exact Shidoka icon assets from `@kyndryl-design-system/shidoka-icons`:** `notification.svg`, `information.svg`, `user.svg`. Import those package assets and render the SVG markup inline in `slot="button"` (20×20), and keep the user trigger icon visibly rendered in the header even when the flyout panel uses a simpler placeholder treatment. **WRONG:** Generic bell, i-in-circle, person-silhouette substitutions, blank outlined squares/circles in place of the actual trigger icon, lucide/heroicons/font-awesome, hand-drawn inline SVG, any icon not from the Shidoka icon library, plain text inside `.icon-slot`, or pasted `<svg>` string constants.
- Vue: `:hideMenuLabel="true"`
- React: `hideMenuLabel={true}` (never `hide-menu-label` in React JSX)
- Lit/HTML: `hide-menu-label`
- Do not generate ref + onMounted workarounds or `.menu-label` CSS.
- Interactive icons in these flyouts must come from `@kyndryl-design-system/shidoka-icons`, rendered inline from imported package assets. Do not use random SVGs, lucide, heroicons, font-awesome, emoji, text glyphs, pasted `<svg>` string literals, or icons outside the Shidoka icon library.
- React/Vite example: `import notificationIconSvg from '@kyndryl-design-system/shidoka-icons/svg/monochrome/20/notification.svg?raw'` then render that imported markup inline in `slot="button"`. Do not replace that with `const NOTIFICATION_ICON = '<svg ...>'`.
- Do not satisfy these icon requirements by drawing a new local SVG component or by copying package SVG source into a local constant. Use approved package assets from `@kyndryl-design-system/shidoka-icons`, ideally imported raw/inlined in consuming apps.
- Notifications and help should render as compact action menus, not large mostly-empty panels with a single word or single link.
- Keep notifications and help inside one grouped action-list wrapper each. Do not emit bare text nodes, one-word-per-line fragments, or unwrapped loose links inside the flyout panel.
- Default notifications actions: `Notification center`, `Alert preferences`, `Mark all as read`.
- Default help actions: `Documentation`, `Support`, `Release notes`.
- Default user actions: `Profile settings`, `Account settings`, `Sign out` plus the centered profile block.
- Keep the user flyout as one `user-flyout-card`: centered `kyn-header-user-profile` first, then one grouped action list containing all user actions. Do not split `Sign out` into a separate trailing link outside the main action list.
- The user profile block must include a visible centered avatar/placeholder above the user text. When no real photo is provided, a simple 56px circular placeholder is acceptable by default; only add a larger inner user glyph when the prompt explicitly asks for it or when a consuming app wants that richer treatment.
- If a user flyout renders `Profile settings`, `Account settings`, or `Sign out` without `kyn-header-user-profile`, it is wrong. The default user flyout is profile-block-plus-actions, not actions-only.
- In Svelte 5, prefer event attributes for custom-element and DOM events: `onon-flyout-toggle`, `onon-click`, `onclick`, and `onkeydown`. Legacy directive forms such as `on:on-flyout-toggle`, `on:on-click`, `on:click`, and `on:keydown` now emit deprecation warnings. Wrong: malformed names like `onflyout-toggle`, `on-flyout-toggle`, or `on-click`, or omitting handlers so workspace/account items are not clickable.
Required right-side flyout skeleton:
```html
<kyn-header-flyout label="Notifications" hide-menu-label>
  <span slot="button"><!-- notification.svg from @kyndryl-design-system/shidoka-icons (20×20) --></span>
  <div class="flyout-action-list">
    <kyn-header-link href="#"><span>Notification center</span></kyn-header-link>
    <kyn-header-link href="#"><span>Alert preferences</span></kyn-header-link>
    <kyn-header-link href="#"><span>Mark all as read</span></kyn-header-link>
  </div>
</kyn-header-flyout>
<kyn-header-flyout label="Help">
  <span slot="button"><!-- information.svg from @kyndryl-design-system/shidoka-icons (20×20) — help/info flyout --></span>
  <div class="flyout-action-list">
    <kyn-header-link href="#"><span>Documentation</span></kyn-header-link>
    <kyn-header-link href="#"><span>Support</span></kyn-header-link>
    <kyn-header-link href="#"><span>Release notes</span></kyn-header-link>
  </div>
</kyn-header-flyout>
<kyn-header-flyout label="User Profile" hide-menu-label>
  <span slot="button"><!-- user.svg from @kyndryl-design-system/shidoka-icons (20×20) --></span>
  <div class="user-flyout-card">
    <kyn-header-user-profile name="Jordan Lee" subtitle="Platform Operations Lead" email="jordan.lee@kyndryl.com" profileLink="#" profileLinkText="View profile">
      <span class="user-profile-placeholder" aria-hidden="true"></span>
    </kyn-header-user-profile>
    <div class="flyout-action-list">
      <kyn-header-link href="#"><span>Profile settings</span></kyn-header-link>
      <kyn-header-link href="#"><span>Account settings</span></kyn-header-link>
      <kyn-header-link href="#"><span>Sign out</span></kyn-header-link>
    </div>
  </div>
</kyn-header-flyout>
```
Right-side flyout panel CSS (all frameworks — required so "Profile settings" etc. stay on one line):
```css
.flyout-action-list {
  min-width: 280px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 8px 0;
  box-sizing: border-box;
}
.flyout-action-list kyn-header-link span {
  white-space: nowrap;
}
.user-flyout-card {
  min-width: 280px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  box-sizing: border-box;
}
.user-profile-placeholder {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 56px;
  height: 56px;
  border-radius: 50%;
  border: 3px solid var(--kd-color-border-variants-brand);
}
.user-profile-placeholder svg {
  display: block;
  width: 32px;
  height: 32px;
}
.user-flyout-card .flyout-action-list {
  align-items: stretch;
  text-align: left;
}
.user-flyout-card .flyout-action-list kyn-header-link {
  width: 100%;
}
```
## 3. Workspace switcher CURRENT meta info
- Use the packaged workspace-switcher pattern asset `workspace-switcher.pattern.json` as the structured source for trigger markup, CURRENT data, copy feedback, and selection wiring. This is the normalized equivalent of `workspaceSwitcher.stories.js#UIImplementation`.
- Set the workspace flyout `label` to `Workspaces` so the mobile overflow menu preserves the canonical top-level IA while the desktop trigger continues to show the selected account name + chevron in `slot="button"`.
- Preserve the canonical `CURRENT` block instead of collapsing it to a name-only stack.
- Replicate the `workspaceSwitcher.stories.js#UIImplementation` CURRENT section exactly: `.account-meta-info` -> `.account-meta-info__header` -> `.account-meta-info__checkmark` + `.account-meta-info__content` -> `.account-meta-info__name`, copyable account ID `kyn-link`, and `.account-meta-info__country`.
- If `kyn-workspace-switcher` is present but no `.account-meta-info` block is rendered in `slot="left"`, it is wrong. The default workspace switcher must ship with visible account info on first render.
- The account ID should be rendered as a copyable account ID link, not a plain text row or decorative badge.
- **Trigger icon separation is required:** keep `chevron-down.svg` only for `.account-chevron` in the workspace trigger, and keep `copy.svg` / copied-state `checkmark-filled.svg` only inside the account ID `kyn-link`. Do not reuse the copy affordance icon as the flyout trigger icon.
- Do not substitute text glyphs for the `CURRENT` icons. Wrong: `<span class="account-meta-info__checkmark">✓</span>` or `<span slot="icon">⎘</span>`. Correct: imported Shidoka package icons rendered inline at 16×16 for both the status marker and copy affordance.
- Enforce two-pane sizing exactly: add class `ui-impl-switcher` on the switcher host, keep desktop width `625px` (minimum `625px`), keep `--kyn-workspace-switcher-left-panel-width: 275px`, and keep `--kyn-workspace-switcher-max-height: 70vh` on the element.
- Put the desktop sizing on the host element itself, not only in CSS. In React, include `width: '625px'` and `minWidth: '625px'` in the `style={{ ... }}` object on `kyn-workspace-switcher` alongside the CSS variables.
- Do not set a fixed host height. The left pane drives container height by design; the right pane should match that height and scroll independently.
- When a workspace or account item is selected, always use the item display name, never the raw id, when updating the trigger label and `.account-meta-info__name`.
- The trigger label and CURRENT block must reflect the selected account in the active right pane, not the selected workspace label. A workspace name like `Compute Zones` should not replace the account name in CURRENT unless it is itself an account item.
- When the workspace list includes an aggregate option such as `All` or `Global Zone (All)`, treat it as the union of the underlying workspace account lists by default. Do not model the aggregate row as an unrelated sibling workspace with its own isolated right-pane data unless the prompt or supplied data explicitly says otherwise.
- On first render, both workspace columns must already be populated. Default left-list examples: `Global Zone (All)`, `Account Tenants`, `Compute Zones`. Default right-list examples: `North America tenant`, `EMEA tenant`, `APAC tenant`.
- If `kyn-workspace-switcher` is emitted without `slot="left"`, `slot="left-list"`, and `slot="right-list"` children already present in the generated code, it is wrong.
- If only `slot="left"` and `slot="left-list"` are present, the workspace switcher will appear single-pane even on desktop. Emit initial `slot="right-list"` account items in the first render, not only after a later click.
- **Svelte event wiring (required for clicks to work):** Wire workspace flyout and menu-item clicks so left-list (workspace) and right-list (account) are both selectable. In Svelte 5, use event attributes: `onon-flyout-toggle`, `onon-click`, `onclick`, and `onkeydown`. Apply the flyout toggle handler on the flyout and click handlers on each `kyn-workspace-switcher-menu-item` or on the parent `kyn-workspace-switcher` with a single handler that reads `event.detail.value` and calls `selectWorkspace(value)` or `selectAccount(value)`. For the account ID `kyn-link`, keep `onclick` and `onkeydown` (Enter/Space). Set `data-copy-state={copiedAccountId ? 'copied' : 'idle'}` and swap the icon slot to checkmark when copied. The older directive forms (`on:on-flyout-toggle`, `on:on-click`, `on:click`, `on:keydown`) still compile but now emit Svelte 5 deprecation warnings. Without correct event wiring, left-list workspace items and right-list account items are not clickable.
- **React event + boolean wiring (required for clicks and selection state):** React does not map custom events from Lit components. The menu items emit a custom event named `on-click` (not the native `click`). You **must** use a ref on `kyn-workspace-switcher` and in `useEffect` call `switcherRef.current.addEventListener('on-click', handler)`. In the handler, read `event.detail?.value` and `event.target` (e.g. `event.target.getAttribute('slot')`): if slot is `left-list` call `setSelectedWorkspaceId(value)` and replace the active right-list account array from a workspace-to-accounts data map; do not keep one static `slot="right-list"` list for every workspace. When the workspace changes, also reset `selectedAccountId` to a valid account from that newly selected workspace before the next render. If slot is `right-list`, call `setSelectedAccountId(value)` and update trigger/CURRENT from the selected account record. For the flyout chevron use a ref on the first `kyn-header-flyout` and `addEventListener('on-flyout-toggle', (e) => { chevronRef.current.style.transform = e.detail?.open ? 'rotate(180deg)' : 'rotate(0deg)'; })`. For the account ID copy use native `onClick` on the `kyn-link` (or a ref + `addEventListener('click', copyHandler)`). **Initial render requirement:** derive the initial right-list array from the selected default workspace before the first render so the switcher opens with both panes populated; do not wait for a click before rendering the account list. **Selection booleans:** do not rely on `selected={condition}` for custom elements in React because non-selected rows can still render as `selected="false"` (attribute present), which Lit treats as selected. For non-selected rows, omit the attribute/property entirely. Use a conditional spread pattern like `{...(isSelected ? { selected: true } : {})}` and likewise for `favorited` / `showFavorite` when needed. **Host/class/style syntax:** in React use `className="ui-impl-switcher"` (not CSS-module-local class names) and set switcher inline CSS vars with a style object. Also put the desktop host sizing directly on the element with `width: '625px'` and `minWidth: '625px'`; do not rely only on a CSS class for the two-pane width contract. Keep the matching `.ui-impl-switcher` width rules in app-level global CSS, not a CSS module. **React keys:** never use bare display labels as list keys (canonical nav data intentionally includes repeated labels like `Private Cloud IaaS/PaaS`). Use unique ids when available, otherwise compose keys with section/tab/category context plus index (for example `${sectionId}-${tabId ?? "default"}-${categoryIndex}-${linkIndex}`). **Avoid change-in-update warnings:** do not imperatively set `kyn-header-nav`/`kyn-header-link` properties during every render cycle; keep nav data memoized and pass props declaratively, or set imperative properties once in a guarded mount effect.
Required workspace-switcher slot skeleton:
```html
<kyn-workspace-switcher id="workspace-switcher" class="ui-impl-switcher" style="width: 625px; min-width: 625px; --kyn-workspace-switcher-left-panel-width: 275px; --kyn-workspace-switcher-max-height: 70vh;">
  <div slot="left" class="account-meta-info">
    <div class="account-meta-info__header">
      <span class="account-meta-info__checkmark"><!-- checkmark-filled.svg (16×16, monochrome/16/) from @kyndryl-design-system/shidoka-icons --></span>
      <div class="account-meta-info__content">
        <span class="account-meta-info__name">North America tenant</span>
        <kyn-link standalone animationInactive="true" href="#">023497uw02399023509<span slot="icon"><!-- copy.svg (16×16, monochrome/16/) from @kyndryl-design-system/shidoka-icons --></span></kyn-link>
        <span class="account-meta-info__country">United States</span>
      </div>
    </div>
  </div>
  <kyn-workspace-switcher-menu-item slot="left-list" variant="workspace" value="workspace-0" name="Global Zone (All)" count="2"></kyn-workspace-switcher-menu-item>
  <kyn-workspace-switcher-menu-item slot="left-list" variant="workspace" value="workspace-1" name="Account Tenants" count="3" selected></kyn-workspace-switcher-menu-item>
  <kyn-workspace-switcher-menu-item slot="left-list" variant="workspace" value="workspace-2" name="Compute Zones" count="4"></kyn-workspace-switcher-menu-item>
  <kyn-workspace-switcher-menu-item slot="right-list" variant="item" value="account-0" name="North America tenant" selected showFavorite favorited></kyn-workspace-switcher-menu-item>
  <kyn-workspace-switcher-menu-item slot="right-list" variant="item" value="account-1" name="EMEA tenant" showFavorite favorited></kyn-workspace-switcher-menu-item>
  <kyn-workspace-switcher-menu-item slot="right-list" variant="item" value="account-2" name="APAC tenant" showFavorite favorited></kyn-workspace-switcher-menu-item>
</kyn-workspace-switcher>
```
## 4. Workspace switcher CSS
- The trigger label must truncate while the chevron stays fixed-size. That is why `.account-name` uses ellipsis and `.account-chevron` uses `flex-shrink: 0`.
- Keep the workspace switcher as a direct child of the flyout so the panel does not gain extra top padding above CURRENT.
- Mirror the pattern/workspace story CSS for CURRENT exactly instead of approximating it.
- Prefer importing the Studio-managed bundles `@kyndryl-cto/shidoka-studio/styles/header-flyouts.css` and `@kyndryl-cto/shidoka-studio/styles/workspace-switcher.css` in app global CSS instead of reauthoring these selectors in every app.
- If the same header shell also includes drawer, modal, or flyout stacking reinforcement, import `@kyndryl-cto/shidoka-studio/styles/shell-overlays.css` in that same stylesheet instead of adding page-local z-index patches.
```css
@import '@kyndryl-cto/shidoka-studio/styles/header-flyouts.css';
@import '@kyndryl-cto/shidoka-studio/styles/workspace-switcher.css';
/* Add when this shell also needs overlay stacking glue: @import '@kyndryl-cto/shidoka-studio/styles/shell-overlays.css'; */
```
Fallback reference block (use only when a workspace cannot import the Studio bundle directly):
```css
.account-meta-info {
  display: flex;
  flex-direction: column;
  gap: 2px;
  margin: 0 auto 12px;
}
.account-meta-info__header {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  font-size: 14px;
}
.account-meta-info__checkmark {
  display: flex;
  align-items: center;
  flex-shrink: 0;
  margin-top: 4px;
  color: var(--kd-color-badge-heavy-background-success);
}
.account-meta-info__content {
  display: flex;
  flex-direction: column;
}
.account-meta-info__name {
  max-width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 500;
  font-size: 14px;
  line-height: 20px;
  color: var(--kd-color-text-level-primary);
}
.account-meta-info__country {
  font-size: 14px;
  line-height: 20px;
  color: var(--kd-color-text-level-primary);
}
.account-name {
  max-width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  min-width: 0;
  color: inherit;
}
.account-chevron {
  display: flex;
  flex-shrink: 0;
  align-items: center;
  transition: transform 0.2s;
  color: inherit;
}
.ui-impl-switcher {
  width: 625px;
  min-width: 625px;
  --kyn-workspace-switcher-left-panel-width: 275px;
}
@media (max-width: 831px) {
  .ui-impl-switcher {
    max-width: 375px;
    min-width: 0;
  }
}
@media (max-width: 671px) {
  .ui-impl-switcher {
    width: 100%;
    max-width: none;
    min-width: 0;
  }
}
```
The workspace switcher has two panes (left: CURRENT + workspace list; right: account list). Keep desktop width at 625px (minimum 625px) and keep `--kyn-workspace-switcher-left-panel-width: 275px` so both panes remain visible. If desktop width or the left-panel-width host variable is omitted, the right pane can disappear and only the left pane renders. Keep this rule on the host element itself and in app global CSS across Vue, React, Svelte, and Lit.
Use pixel breakpoints for collapse behavior (`831px` and `671px`) so root font-size changes do not accidentally force one-pane mode on desktop widths.
## 4b. Shell layering in consuming apps
- If a consuming app needs to reinforce `kyn-header`, `kyn-local-nav`, or flyout panel stacking/backgrounds, prefer importing `@kyndryl-cto/shidoka-studio/styles/shell-overlays.css` in one app-level global stylesheet such as `src/app.css`.
- Do not generate page-scoped host overrides like `:global(kyn-header) { z-index: ... }` or `:global(kyn-local-nav) { background: ... }` inside a single page component. Those can create fragile stacking contexts that fight the design system overlay/panel stack.
- In Svelte consuming apps, custom elements upgrade asynchronously after mount. Avoid repeated `$effect` loops that keep writing shell-related custom-element properties during render; if a property truly must be set programmatically, do it after mount and then update it from explicit handlers.
## 5. Workspace-switcher canonical asset
- Structured asset: `workspace-switcher.pattern.json`. Use it as the machine-readable source for trigger markup, CURRENT classes, default data, and interaction wiring.
- Upstream reference: `workspaceSwitcher.stories.js#UIImplementation`.
- The account ID link must both copy the selected account number and reflect the copied state after click.
Default workspace data:
```json
{
  "defaultWorkspaces": [
    {
      "id": "workspace-0",
      "name": "Global Zone (All)",
      "count": 2
    },
    {
      "id": "workspace-1",
      "name": "Account Tenants",
      "count": 3,
      "selected": true
    },
    {
      "id": "workspace-2",
      "name": "Compute Zones",
      "count": 4
    }
  ],
  "defaultItems": [
    {
      "id": "account-0",
      "name": "North America tenant",
      "accountNumber": "023497uw02399023509",
      "country": "United States",
      "selected": true,
      "favorited": true
    },
    {
      "id": "account-1",
      "name": "EMEA tenant",
      "accountNumber": "135791ea03588011224",
      "country": "Germany",
      "favorited": true
    },
    {
      "id": "account-2",
      "name": "APAC tenant",
      "accountNumber": "880044ap09113456781",
      "country": "Singapore",
      "favorited": true
    }
  ]
}
```
Required copy handler:
```js
const handleCopy = async (value, e) => {
  e?.preventDefault?.();
  const target = e?.currentTarget ?? e?.target ?? null;
  await navigator.clipboard.writeText(value);
  if (!target) return;
  target.setAttribute('data-copy-state', 'copied');
  const iconSpan = target.querySelector('[slot="icon"]');
  if (iconSpan) {
    iconSpan.innerHTML = copiedIcon;
  }
  setTimeout(() => {
    target.setAttribute('data-copy-state', 'idle');
    if (iconSpan) {
      iconSpan.innerHTML = copyIcon;
    }
  }, 3000);
};
```
Required chevron handler:
```js
const handleFlyoutToggle = (e) => {
  const chevron = e.currentTarget?.querySelector('.account-chevron');
  if (chevron) {
    chevron.style.transform = e.detail?.open ? 'rotate(180deg)' : 'rotate(0deg)';
  }
};
```
Required selection sync helper:
```js
const syncWorkspaceSelection = ({ triggerLabelEl, currentNameEl, currentCountryEl, accountLinkEl, nextItem }) => {
  triggerLabelEl.textContent = nextItem.name;
  currentNameEl.textContent = nextItem.name;
  currentCountryEl.textContent = nextItem.country;
  accountLinkEl.childNodes[0].textContent = nextItem.accountNumber;
  accountLinkEl.dataset.accountNumber = nextItem.accountNumber;
};
```
## 6. Widget-grid canonical asset
- Structured asset: `widget-grid.pattern.json`. Use it as the machine-readable source for widget-grid markup, Gridstack config, and chart presets.
Canonical Gridstack config:
```json
{
  "handle": "kyn-widget-drag-handle",
  "margin": 24,
  "animate": false,
  "columnOpts": {
    "breakpointForWindow": true,
    "breakpoints": [
      {
        "w": 671,
        "c": 4
      },
      {
        "w": 1183,
        "c": 8
      }
    ]
  },
  "cellHeight": 420,
  "staticGrid": true,
  "disableDrag": true,
  "disableResize": true
}
```
Default widget presets:
```json
[
  {
    "title": "Revenue trend",
    "subtitle": "Monthly revenue over the last 12 months",
    "chartTitle": "Revenue trend",
    "type": "line",
    "labels": [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun"
    ],
    "datasets": [
      {
        "label": "Dataset 1",
        "data": [
          12,
          18,
          16,
          22,
          26,
          24
        ]
      },
      {
        "label": "Dataset 2",
        "data": [
          9,
          14,
          15,
          18,
          21,
          20
        ]
      }
    ]
  },
  {
    "title": "Usage by region",
    "subtitle": "Active users by region",
    "chartTitle": "Usage by region",
    "type": "bar",
    "labels": [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun"
    ],
    "datasets": [
      {
        "label": "Dataset 1",
        "data": [
          20,
          35,
          30,
          45,
          40,
          50
        ]
      },
      {
        "label": "Dataset 2",
        "data": [
          14,
          28,
          25,
          38,
          35,
          42
        ]
      }
    ]
  },
  {
    "title": "Response times",
    "subtitle": "P95 latency by week",
    "chartTitle": "Response times",
    "type": "line",
    "labels": [
      "W1",
      "W2",
      "W3",
      "W4",
      "W5",
      "W6"
    ],
    "datasets": [
      {
        "label": "Dataset 1",
        "data": [
          220,
          205,
          210,
          198,
          202,
          190
        ]
      },
      {
        "label": "Dataset 2",
        "data": [
          180,
          176,
          170,
          172,
          168,
          160
        ]
      }
    ]
  },
  {
    "title": "Capacity",
    "subtitle": "Storage and compute utilization",
    "chartTitle": "Capacity",
    "type": "bar",
    "labels": [
      "A",
      "B",
      "C",
      "D",
      "E",
      "F"
    ],
    "datasets": [
      {
        "label": "Dataset 1",
        "data": [
          72,
          68,
          64,
          78,
          75,
          70
        ]
      },
      {
        "label": "Dataset 2",
        "data": [
          62,
          60,
          59,
          66,
          64,
          61
        ]
      }
    ]
  },
  {
    "title": "Incidents",
    "subtitle": "Open and resolved by month",
    "chartTitle": "Incidents",
    "type": "line",
    "labels": [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun"
    ],
    "datasets": [
      {
        "label": "Dataset 1",
        "data": [
          16,
          14,
          13,
          11,
          10,
          9
        ]
      },
      {
        "label": "Dataset 2",
        "data": [
          10,
          12,
          13,
          15,
          16,
          18
        ]
      }
    ]
  },
  {
    "title": "Cost breakdown",
    "subtitle": "Spend by category",
    "chartTitle": "Cost breakdown",
    "type": "bar",
    "labels": [
      "Infra",
      "Apps",
      "Data",
      "Security",
      "Ops",
      "Support"
    ],
    "datasets": [
      {
        "label": "Dataset 1",
        "data": [
          42,
          28,
          18,
          15,
          24,
          12
        ]
      },
      {
        "label": "Dataset 2",
        "data": [
          40,
          26,
          20,
          14,
          22,
          10
        ]
      }
    ]
  }
]
```
Pinned local-nav fixture links:
```json
[
  {
    "id": "dashboard",
    "label": "Dashboard",
    "icon": "dashboard",
    "selected": true
  },
  {
    "id": "services",
    "label": "Services",
    "icon": "services"
  },
  {
    "id": "administration",
    "label": "Administration",
    "icon": "user-settings"
  },
  {
    "id": "catalogs",
    "label": "Catalogs",
    "icon": "catalog-management"
  }
]
```
- When the prompt asks for local nav, translate `local-nav.pattern.json` directly. Do not emit an empty `<kyn-local-nav>`.
- Every `kyn-local-nav-link` must include visible label text plus `<span slot="icon" class="local-nav-icon">` with an approved Shidoka SVG.
- Local-nav icons should use inline SVG from `@kyndryl-design-system/shidoka-icons` so placeholder or custom icons inherit the same `currentColor` token as the associated local-nav label text. Do not use `<img>` inside `slot="icon"`.
- When the prompt does not specify exact route-to-icon semantics, still assign each sibling local-nav item a different approved Shidoka icon from a neutral/canonical nav family. Do not reuse the same icon across level-one local-nav links or guess with a mixed bag of noncanonical route icons.
- `kyn-local-nav-link` uses the default slot for link text. Do not put `slot="nav"` on `kyn-local-nav-link`.
- Put `slot="icon"` on the inner icon wrapper only, not on `kyn-local-nav-link` itself. Wrong: `<kyn-local-nav-link slot="icon">...`; correct: `<kyn-local-nav-link><span slot="icon" class="local-nav-icon">...</span>Label</kyn-local-nav-link>`.
- Import `@kyndryl-cto/shidoka-studio/styles/shell-local-nav.css` when local nav is present so the shared icon-box alignment rules keep the slotted icon tight to a real 16x16 wrapper.
Local-nav starter skeleton:
```html
<kyn-local-nav>
  <kyn-local-nav-link selected><span slot="icon" class="local-nav-icon"><!-- dashboard.svg from @kyndryl-design-system/shidoka-icons --></span>Dashboard</kyn-local-nav-link>
  <kyn-local-nav-link><span slot="icon" class="local-nav-icon"><!-- services.svg from @kyndryl-design-system/shidoka-icons --></span>Services</kyn-local-nav-link>
  <kyn-local-nav-link><span slot="icon" class="local-nav-icon"><!-- user-settings.svg from @kyndryl-design-system/shidoka-icons --></span>Administration</kyn-local-nav-link>
  <kyn-local-nav-link><span slot="icon" class="local-nav-icon"><!-- catalog-management.svg from @kyndryl-design-system/shidoka-icons --></span>Catalogs</kyn-local-nav-link>
</kyn-local-nav>
```
## 6b. Data table structure (CRITICAL for column alignment)
- **Never use native HTML table elements.** Do not use `<table>`, `<thead>`, `<tbody>`, `<tr>`, `<th>`, or `<td>`. Only use `kyn-table-container`, `kyn-table`, `kyn-thead`, `kyn-tbody`, `kyn-header-tr`, `kyn-th`, `kyn-tr`, `kyn-td`.
- **Import required:** The consuming app must load the Shidoka table components so that `kyn-table-container`, `kyn-table`, `kyn-thead`, `kyn-tbody`, `kyn-header-tr`, `kyn-th`, `kyn-tr`, and `kyn-td` are all defined. Use `import '@kyndryl-design-system/shidoka-applications';` at app entry or in the page/layout that contains the table. If the table components are not loaded, rows and cells render as unknown elements and do **not** get Shidoka table styling (header may appear but body rows/cells will look broken).
- When the page includes a data table, wrap it in a div with `style="width: 100%; overflow: auto; max-height: 360px;"` then `kyn-table-container` > `kyn-table`. Do not add a border or border-radius by default; only add those when the user explicitly requests a bordered table treatment.
- **Header:** `kyn-thead` > `kyn-header-tr` > **one `kyn-th` per column** with text content (e.g. `<kyn-th>Name</kyn-th>`, `<kyn-th>Status</kyn-th>`, `<kyn-th>Value</kyn-th>`).
- **CRITICAL — One cell per column:** Each body row (`kyn-tr`) must contain **exactly one `kyn-td` per column**, in the **same order** as the `kyn-th` elements. The number of `kyn-td` in every `kyn-tr` must equal the number of `kyn-th` in the header. If a row has fewer cells than columns, or multiple values in one cell, the Shidoka table will render with **misaligned columns** (e.g. Status and Date appearing under Name).
- **WRONG:** One `kyn-td` per row; or one `kyn-td` containing all column values; or rows with different cell counts.
- **CORRECT:** For each row, emit one `kyn-tr` with one `kyn-td` per column, in header order. Example default columns: Name, Status, Value.
Svelte example (one kyn-td per column):
```svelte
<div class="table-wrapper" style="width: 100%; overflow: auto; max-height: 360px;">
  <kyn-table-container>
    <kyn-table>
      <kyn-thead>
        <kyn-header-tr>
          <kyn-th>Name</kyn-th>
          <kyn-th>Status</kyn-th>
          <kyn-th>Value</kyn-th>
        </kyn-header-tr>
      </kyn-thead>
      <kyn-tbody>
        {#each tableData as row}
          <kyn-tr>
            <kyn-td>{row.name}</kyn-td>
            <kyn-td>{row.status}</kyn-td>
            <kyn-td>{row.value}</kyn-td>
          </kyn-tr>
        {/each}
      </kyn-tbody>
    </kyn-table>
  </kyn-table-container>
</div>
```
Ensure `tableData` is an array of objects whose keys match the column names (e.g. `{ name, status, value }` or `{ name, status, date }`), and that every row has the same keys so each `kyn-tr` has the same number of `kyn-td` as `kyn-th`.
**Canonical pattern (design system):** The structure above matches the Shidoka table story: `kyn-table-container` > `kyn-table` > `kyn-thead` (one `kyn-header-tr` with one `kyn-th` per column) + `kyn-tbody` (one `kyn-tr` per row, each with one `kyn-td` per column in header order). Optional: `kyn-table-toolbar` above for title/subtitle; `kyn-table-footer` below for legend/pagination. In Lit the story uses `repeat(rows, row => row.id, row => …)` with one `kyn-tr` per row and one `kyn-td` per column; in Svelte use `{#each tableData as row}` with one `<kyn-td>` per column. Same element hierarchy in all frameworks so rows and cells render as Shidoka table rows and cells.
## 7. Main structure
- Use `<main style="padding: max(var(--kd-shell-header-clearance, 0px), 2rem) var(--kd-page-gutter, 2rem) var(--kd-page-gutter, 2rem);">` so the main body stays visibly inset and narrower than the shell edges.
- Use one direct Foundation grid wrapper inside `main`, such as `<div class="main-stack kd-grid">`, so all interior page content stays on `kd-grid` unless the prompt explicitly asks for another layout primitive.
- Keep page title, toolbar, widget/chart region, forms, and table on that same page grid. Single-column sections should still use full-span Foundation columns rather than abandoning the grid.
- Use the Shidoka Foundation grid as the default responsive layout system for all interior `<main>` content. Do not substitute custom page-level CSS grids or a separate page-level flex wrapper unless the prompt explicitly asks for it.
- Keep the canonical order: page title, toolbar, then the widget region (static Foundation/CSS grid by default; use `kyn-widget-gridstack` only when explicitly requested).
- The toolbar row uses `display: flex; justify-content: space-between; align-items: center; gap: 1rem;`.
- Default drawer labels are `Ok`, `Cancel`, and `Secondary`.
- Drawers, modals, and dialogs stay closed on initial render unless the user explicitly asks for them to start open.
- If the prompt asks for a modal or drawer, do not open it on initial render unless the user explicitly asks. Never leave `<kyn-modal open>` / `open` on the host by default.
- Prefer the **anchor** pattern so the component can manage `open` internally: `<kyn-modal ...><kyn-button slot="anchor" kind="secondary">Modal</kyn-button>...</kyn-modal>` (same idea for `kyn-side-drawer`).
- **Lit Shidoka components + app-bound `open` (`kyn-modal` / `kyn-side-drawer`):** The design system is implemented in **Lit**; consuming repos may use **React, Vue, Svelte, Next.js, vanilla JS**, or other stacks. Components **own `open` internally** on dismiss. If the **app layer** also **binds `open` from reactive state**, the next render/reconciliation can **re-apply `open=true` before parent state catches up**, which **reopens** the overlay (often two interactions to close). **Prefer uncontrolled:** do **not** pass `open` from the app; use the **anchor**; use **`on-close`** / **`on-open`** for side effects only—not a Lit bug, not anchor bubbling.
- If you **must** bind `open` from app state, **omit `open` when the overlay should be closed** (only set `open` when truly open) so the next update cannot push `open` after an internal dismiss. With custom elements, a false boolean in some frameworks can still leave an `open` attribute behind—conditional attributes/props are safer than a always-bound boolean.
- `kyn-modal` emits the custom event **`on-close`**. Listen on the host element, e.g. `element.addEventListener('on-close', handler)`. Do not assume your framework’s `on*` / `@` prop syntax maps to Lit custom events without explicit wiring.
- Confirmation modals should keep `labelText` short and place the fuller explanatory copy in the modal body content (for example a `<p>` child). Do not cram the entire confirmation sentence into `labelText` and leave the modal body empty.
- For command palettes or command-launch surfaces that behave like a modal dialog with backdrop, prefer `kyn-modal` by default rather than a custom `role="dialog"` wrapper plus bespoke scrim. Keep the palette search field and command list inside the modal body, use the normal anchor/open contract, and reserve custom dialog shells for explicit user requests or for preserving an existing local pattern in place.
- If a table row or details panel needs an inline escalation/confirm action, render a real Shidoka affordance such as `kyn-button` or `kyn-tag clickable`. Do not fake the action with plain text, a non-clickable badge, or an unstyled table cell label.
- Keep closed overlay hosts such as `kyn-modal` out of the normal centered content stack when possible so they do not create phantom spacing.
- Default chart type is `line`. For categorical line/bar charts, default to at least 2 datasets with varied dummy values and `options.colorPalette = 'categorical'`. Keep chart metadata explicit (`chartTitle`, `description`) for standalone charts. In widget-grid charts, default to a compact widget-chart treatment: keep `chartTitle`, hide `description` and controls, and avoid repeating the same descriptive chrome in both widget copy and chart copy unless the user explicitly asks for richer chart-owned header content. Prefer dataset labels `Dataset 1` / `Dataset 2` unless the user provided semantic labels, and leave dataset paint token-driven. Never emit hard-coded chart paint such as `backgroundColor`, `borderColor`, or raw color literals by default. Use only palette names supported by `@kyndryl-design-system/shidoka-charts`; if a palette is unknown or invalid, fall back to `'categorical'`.
- **Cross-framework dataset invariant:** in Vue, React, Lit/HTML, Storybook, and Svelte, every categorical line/bar `kd-chart` defaults to at least 2 datasets. Do not collapse to one dataset unless the user explicitly requests a single-series chart.
- In Vue, use `:headLine`, `:pageTitle`, `:subTitle`, `:titleText`, `:labelText`, `:widgetTitle`, and `:subTitle` so Lit-backed titles render correctly.
- When React widgets use `kd-chart`, import `@kyndryl-design-system/shidoka-charts/components/chart`; otherwise `kd-chart` can render as an empty box even when width and height are correct.
- In React, put the chart palette on `options.colorPalette`, not on `<kd-chart colorPalette=...>` and not on `element.colorPalette = ...`; assign the full `options` object on the real `kd-chart` element via ref/effect.
- **kd-chart `colorPalette` resolution (line charts go blank):** `shidoka-charts` resolves `options.colorPalette` via `getComputedColorPalette()`. It only understands **named keys** from `common/config/colorPalettes.js` (e.g. `categorical`, `sequential01`, `statusDark`) or a **single design token name** such as `--kd-color-data-viz-categorical-01-01` that `getTokenThemeVal` can resolve. **Do not** pass arrays of `var(--kd-color-...)` strings, raw `var(...)` CSS, hex, or rgb — unknown values resolve to an **empty palette**; line styling then has no `borderColor`/fill, so **lines do not render** (empty plot). Bar charts may still appear with partial fallback. Always use a supported name such as `colorPalette: 'categorical'`.
- **Grouped bar + categorical palette:** With **multiple datasets** (e.g. two regions), the ramp assigns **one color per series**; X-axis categories are not separate series, so the legend shows **two** colors, not one per category — that is expected unless the data model or chart type changes.
- For the workspace trigger in React, the chevron should be imported from `@kyndryl-design-system/shidoka-icons/svg/monochrome/20/chevron-down.svg?raw` and rendered inline at 20×20 so hover and active tokens flow through `currentColor`; do not use `<img>` for that interactive icon.
- Interactive header icon-only buttons should also be imported from `@kyndryl-design-system/shidoka-icons` and rendered inline rather than using `<img>` so hover and active states inherit the correct text/icon color tokens.
- React/Vite icon import example: `import notificationIconSvg from '@kyndryl-design-system/shidoka-icons/svg/monochrome/20/notification.svg?raw'` and render that imported markup inline. Wrong: `const NOTIFICATION_ICON = '<svg ...>'`.
- In React, do not use `checked={condition}` for custom-element form controls in React when false values must be genuinely absent. For `kyn-checkbox`, `kyn-toggle-button`, and similar custom elements, omit `checked` entirely when false with a conditional spread such as `{...(isChecked ? { checked: true } : {})}`.
- If React form controls still need hard state sync after interaction, set the element property via a ref/effect (`element.checked = isChecked`) instead of relying only on JSX boolean serialization.
- `kyn-checkbox` emits `on-checkbox-change`; `kyn-toggle-button` and many other form controls emit `on-change`. Use refs plus `addEventListener(...)` in React when those custom events do not wire through JSX automatically.
- In Svelte, keep the same canonical camelCase property names for `kyn-page-title`, `kyn-side-drawer`, `kyn-modal`, and `kyn-widget`; do not emit kebab-case props such as `head-line`, `page-title`, `sub-title`, `title-text`, `label-text`, or `widget-title` for those components.
- For filters, toolbars, and forms, use **`kyn-dropdown`** with **`kyn-dropdown-option`** (or the documented Shidoka selection pattern). Avoid native `<select>` for primary page UI—it will not match Shidoka styling.
- **Modal and drawer footers:** Keep primary, secondary, and cancel actions in a **horizontal** row on desktop (`display: flex; flex-direction: row; flex-wrap: wrap; gap: 0.75rem; align-items: center`). Use a media query (e.g. `max-width: 672px`) to stack actions only on narrow viewports. Do not default to a vertical button stack on desktop.
- For static non-interactive dashboards, keep the widget region on the same page `kd-grid` and let the prompt govern arrangement as rows x columns (for example 2x3, 3x2, 24x3). If no arrangement is provided, fall back to the `Reference dashboard` starter profile (2x3).
- Original default dimensions are: 24px gap, layout-wrapper/card min-height 420px, a flexible chart host (`.dashboard-chart-host { flex: 1; min-height: 0; width: 100%; }`), widget-chart fill height `280`, and chart style `width: 100%; display: block;`. Do not add `align-items: start` on the chart-grid `kd-grid` container by default. For widgets with CTA/supplemental content, keep the chart-host floor at about 320px, reserve the supplemental row, and let the card floor derive to about 440px.
- If the prompt explicitly gives widget dimensions, apply those width/height values on the wrapper that contains each widget instead of reskinning the widget host itself, and keep charts filling the widget width.
- Only when `kyn-widget-gridstack` is explicitly requested, render a centered `widget-grid-wrapper` wrapper and import `@kyndryl-design-system/shidoka-applications/common/css/gridstack-shidoka.css`, then pass `gridstackConfig` with {"handle":"kyn-widget-drag-handle","margin":24,"animate":false,"columnOpts":{"breakpointForWindow":true,"breakpoints":[{"w":671,"c":4},{"w":1183,"c":8}]},"cellHeight":420,"staticGrid":true,"disableDrag":true,"disableResize":true}.
- Default gridstack item size is `gs-w="4"`, `gs-h="1"` (default 2x3 desktop). When prompt sets a different columns count, derive `gs-w` from columns (`12 / columns`) and align `gs-h`/height to the requested dimensions.
- Inside every `grid-stack-item`, add `<div class="grid-stack-item-content">` around the widget. Gridstack applies inset margin spacing to that wrapper, not to a direct child `kyn-widget`.
- Pass `gridstackConfig` declaratively on `kyn-widget-gridstack` in the generated markup. Do not rely on a later `onMount`/post-render patch-up step as the primary way to apply the canonical static dashboard config.
- Treat GridStack interactivity as one of three supported modes only: static (`staticGrid: true`, `disableDrag: true`, `disableResize: true`), drag-only (`staticGrid: false`, `disableDrag: false`, `disableResize: true`), or drag+resize (`staticGrid: false`, `disableDrag: false`, `disableResize: false`). Avoid partial or page-specific combinations unless the user explicitly asks for a custom interaction pattern.
- Emit the default `gs-w` / `gs-h` sizing directly in the grid item markup for the canonical 6-widget dashboard instead of mutating those attributes after mount.
- For the default uniform dashboard grid, omit `gs-x` / `gs-y` on each item so Gridstack can reflow cards responsively. If you hard-code `gs-x` / `gs-y` for a 12-column desktop layout without supplying a breakpoint-aware `layout` map, the grid can leave holes or stack incorrectly on resize.
- Do not bind `layout`, `:layout`, `.layout`, or an empty/default layout object on `kyn-widget-gridstack` for the canonical auto-pack dashboard grid. Only supply `layout` when you have a real breakpoint-aware layout map.
- In Svelte/Vite live-edit flows, if HMR replaces the slotted `.grid-stack` children, reapply a fresh `gridstackConfig` object or remount `kyn-widget-gridstack` so GridStack re-initializes against the updated DOM. In auto-pack mode, keep `layout` omitted/unset/`undefined` during that refresh.
- If a grid refresh or remount can replace `kd-chart` nodes, reapply each chart's `labels`, `datasets`, and `options` properties after the refresh instead of assigning chart data only once.
- In React, if a plain JSX object prop does not reliably reach `kyn-widget-gridstack`, set `gridEl.gridstackConfig = { ...gridstackConfig }` after mount before adding page-level CSS or widget-specific handle workarounds.
- Use gridstack only for an explicitly requested widget-grid region; do not use it for ordinary single-chart pages or the default interior layout of `main`.
- Never rely on `.grid-stack { gap: ... }`, `.grid-stack { display: grid; }`, or `.grid-stack { display: flex; }` for widget spacing in real pages. Spacing comes from `gridstackConfig.margin` plus `gridstack-shidoka.css`.
- **Visible widget-row spacing is required:** dashboard widget grids must show clear horizontal and vertical separation between cards. If adjacent rows look packed together or nearly touching, treat that as a regression. The first things to verify are (1) `@kyndryl-design-system/shidoka-applications/common/css/gridstack-shidoka.css` is imported, (2) `gridstackConfig.margin` remains `24`, and (3) every `.grid-stack-item` contains the required `.grid-stack-item-content` wrapper so Gridstack can apply its inset spacing on both axes.
- If resize handles appear in the default dashboard grid, treat that as a regression: the canonical config keeps `staticGrid: true`, `disableDrag: true`, and `disableResize: true`, so widgets should be neither draggable nor resizable by default. If the user explicitly requests interactive widgets, flip all three interactivity flags to `false` together.
- If the user explicitly wants draggable but not resizable widgets, prefer the supported drag-only mode (`staticGrid: false`, `disableDrag: false`, `disableResize: true`) and only add stronger fallbacks such as `resizable: { handles: "" }` if the runtime still leaks resize affordances after the primary config is correct.
- Do not treat screenshot-specific or widget-specific GridStack workarounds such as chart-only drag handles, title-row offset CSS, or selector exceptions for one page as canonical guidance unless they are proven reusable across widget types and frameworks.
- **Charts must display data:** Every `kd-chart` must receive `labels` and `datasets` (and optionally `options`). Without them, the chart renders empty even when expanded. Pass recipe defaultLabels/defaultDatasets or equivalent from widget data (e.g. in React: `labels={chartLabels}` and `datasets={chartDatasets}`). Never emit a bare `<kd-chart type="line">` or a fixed-height placeholder chart with no data.
- **Chart widgets with CTA must still show charts:** if the prompt asks for chart widgets and also asks for a CTA/action row, do not degrade the widget into a title + CTA card with an empty body. A visible CTA with a blank chart area is a regression; keep the chart rendered above the CTA and fix chart hydration rather than dropping chart content.
- **Widget footer CTA — default sizing and placement:** When a `kyn-widget` includes a footer or secondary CTA (for example “Open costs”, “View health”), default to `kyn-button` with `kind="outline"` and `size="small"` unless the prompt requires a different emphasis. **Placement:** center the button horizontally in its row; keep the button content-sized (not full-width on desktop dashboards). Give the action row `flex-shrink: 0` and symmetric vertical padding (for example `padding-block: 0.5rem`) so spacing above and below the CTA stays balanced relative to the body content. Do **not** pin the action row with `margin-top: auto` or force a tall strip with a fixed `min-height`—those patterns create uneven spacing. **Chart widgets:** wrap `kd-chart` + CTA in a column flex stack with a modest gap between chart block and CTA row (for example `0.75rem`). Keep the chart host `flex: 1; min-height: 0; width: 100%` by default, and do **not** pair a default `min-height: 300px` floor with `justify-content: flex-end` on the chart host just to pin the chart above the CTA; that makes mixed chart rows accumulate extra space above the chart.
- If `kd-chart` renders as an empty box in React, the first things to verify are (1) `@kyndryl-design-system/shidoka-charts/components/chart` is imported and (2) `labels` / `datasets` are passed at render time; this is not usually a width-only issue.
- **Cross-framework chart hydration invariant:** Any ref/handle/binding used to hydrate chart data must point only to the actual `kd-chart` element, never to a wrapper `div`/host around it. Do not store the same chart handle slot from both the wrapper and the chart element.
- Hydrate `labels`, `datasets`, and `options` on the real `kd-chart` element as soon as that specific element instance is attached. Use the framework-native element hook on `kd-chart` itself (for example React callback refs, Svelte `bind:this` plus mount/update handling, Vue template refs plus `onMounted`/`nextTick`) rather than hydrating a wrapper and hoping the chart can inherit those properties.
- If custom-element upgrade timing may race the hydration step, reapply chart properties after `customElements.whenDefined('kd-chart')` (or the framework-equivalent mounted/nextTick pass) so blank chart bodies do not persist when the element upgrades after initial render.
- **Vue-specific first-hydration rule:** do not rely only on an `immediate` watcher for the initial `kd-chart` hydration pass. In Vue, that watcher can run before the template ref exists. Always perform one explicit post-mount hydration pass (`onMounted` + `nextTick` + `customElements.whenDefined('kd-chart')`) against the real `kd-chart` element, then reapply on later data/size changes as needed.
- Keep palette selection inside `options.colorPalette`; do not expect a standalone `colorPalette` JSX prop/attribute or `element.colorPalette` assignment to theme `kd-chart` correctly in React.
- When assigning chart data objects, use fresh arrays/objects (`labels`, `datasets`, `options`) instead of mutating and reusing a stale object reference across remounts.
- A blank widget body in compact widget-chart mode often means chart hydration targeted the wrong node or ran before `kd-chart` was ready; do not assume this is only a sizing or import problem.
- In React, `labels`, `datasets`, and `options` are complex values on a custom element. Do not rely only on JSX props for those arrays/objects. Assign `labels`, `datasets`, and `options` on the `kd-chart` element via a ref/effect so the custom element receives real properties rather than stringified or ignored attributes.
- **Chart and grid sizing:** Use `cellHeight: 420` in gridstackConfig, keep the widget/card min-height explicit, and make each widget-chart use `height="280"` plus `style="width: 100%; display: block;"`. For static `kd-grid` dashboards, let `.dashboard-chart-host` stay `flex: 1; min-height: 0; width: 100%;` by default; only add a larger host floor when the layout truly needs reserved room. If charts appear tiny, ensure gridstack-shidoka.css is imported when using Gridstack and the card -> widget -> chart-host height chain is intact.
- **Dimensions must be explicit:** define wrapper/card dimensions directly (default min-height 420px), keep the ordinary chart host flexible instead of layering a second default chart-host floor under that card, and let the chart fill the remaining host space. When the widget also contains CTA/supplemental content, define the chart-host floor first (about 320px), reserve the supplemental row, and let the card floor derive to about 440px instead of reusing the smaller chart-only dimensions. Do not rely on implicit auto sizing for widget or chart dimensions, do not add `align-items: start` on the chart-grid container by default, and do not reskin `kyn-widget` when a wrapper can own the layout.
- **Uniform row spacing beats inner-card overflow:** when gridstack widgets include CTA/supplemental content, do not only raise the inner widget/card min-height while leaving the grid item on the chart-only default row size. Increase the uniform grid item height for the whole grid (for example by raising `cellHeight` or using a larger shared `gs-h`) so chart + legend + CTA fit inside every cell without spilling into the next row. Vertical spacing between widget rows must remain consistent regardless of individual widget internals.
- **Do not override the GridStack spacing wrapper:** `.grid-stack-item-content` owns the inset spacing contract. Do not add rules such as `height: 100%`, custom padding, or layout overrides on that wrapper when they neutralize Gridstack's inset offsets. Let the child `kyn-widget` and its internal body fill the wrapper instead.
- In ordinary static dashboard cards, keep the canonical explicit widget-chart height instead of adding self-measuring chart-height logic to eliminate every bit of remaining space. Only switch to measured numeric height when the outer widget/grid cell is explicitly resizable.
- Make the card and widget a flex column chain so the widget receives a real height from its wrapper and the chart host can fill the remaining body space.
- In React/static-grid layouts, chart widgets should let the `kd-grid` row stretch by default (do not add `align-items: start` on the chart-grid container), use `.static-widget-card { display: flex; flex-direction: column; min-height: 420px; }`, `.static-widget-card > kyn-widget { flex: 1; min-height: 0; }`, and `.dashboard-chart-host { flex: 1; min-height: 0; width: 100%; }`; content-only widgets should use the row-matching `.content-widget-card` pattern instead of the 420px chart floor.
- When a widget/grid cell is explicitly resizable, measure that outer bounded container and set `kd-chart` `height` to the measured pixel height (not `height="100%"`, which coerces to ~100px). Use `style={{ width: "100%", display: "block" }}` so the chart fills width without a bogus percentage height.
- **Svelte/Vue / static HTML:** Wrap `kd-chart` in a flex child `.dashboard-chart-host` under a full-height `kyn-widget` body chain and keep the canonical explicit numeric widget-chart height (`height="280"`) for ordinary static dashboard cards. Only add `ResizeObserver` when an outer widget/grid cell is explicitly resizable and already provides an independent bounded height; do not observe the chart host whose size depends on `kd-chart` itself.
- If percentage height cannot resolve because the host chain has no defined height, fix the card -> widget -> chart-host height chain first and use a host min-height only as a fallback.
- Use `kyn-widget` for each grid item and keep the chart host in the flex height chain so the chart plus legend fit without internal widget scrolling. In chart-only static cards, the host stays flexible by default; for CTA/supplemental cards, derive the larger host floor from the supplemental layout instead of stacking multiple default vertical floors.
- Keep an explicit `chartTitle` in widget grids by default. If the user does not provide separate chart copy, `chartTitle` may mirror the widget title. Hide `description` by default unless the user explicitly asks for chart-specific explanatory copy, and avoid repeating the same descriptive text in both widget subtitle and chart description.
- Reference starter widget set: `Revenue trend` (line), `Usage by region` (bar), `Response times` (line), `Capacity` (bar), `Incidents` (line), `Cost breakdown` (bar). Use it as fallback scaffolding when the prompt does not imply a different dashboard variety.
- Keep `kyn-footer` after main with `<span slot="copyright">Copyright © {year} Kyndryl Inc. All rights reserved.</span>`.
- Do not wrap the footer copyright slot in a fake full-width layout wrapper. `kyn-footer` already has native gutters, and `kyn-ui-shell` reserves local-nav clearance for the slotted footer by applying `has-local-nav` / `pinned` classes. Adding custom left padding or margin to `main` or `kyn-footer` will double the offset.
- Do not add host-level `width`, `max-width`, or `margin: 0 auto` to `kyn-footer` in local-nav pages. Let `kyn-ui-shell` manage the slotted footer clearance.
- The footer logo slot wrapper should use inline-flex alignment (`display: inline-flex; align-items: center; height: 100%`) so the bridge logo stays vertically aligned with adjacent footer text.
- Keep `main` and `kyn-footer` as direct children of `kyn-ui-shell`; do not wrap them in an extra shell/body container in local-nav pages.
- If `kyn-footer` still spans underneath the local nav in a consuming app, that is a classing failure: the slotted footer should have `has-local-nav` and `pinned` when the local nav is pinned.
- **Local nav — do not pin by default:** Do not set the `pinned` attribute on `kyn-local-nav` unless the user explicitly asks for a pinned nav rail. Omit `pinned` by default.
- When the prompt asks for local nav, emit populated `kyn-local-nav-link` children from `local-nav.pattern.json` unless the user supplies custom nav items.
- Do not emit an empty `<kyn-local-nav>`.
- Every `kyn-local-nav-link` must include visible label text plus `<span slot="icon" class="local-nav-icon">` with an approved Shidoka SVG.
- Local-nav icons are a 16x16 contract. Use approved `@kyndryl-design-system/shidoka-icons/svg/monochrome/16/...` assets for level-one local-nav items, not the larger 20x20 shell/flyout icons.
- Each sibling level-one local-nav item should use a different approved Shidoka icon. Do not repeat the same icon across the rail unless the user explicitly asks for that repetition.
- Wrap the local-nav icon in a fixed 16x16 inline-flex box (for example `<span slot="icon" class="local-nav-icon">...</span>`) so the icon slot stays aligned and the label text baseline does not drift.
- Load `@kyndryl-cto/shidoka-studio/styles/shell-local-nav.css` when local nav is present so the shared icon-box alignment rules keep the row spacing tight and normalize the slotted icon wrapper.
- Local-nav icons should be imported from `@kyndryl-design-system/shidoka-icons` and rendered inline so placeholder or custom icons inherit the same `currentColor` token as the associated local-nav label text. Do not use `<img>` inside `slot="icon"` and do not paste copied `<svg>` source into local constants.
- Do not author bespoke shell/local-nav SVG paths or React icon components for local-nav items. Use approved `@kyndryl-design-system/shidoka-icons` assets such as `settings.svg`, `history.svg`, `grid.svg`, or the canonical placeholder asset appropriate to the nav item, imported directly from the package.
- Do not put `slot="nav"` on `kyn-local-nav-link`; `kyn-local-nav` expects links in its default slot.
- Do not put `slot="icon"` on `kyn-local-nav-link`; that breaks spacing and icon placement. The icon slot belongs on a child wrapper such as `<span slot="icon" class="local-nav-icon">...</span>` inside the link.
- Local-nav wrong/correct example: WRONG `<kyn-local-nav-link slot="icon"><span>...</span>Dashboard</kyn-local-nav-link>`; CORRECT `<kyn-local-nav-link><span slot="icon" class="local-nav-icon">...</span>Dashboard</kyn-local-nav-link>`.
## 8. Archetypes and modes
- The current default archetype is `dashboardPage`; the other archetypes are explicit extensions of the same canonical contract.
- `dataTablePage`
- `dashboardPage`
- `detailWorkflowPage`
- `generate_full_page`
- `refine_existing_page`
- `generate_shell_only`
- `translate_archetype_to_framework`
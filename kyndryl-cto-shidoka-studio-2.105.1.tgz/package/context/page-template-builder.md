# Page / template builder — Shidoka layout rules

Use this for **any prompt that asks for a full page, UI shell, or template** (e.g. "build a page with ui-shell, header, local nav, footer, data table, side drawer"). Follow the order and spacing below so the output is valid and consistent.

**Every page checklist (apply in every project):** (1) `<main style="padding: max(var(--kd-shell-header-clearance, 0px), 2rem) var(--kd-page-gutter, 2rem) var(--kd-page-gutter, 2rem);">` — never use bare `<main>`; the main body must stay visibly inset and the first visible content block must clear the fixed shell header; the consuming app may override `--kd-shell-header-clearance` if its shell chrome is taller, but do not remove the fallback top clearance from `main`. When a framework needs adapter syntax for inline styles, keep this exact padding contract. (2) one direct Foundation grid wrapper such as `<div class="main-stack kd-grid">` inside `main` — this keeps interior page content on the same framework-neutral layout primitive instead of drifting into per-framework wrappers; use full-span columns for single-column sections. (3) when pinned `kyn-local-nav` is present inside `kyn-ui-shell`, let the shell reserve the horizontal clearance for `main` and `kyn-footer`; do not add extra page-scoped left padding/margin; (4) main content order: kyn-page-title → toolbar (drawer + ghost button) → chart or widget region → table — drawer in toolbar row, not after table; (5) Storybook decorator: only `min-height: 100vh; width: 100%;` — never `margin: var(--kd-negative-page-gutter)` or negative margin; (6) in consuming apps, mount `kyn-ui-shell` at full available route width — do not place the shell inside a centered app wrapper with `max-width`, `width: min(...)`, or `margin: 0 auto`; if the app has a demo nav or route picker outside the shell, center that nav separately and let the shell route render full width.

**Shell chrome and flyout stacking belong to app-level CSS, not page CSS.** If a consuming app needs to reinforce `kyn-header`, `kyn-local-nav`, or flyout panel stacking/backgrounds, prefer importing the Studio-managed shell bundles (for example `@kyndryl-cto/shidoka-studio/styles/shell-overlays.css` and, when local nav is present, `@kyndryl-cto/shidoka-studio/styles/shell-local-nav.css`) from one global stylesheet such as `src/app.css`. Do not generate page-scoped host overrides for shell elements inside a single Vue/Svelte/React page component.

**Default data rule:** If a component or pattern accepts JSON/structured data and the user does **not** explicitly provide that data, generate **boilerplate inline data** so the output is complete and working. This applies to global switcher data, workspace switcher data, chart labels/datasets/options, table columns/rows, and similar data-driven patterns. Do not leave generated examples empty.

**Same page everywhere.** The **structure and content** of the page (shell order, header with global/workspace switcher, main with title, toolbar, chart, table, side drawer with user-specified anchor text, button labels, row count, dummy data) must be **identical** whether you generate a Storybook story (design-system repo) or a Vue/React/etc. component (consuming app). Only the **output format** differs: in the design-system repo write a `.stories.js` (or `.stories.ts`) file; in a consuming app write the appropriate framework file (e.g. `.vue`, `.tsx`) and use package imports. Infer the framework from repo context by default and do not require the user to restate it when the workspace already makes it clear. Same `kyn-*` tags, same layout, same row count, and same behavior. If the user does not supply action labels, use neutral defaults such as `Open details` and `Secondary action`.

**Framework-neutral default, adapter quirks second.** The default page contract is the same across frameworks: same shell, same `main` layout, same `kd-grid`, same widgets/tables/charts, same data defaults. Mention framework names only when the implementation needs a real adapter-specific expression of that contract, such as Vue property binding, Svelte custom-element event/property wiring, or React ref/property hydration.

**Authority scope and multi-MCP composition:** Use Shidoka Studio as the authority for shell/layout composition, component selection, pattern semantics, and design-system integration behavior. Do not use Shidoka guidance to invent or override business metric definitions, workflow state truth, approved domain terminology, query semantics, or other domain meaning when another source is available. For mixed-authority tasks, establish domain facts from the user or another authoritative source first, then translate those facts into canonical Shidoka UI with the MCP payload. Preserve externally established labels, statuses, thresholds, and meanings instead of reinterpreting them through Shidoka defaults.

**Auxiliary MCP tools stay scoped:** `get_workspace_ui_context` is only for framework syntax, routing, file placement, app entry, and integration details. `get_shidoka_support_docs` is only for setup, packaging, rollout, and troubleshooting. Neither one is a source of domain/business truth, and neither one overrides the canonical Shidoka UI authority for page composition.

**MCP-only boundary for pages:** For full-page generation and page-level refinement, use the Shidoka Studio MCP payload as the sole design authority. Do not inspect local Storybook stories, generated pages, component source files, boilerplate helpers, or example JSON to decide page composition unless the user explicitly asks you to analyze or edit an existing local file.

**Canonical generation checklist:**
1. Detect only the minimum adapter facts first: framework, router, output file destination, app entry, and global CSS location. Do not read local app entry/layout or existing page/layout files before the canonical payloads except to confirm those adapter facts.
2. If the request mixes UI work with business/domain facts, establish those domain facts from the user or another authoritative source before composing the page. Do not let Shidoka payloads redefine KPI meaning, workflow truth, or approved domain terminology.
3. Call the Shidoka Studio MCP payloads before deeper repo exploration. For full pages and ui-shells, call all 7 generation tools first; for header-only work, the header-nav trio is the minimum required set.
4. Build the page from the canonical template/recipe/snippets first, then translate that structure into the local framework syntax. Do not frame local layout review as "replace or extend it cleanly" until the canonical shell/page structure is already fixed.
5. Use local repo inspection only for syntax, file placement, routing, imports, and app-specific integration details.
6. Do not inspect local pages, layouts, stories, generated routes, or component source as design references for a new page unless the user explicitly asks to modify an existing implementation.
7. When the user explicitly asks to modify an existing Shidoka implementation already in the repo, reuse that implementation in place instead of approximating it with a new parallel UI. Do not create a second local version of the same pattern, and do not wrap custom controls inside an outer Shidoka host just to look compliant. Preserve the original pattern's slot contract and left/right grouping. Example: `kyn-global-filter` must remain the real search/action/tags pattern, with compact search + filter on the left and product actions in `slot="actions"`, not a decorative wrapper around a custom filter card or side drawer.
8. When the user names a known UI pattern or component in natural language (for example "global filter", "command palette", "workspace switcher", "local nav", or "data table"), first inspect the repo for an existing local implementation matching that wording or intent before generating a new one. If a matching implementation exists, extend it in place and preserve its composition, slot contract, grouping, and interaction hierarchy. This discovery step is a narrow exception to the "do not inspect local pages/components as design references for a new page" rule: use local code only to locate and reuse the existing implementation, not to replace the MCP payload as design authority.

## 1. Shell order (fixed)

Inside **kyn-ui-shell**, children must appear in this order:

1. **kyn-header** (required)
2. **kyn-local-nav** (optional; include only if the user asks for local nav). Each **kyn-local-nav-link** (level 1) must have **slot="icon"** with a 16px icon and direct visible label text as the link content. Use approved assets from `@kyndryl-design-system/shidoka-icons/svg/monochrome/16/`; do not hand-draw or invent shell/local-nav SVG icons and do not reuse the larger 20px shell/flyout icons here. Wrap the local-nav icon in a fixed 16px inline-flex box (for example `<span slot="icon" class="local-nav-icon">...</span>`) so the slot alignment and text baseline stay stable. Do not wrap the label in nested `kyn-link`, native `a`/`button`, heading tags, or underline wrappers. When local nav is present, load `@kyndryl-cto/shidoka-studio/styles/shell-local-nav.css` so the shared icon-box alignment rules keep the row spacing tight. **Default state:** do **not** set `pinned` unless the user explicitly asks for a pinned/open nav. The default generated local nav should start collapsed on desktop.
3. **main** (required)
4. **kyn-footer** (required)

Do not omit header or footer when building a full page. Never put only `<main>` inside the shell.
Footer logo must mirror header logo. If the header uses the Kyndryl Bridge logo, the footer must use the Kyndryl Bridge logo too.

## 2. Main content: padding (required)

**CRITICAL — Never render a page without this.** **main** must have visible left and right indentation so content is not flush to the edges. Always use the Shidoka page gutter:

```html
<main style="padding: max(var(--kd-shell-header-clearance, 0px), 2rem) var(--kd-page-gutter, 2rem) var(--kd-page-gutter, 2rem);">
  <!-- content -->
</main>
```

- Use this **exact** style on every `<main>` for page/template stories. Do not omit it. In **React JSX**, use a style object: `style={{ padding: 'max(var(--kd-shell-header-clearance, 0px), 2rem) var(--kd-page-gutter, 2rem) var(--kd-page-gutter, 2rem)' }}`.
- The fallback `2rem` ensures readable inset when the token is not set. This is intentional so the main content remains narrower than the full-width header/footer and follows Kyndryl design principles.
- **Wrong:** `<main>` with no style or with only generic page gutters. **Right:** always include `padding: max(var(--kd-shell-header-clearance, 0px), 2rem) var(--kd-page-gutter, 2rem) var(--kd-page-gutter, 2rem);` so the body has clear left/right padding and the first visible content block clears the fixed shell header.

## 3. Spacing (use these tokens)

- **Page gutter (main padding):** `var(--kd-page-gutter, 2rem)` — see section 2; required on `<main>`.
- **Fullscreen decorator:** Use only `min-height: 100vh; width: 100%;` on the wrapper. Do **not** use negative margin on the decorator—that would pull the shell past the viewport and cancel the main content indent. The shell stays viewport width; the main's padding then gives visible left/right indent.
- **Section spacing — use consistent vertical rhythm:** Every block inside main (page title, toolbar, chart, headings, table) must have predictable gaps. Use **one direct `kd-grid` wrapper by default** or one of these patterns for all section gaps:
  - **Between sections (e.g. chart → heading → table):** `margin-bottom: 1rem` (or `1.5rem` for larger separation). Apply to the wrapper of each section (e.g. chart wrapper `margin-bottom: 1.5rem`; section heading `margin: 0 0 1rem 0`; table wrapper has no extra top margin if the heading already has margin-bottom).
  - Or use one direct `kd-grid` wrapper such as `<div class="main-stack kd-grid">` with a consistent row gap, and place ordinary single-column sections in full-span grid columns so all children remain inside the page gutters.
- If you use the centered wrapper `gap` approach, **do not also add default vertical margin to the toolbar row or extra top padding to the chart/widget wrapper**. That compounds spacing and creates visibly oversized gaps.
- **Table wrapper:** use the wrapper in section 4 so the table does not overflow.

Do not invent spacing values; use the tokens above or simple `1rem` / `1.5rem` for consistency. **Wrong:** large random gaps between some sections and none between others. **Right:** uniform spacing (e.g. 1rem or 1.5rem) between title, toolbar, chart, any heading, and table.

## 3b. Forms, wizards, and multi-field panels

Dashboard spacing above does not automatically fix **dense forms**. For registration flows, agent setup, filters-in-a-card, or stepper steps:

### Base layout — setup / multi-step wizards

Use **one** `kd-grid` wrapper for the **entire** main body flow by default, and keep the wizard blocks inside that same grid. For compact/full-width wizard flows, place the page title, horizontal `kyn-stepper`, step body, and action row in **full-span Foundation grid columns** (`kd-grid__col--sm-4 kd-grid__col--md-8 kd-grid__col--lg-12`) instead of dropping out of the grid. **Order inside the grid:** (1) `kyn-page-title`, (2) horizontal `kyn-stepper` with `kyn-stepper-item` children (bind `currentIndex` / `current-index` to app state), (3) **step body** — a single flex column (`gap: 1rem` or `1.5rem`) for optional “Step N of M” copy + fields, **full width** of its grid column, **no** extra inner `max-width` “card” that shrinks only the fields, (4) **wizard action row** — Back/Next (or Submit) in a **horizontal** row **immediately** under the fields, **inside** `main`, same column width as the stepper (`justify-content: space-between` on this row only). **Shell `kyn-footer`** stays copyright-only; do **not** put wizard navigation there. **Authoritative HTML-oriented skeleton:** see **required full-page snippets, section 6a** (`full-page-required-snippets.md` in MCP / `context/full-page-required-snippets.md` in the package).

**Do not abandon `kd-grid` for single-column wizard content.** Unless the prompt explicitly asks for a different primitive, keep the interior content of `<main>` on the Foundation grid and use full-span columns when a section should read as one column.

#### `kyn-stepper`: horizontal vs vertical

`kyn-stepper` exposes a **`vertical`** attribute (see CEM). Choose mode from **layout intent**, not at random.

| Use **horizontal** (default for full-page wizards) | Use **vertical** |
|---------------------------------------------------|------------------|
| **Desktop** setup / registration / deploy flows in **`main`** under `kyn-page-title` — progress reads **left-to-right**; the form stays **directly under** a short step rail. | User explicitly asks for **vertical steps**, **timeline**, or **stacked** step list. |
| Prompt does **not** specify stepper orientation — **default horizontal**. | **Two-column layout:** vertical step list in a **left rail** (fixed width) and **step content + fields in a right column** (`display: grid` or flex row). The stepper is **beside** the form, **not** above it in one narrow column. |
| | **Modal, narrow drawer, or small panel** wizards where a horizontal rail does not fit. |
| | **`stepperType` / pattern** from Storybook or product spec that requires vertical (e.g. status-style stepper) — follow that spec. |

**Wrong:** A **single-column** full-page layout with **`vertical`** on `kyn-stepper` **stacked above** the fields — the rail becomes a tall block, pushes the form down, and wastes horizontal space. **Right:** horizontal stepper for single-column wizards; **or** vertical stepper **only** in a true **side-by-side** grid (left rail + right body), or when the user explicitly wants vertical / modal context.

#### Step labels: `kyn-stepper` only — not badges, not `stepperType` misuse

- **Wrong:** Building step navigation from a row of **`kyn-badge`**, **`kyn-tag`**, ghost buttons, or custom “pill” `div`s. That looks like **filters or catalog metadata** (see §3e), not a wizard, and it is **not** the design-system stepper.
- **Right:** **`kyn-stepper`** with one **`kyn-stepper-item`** per step, bound to app state (`current-index` / `currentIndex`, `step-state` on each item). See **full-page-required-snippets §6a** for the contract.
- **Required text fields:** for wizard flows, each `kyn-stepper-item` must set both `step-name`/`stepName` and `step-title`/`stepTitle`. Do not omit `step-title`; that produces unlabeled circles.
- **`stepperType` on `kyn-stepper`:** For ordinary registration/setup flows with named steps, **omit `stepperType`** or use Storybook’s **default / progress** stepper. **`stepperType="status"`** is the **status/lifecycle** rail (icon-based steps in Storybook)—use only when the product spec explicitly requires that mode, not as a default for generic multi-step forms.

- Use **one** vertical stack per card/panel: `display: flex; flex-direction: column; gap: 1rem` (or `1.5rem`). **Pick one gap value** for the whole form; do not combine it with default `margin-bottom` on every `kyn-text-field` / input unless you are intentionally loosening one section.
- **Field groups:** Wrap each label + control + hint in a single container if you need grouping; avoid orphan margins on only some fields.
- **Segmented controls** (pill buttons, tag groups) stay **directly under their label** with the same `gap` as text fields—avoid an extra wrapper that adds a second margin layer (that often creates the “huge gap before Agent type” bug).
- **Action row:** Place Back/Next (or Submit/Cancel) in a row **after** the field stack with `margin-top: 1rem` minimum, or as the last children in the same flex column so `gap` applies between the last field group and the buttons. **Wrong:** buttons visually touching the last input. **Right:** predictable separation using the same spacing system as the rest of the page.
- **Desktop button width:** On **desktop** admin and wizard flows, do **not** make every action a **full-width block** spanning the content column (`width: 100%` on the button or a stretching flex child). That pattern is for **narrow / mobile** viewports. **Right:** content-sized buttons, or a **horizontal** action row (`display: flex; flex-direction: row; flex-wrap: wrap; gap: 1rem; justify-content: flex-start` or `space-between`) with Back/secondary left-aligned and primary right-aligned when appropriate. Put a lone “Back to …” link or tertiary action **inline** under the page title or in a compact toolbar row—not a billboard-wide bar. **Wrong:** a single `kyn-button` stretched edge-to-edge below the subtitle on a wide screen.
- **Wizard / stepper width (desktop):** Place **kyn-page-title (if present), horizontal stepper, step body, and Back/Next** inside the **same** centered wrapper as every other full page (`width: min(100%, 1536px); margin: 0 auto`, or **`1280px`** only when the prompt explicitly asks for a compact reading column—then apply that cap to the **whole** wizard block, not just the fields). **Wrong:** the “chimney”—a **full-width** stepper across `main` while the fields sit in a **small** centered card (`max-width` ~400–560px) with empty whitespace on both sides. **Wrong:** stepper and form using **different** max-widths so the progress rail looks disconnected from the body.
- **Wizard actions stay in `main`:** Back/Next (or Submit/Cancel) for the step belong in an action row **immediately after** the field stack **inside the same column** as the fields. **Wrong:** putting wizard navigation in **`kyn-footer`** slots or in a bar that spans the **viewport** width so Back and Next sit at the **far left and far right** of the screen, visually unrelated to the form. **`justify-content: space-between`** is fine **only** on a row whose width is the **form column** (the centered wrapper), not on a full-bleed strip aligned to the stepper ends only.

### Action bars / button rows (non-wizard)

For detail pages, agent management, or any page that needs a **row of action buttons** (Deploy, Edit, Manage, etc.) outside a wizard context:

- Keep the action row **on the main `kd-grid`** by placing it in a full-span grid column, then use a flex row **inside that column**: `display: flex; flex-direction: row; flex-wrap: wrap; gap: 1rem; align-items: center;`.
- Any row containing multiple buttons, button-like links, or action triggers must use explicit horizontal gap spacing. Treat adjacent actions that visually touch or fuse into one block as a failed output.
- **Left-align by default** on desktop (`justify-content: flex-start`).
- Use `justify-content: space-between` **only** when there are distinct left and right action groups (e.g. a drawer trigger on the left and a secondary action on the right — the canonical toolbar pattern). For a homogeneous row of buttons, left-align with `flex-start`.
- **Wrong:** abandoning the Foundation grid for page interior layout. **Right:** `kd-grid` for the page body, with the action row as a flex container inside its spanning grid column.

## 3e. Catalog and listing cards (metadata vs actions)

Prompts for **catalogs**, **agent lists**, **tile grids**, or “status + type + deployment” on each item often produce a **bottom row of three undifferentiated text strings** (e.g. `active`, `Not deployed`, `specialist`). That reads as **broken ghost buttons** or mystery controls—not enterprise UI.

- **Read-only facts** (lifecycle status, deployment state, agent/architecture type) are **metadata**, not primary actions. Do **not** lay them out as three equal-weight bare words with no container, label, or component affordance.
- **Prefer**, when available in CEM for the target package: **tags** for categories/keywords, **badges** or **status** treatments for state, and a **single clear primary action** (e.g. “View details”, “Open”) if the prompt asks for navigation—usually one actual `kyn-button` (or link styled per pattern), not three fake buttons.
- **Structure:** Keep title + description + tags in the card body; put status/type/deployment in a **footer row** with visual hierarchy—e.g. small caps/label + value, icon + label patterns from the design system, or pill chips with distinct backgrounds—so users see **badges**, not **clickable-looking noise**.
- **Wrong:** three plain text tokens in a horizontal row with no styling difference from body copy. **Wrong:** using `kyn-button kind="ghost"` or tertiary for pure metadata unless the prompt explicitly asks for those controls to be interactive. **Right:** the second pass fix: labeled or iconic status, deployment indicator, and type as **pills/badges/tags** consistent with Shidoka tokens.
- **Wrong:** **duplicating** the same description (or paragraph) twice inside one card, or adding a **second row of tags** that only repeats the first row with **#hashtags**—that is noise, not “more enterprise UI.” **Right:** one **short** description block; **one** tag/category row (or one row for categories + one clearly labeled row for **status vs type** only when semantics differ).
- **Wrong:** putting a **success/checkmark** icon on **every** tag when those tags are **categories or keywords**—checkmarks read as “done” or “selected,” not taxonomy. Use neutral **tags** for categories; reserve **status** treatments for lifecycle/deployment state. **Right:** at most one **status** badge (or icon + label) for state; categories/tags without misleading success icons unless the prompt is truly about selection/completion.
- **Sizing:** Badges, tags, and pill treatments must hug their content. Keep them intrinsic width (`display: inline-flex`, `width: fit-content`, `max-width: 100%`, `align-self: flex-start`) and do **not** stretch them with `width: 100%`, `flex: 1`, or parent `justify-content: space-between` layouts unless the user explicitly asks for a full-width segmented control.
- **Catalog page chrome:** When the prompt asks for **search**, **filters**, and **sorting**, the page must include a **toolbar row** above the grid (e.g. `kyn-text-field` for search, `kyn-dropdown` or filter controls, sort control)—not only a bare card grid. **Wrong:** a title + subtitle + cards while **omitting** all filter/search UI that the requirements listed.
- **Overlay-in-card policy (dropdowns/menus/popovers):** If a card/widget contains an overlay control (for example `kyn-dropdown`), the expanded panel must render above/outside card bounds with no clipping and no widget/card height growth while open. This must hold for both mouse-open and keyboard-open interactions.
- **Authoring guard:** Prefer component-level top-layer/portal behavior when available. Do not rely on local `overflow: hidden/auto/clip` containers for overlay rendering, and do not add ad-hoc per-page hacks to force visibility when a component exposes a documented host API/hook.
- **Acceptance checks (required):** (1) open dropdown near card bottom edge; (2) menu remains fully visible beyond boundary; (3) neighboring cards/layout do not clip it; (4) widget/card dimensions remain unchanged while open; (5) same behavior in registration/deployment wizard cards and schema/config cards.
- **Card interior spacing:** Put title, description, status badge, and tag row inside **one** column stack with a **single** vertical rhythm — e.g. `display: flex; flex-direction: column; gap: 1rem; width: 100%;` (or `1.5rem`). **Wrong:** bare siblings with **no** gap so the **badge sits flush** on the description, or **ad hoc** `margin-top` on only one block. **Wrong:** `justify-content: space-between` + **fixed card height** so the middle “floats” and tags pin to the bottom—use **content-sized** card height, **`align-items: start`** on the grid, and spacing from **`gap`** only.

## 3c. Local-nav clearance belongs to `kyn-ui-shell`

- When a page uses `kyn-ui-shell` with `kyn-local-nav`, the shell already reserves horizontal space for slotted `main` and `kyn-footer`.
- Keep `main` as a direct child of `kyn-ui-shell`. Do not wrap `main` in another shell/body container and do not move the centered content frame outside `main`, or the shell cannot apply local-nav clearance correctly during resize.
- Keep the normal page gutter on `main`, but do **not** add extra page-scoped `padding-left`, `margin-left`, or custom wrapper offsets to clear the local nav.
- When `kyn-local-nav` starts collapsed or does **not** have `pinned`, keep the normal `main` gutter only. Do **not** reserve collapsed-rail width with extra `padding-left`, `margin-left`, spacer columns, or shell-specific wrapper math.
- Keep the native `kyn-footer` markup too: use the normal copyright slot, not a fake full-width wrapper around the slot content.
- Do **not** set `width`, `max-width`, or `margin: 0 auto` on the `kyn-footer` host in local-nav pages. Let `kyn-ui-shell` manage the slotted footer host positioning and clearance; otherwise the footer can drift back under the nav rail.
- **Wrong:** `main { padding-left: calc(var(--kd-local-nav-width, ...) + ... ) }`, `kyn-footer { padding-left: ... }`, or a custom footer-content-frame wrapper on top of `kyn-ui-shell`. **Right:** `<main style="padding: max(var(--kd-shell-header-clearance, 0px), 2rem) var(--kd-page-gutter, 2rem) var(--kd-page-gutter, 2rem);">` plus native `kyn-footer`, while `kyn-ui-shell` handles nav clearance.
- Horizontal overflow in the shell route is a hard failure. Do **not** paper over bad width math with `overflow-x: hidden` / `clip` on shell, `main`, route, or grid wrappers; fix the layout contract so `document.documentElement.scrollWidth <= window.innerWidth` on first paint and after local-nav state changes.
- Fixed overlays such as command palettes, dialogs, and scrims must stay out of normal layout flow when closed. Use `position: fixed` plus a real hidden state (`hidden`, `display: none`, or equivalent), and do **not** leave behind spacer divs, reserved overlay rows, or persistent wrappers that can widen the page grid.
- If the UI includes a **command palette** that behaves like a **backdrop-backed modal dialog**, default to **`kyn-modal`** rather than a hand-rolled `<div role="dialog">` overlay. Put the search field and command results inside the modal body, keep the modal closed on initial render, and only use a bespoke dialog shell when the user explicitly asks for a non-modal/custom palette or when you must preserve an existing local implementation in place.

## 3d. Shell routes must stay full width

- In consuming apps, the route/container that renders `kyn-ui-shell` must stay full width.
- Do **not** place `kyn-ui-shell` inside a centered app frame like `width: min(980px, ...)`, `max-width: 980px`, or `margin: 0 auto`.
- If the app has a route picker, top-level dev nav, or demo controls outside the shell, keep those in a separate centered wrapper and render the shell route beneath them at `width: 100%`.
- **Wrong:** app-level wrapper with centered max-width around both the route nav and the `kyn-ui-shell`, which makes `main` and `kyn-footer` look artificially narrow. **Right:** centered wrapper for the nav only, plus a full-width shell route mount.

## 3a. Foundation grid vs widget gridstack

- **Shidoka Foundation grid** (`kd-grid` / `kd-grid__col--*`) is the default responsive layout system for **all interior content inside `<main>` unless the prompt explicitly says otherwise**. Use a `kd-grid` wrapper as the standard interior layout primitive for page title, toolbar, widget region, table, forms, and detail content.
- **`kyn-widget-gridstack`** is only for a **dashboard widget grid** when the user explicitly asks for a grid of widget-wrapped charts or for resizable/reorderable widgets.
- **Do not** use gridstack for single-chart pages, generic content layout, or the ordinary title → toolbar → chart/table flow. Those stay on the Foundation grid.
- **Single-column content still stays on `kd-grid`.** Use full-span columns such as `kd-grid__col--sm-4 kd-grid__col--md-8 kd-grid__col--lg-12` instead of dropping back to a separate page-level flex wrapper.
- **Do not** invent custom page-level CSS grids for the main body. Use the Foundation grid for page responsiveness; use gridstack only as the widget-grid layer when required.
- **Chart vs content-only cards:** Default `min-height: 420px` and `cellHeight: 420` are for **chart** dashboards. **Summary / catalog / agent cards** with only text, tags, and buttons must **not** be stretched to that chart height—users will see an awkward empty gap under the buttons. Use a static grid for those cards. Keep the page grid/grid wrapper itself `align-items: start`, but when content widgets are side by side in the same desktop row, stretch only those sibling card wrappers so the tallest card sets the row height and the peer cards match it. A good default is `.content-widget-card { display: flex; min-width: 0; align-self: stretch; }`, `.content-widget-card > kyn-widget { height: 100%; }`, `.content-widget-body { display: flex; flex-direction: column; gap: 1rem; min-height: 100%; height: 100%; }`, and `.content-widget-actions { margin-top: auto; display: flex; justify-content: center; }`. When those same cards stack on mobile, let them return to natural content height and ordinary row spacing. Do not add chart-style `flex: 1`, tall min-heights, or `height: 100%` unless the layout needs row-matched sibling widgets.

### `main-stack kd-grid` is one page-grid element

Treat the canonical wrapper `<div class="main-stack kd-grid">` as the page grid element itself, not as a flex wrapper plus a separate nested grid. Do **not** emit page-scoped or component-scoped CSS such as `.main-stack { display: flex; flex-direction: column; gap: 1.5rem; width: min(100%, 1536px); margin: 0 auto; }` on that same element, because it overrides Foundation `kd-grid` and collapses dashboard widgets into full-width stacked rows.

If the canonical wrapper needs extra help, keep the adjustments grid-safe, for example:
```css
.main-stack.kd-grid { row-gap: 24px; }
```
Only reach for nested-grid centering overrides when the repo truly contains a separate outer wrapper and a different inner `kd-grid` element. That is not the default full-page contract.

### When NOT to use `kd-grid`

Break out of `kd-grid` only when the prompt explicitly asks for another layout primitive or when the component itself owns layout. For ordinary single-column flows (wizard steps, detail pages, single-column forms), keep using the page `kd-grid` and place those sections in full-span columns.

## 3b. Layout rhythm: page title → toolbar → content

When the page has a **kyn-page-title** and one or more **actions** (e.g. "Open Message" drawer trigger, "Add" button):

1. **Page title:** Use `<kyn-page-title headLine="…" pageTitle="…" subTitle="…"></kyn-page-title>`. By default use all three: **headLine** (section/category, e.g. "Dashboard"), **pageTitle** (main title, e.g. "Overview"), **subTitle** (short description). This produces the standard arrangement: headline above, large title, then subtitle text, then toolbar.
2. **Spacing after title:** Add a wrapper or margin so the next block is not flush under the title. Use `margin-bottom: 1rem` on the title wrapper, or a toolbar div with `margin-top: 1rem` (or `var(--kd-spacing-16, 1rem)`). If the page already uses one centered stack wrapper with `gap`, that gap is the spacing system; do not add extra default margin on both the title and toolbar.
3. **Toolbar row:** When there are actions (drawer anchor, primary button, search), put them in a single row with consistent spacing:
   - Wrap in a div: `style="display: flex; justify-content: space-between; align-items: center; gap: 1rem;"`.
   - Put the side-drawer (with its anchor button) and/or primary action buttons in this row so they align horizontally and are clearly separated from the title.
   - If the row contains multiple sibling actions, they must have explicit visible separation using `gap: 0.75rem` or `gap: 1rem`; do not rely on component default margins or source whitespace.
   - Even when the toolbar uses `justify-content: space-between` for left/right groups, the actions inside each group still need explicit gap spacing and must never visually touch.
4. **Content below:** After the toolbar, let the parent stack gap create the default spacing before the main content (cards, widget grid, table, list). Only add extra top margin/padding if the user explicitly asks for a looser layout.

Never place the side-drawer anchor button directly under the page title with no spacing. Always use a toolbar or at least `margin-top: 1rem` between the title and the first action.

**Adapter quirks belong in adapter notes, not in the default layout rule.** Keep the page contract above framework-neutral. Only add framework-specific handling when a custom-element adapter truly needs it: for example Vue property bindings for Lit-backed props, Svelte custom-element event/property wiring or HMR remounts, and React post-mount property hydration for `gridstackConfig` or `kd-chart` data objects. Those quirks do not change the default shell/body layout contract.

For static (non-interactive) widget dashboards, prompt controls arrangement as rows x columns (for example `2x3`, `3x2`, `24x3`). If arrangement is omitted or the dashboard intent is weak, fall back to the **reference dashboard starter** instead of treating one widget layout as universal dashboard truth. Keep original dimensions unless prompt overrides them: 24px gap, widget/card `min-height: 420px`, `.dashboard-chart-host { flex: 1; min-height: 0; width: 100%; }`, and chart fill (`height="280"` plus `style="width: 100%; display: block;"` with `maintainAspectRatio: false`, `responsive: true`). Do not add `align-items: start` on the chart-grid `kd-grid` container by default, and do not pair a default chart-host floor with `justify-content: flex-end`. If the prompt explicitly gives widget width/height, set widget dimensions to those values directly and let charts fill the declared widget width.

For multi-route dashboard shells where Overview routes into named destination pages such as Health, Costs, Capacity, or Compliance, keep those destination pages simple but real instead of reducing them to placeholder prose. Default body shape: one `kd-grid` page wrapper, one full-span `kyn-page-title`, then two side-by-side `kyn-widget` cards using `kd-grid__col--sm-4 kd-grid__col--md-4 kd-grid__col--lg-6`. Each card should have a small internal content stack with a lead sentence and a structured list or action-oriented follow-up points so the page reads like a legitimate routed landing screen, not a temporary stub. If those destination-page widgets include CTAs that imply navigation, every CTA must resolve to a declared route target and be wired through the framework router rather than rendered as an inert label-only button.

Keep closed overlay hosts such as `kyn-modal` out of the normal centered content stack when possible. Do not place a closed modal host inline between the toolbar and the chart/widget region, because the host element can still participate in layout and create phantom spacing.

## 4. Data table (required wrapper)

Data tables must live inside a **scrollable wrapper** so they don't overflow the viewport. Put **kyn-table-container** (and **kyn-table** inside it) inside this div:

```html
<div
  style="width: 100%; overflow: auto; max-height: 360px;"
>
  <kyn-table-container>
    <kyn-table>
      <kyn-thead
        ><kyn-header-tr><kyn-th>Col1</kyn-th>...</kyn-header-tr></kyn-thead
      >
      <kyn-tbody>
        <!-- kyn-tr > kyn-td rows (e.g. 9 rows if user asks for 9-row table) -->
      </kyn-tbody>
    </kyn-table>
  </kyn-table-container>
</div>
```

Use **kyn-thead**, **kyn-header-tr**, **kyn-th**, **kyn-tbody**, **kyn-tr**, **kyn-td** only (no native `<table>`). **Table headers required:** Always include `kyn-thead` with one `kyn-header-tr` and one `kyn-th` per data column (e.g. Name, Role, Status). The header row must contain the column labels; do not leave thead empty or omit it. **One cell per column:** Each `kyn-tr` must contain exactly one `kyn-td` per column, in the same order as `kyn-th`; otherwise the table will render with misaligned columns. Give the table wrapper **full width:** `style="width: 100%; overflow: auto; max-height: 360px;"` so the table spans the main content area. Do **not** add a border or border-radius by default; only add those when the user explicitly requests a bordered table treatment.

- **Default data unless user supplies JSON:** If the user does not provide table data or column definitions, generate boilerplate columns and rows inline so the table renders as a complete example.
- **Reference starter table scaffold:** Unless the user asks for advanced table behavior, the reference starter may use a 5-row table with a `kyn-table-toolbar`, a scroll wrapper, explicit headers, and predictable text data. Treat that as starter scaffolding, not as the only valid dashboard table composition.
- **Prompted row-count contract (required):** If the prompt requests a row count (for example: "5-row data table", "5 row table", "table with 5 rows", or "build a 5-row data table with dummy data"), generate exactly that many data objects and exactly that many rendered `kyn-tr` rows.
- **Dynamic generation requirement (required):** Build rows from a data collection (`tableData`) using framework iteration (`{#each ...}`, `map`, `repeat`, or `v-for`); do not hand-write a fixed number of row tags when the prompt asks for dynamic/dummy data.
- **Validation before output:** `tableData.length` must equal the requested row count, and each row object must include one value per column so every generated `kyn-tr` has the same number of `kyn-td` as header `kyn-th`.

## 4b. Charts (line graph, bar chart, etc.)

**Always use the Shidoka charts component `<kd-chart>`.** Never implement a chart with raw `<svg>`, `<canvas>`, `<polyline>`, `<path>`, or any custom-drawn graphic. When the user asks for a line graph, bar chart, pie chart, or any chart, the only correct implementation is **`<kd-chart>`** with the appropriate `type`, `.labels`, `.datasets`, and `.options`. In Vue, React, or Lit, use `<kd-chart>` (and ensure the app has installed and registered `@kyndryl-design-system/shidoka-charts`).

When the page includes a **line graph**, **bar chart**, or other **kd-chart**, it must **span the full width** of the main content so output is consistent across runs. Do not use `max-width` or a narrow wrapper unless the user explicitly asks for one.

- **Wrapper:** `<div style="width: 100%; margin-bottom: 1.5rem;">` around the chart.
- **Chart:** `kd-chart` with `style="width: 100%; display: block;"` and `.options=${{ maintainAspectRatio: false, responsive: true }}` so it fills the wrapper. Set `height="360"` by default (or similar) for a fixed height; the width follows the container.
- **Chart property timing:** Assign `labels`, `datasets`, and `options` on the real `kd-chart` element only after the element has mounted and the custom element definition is ready. Pre-upgrade assignment can leave charts blank even when the data is valid. In vanilla JS, wait for `customElements.whenDefined('kd-chart')`; in framework consumers, do the equivalent post-mount hydration against the element reference.
- **Chart colors:** Default to Shidoka theme by including **`options.colorPalette = 'categorical'`** unless the user or context requires another Shidoka palette (e.g. `sequential01`, `statusDark`). In React, do **not** set `colorPalette` as a standalone `kd-chart` prop/attribute or custom-element property; place it inside the `options` object that you assign on the real `kd-chart` element. If a palette value is unknown or not from `@kyndryl-design-system/shidoka-charts`, fall back to `'categorical'`. **Never emit dataset or chart paint overrides by default** such as `backgroundColor`, `borderColor`, `hoverBackgroundColor`, `hoverBorderColor`, hex colors, `rgb(...)`, or `rgba(...)`; `shidoka-charts` owns the default chart colors. Only preserve or author those overrides when the user explicitly asks for custom chart styling. If charts render with generic blue/purple that are not Shidoka tokens, the app likely is not loading `@kyndryl-design-system/shidoka-foundation/css/root.css` (and index.css) in global CSS, so the palette resolver falls back to non-Shidoka values.
- **Do not invent `colorPalette` shapes:** `getComputedColorPalette()` only accepts named keys from `shidoka-charts` (e.g. `categorical`) or resolvable token **names** such as `--kd-color-data-viz-categorical-01-01`. Arrays of `var(--kd-color-...)` or other arbitrary strings are **not** supported — the resolver yields an **empty palette**, and **line charts** especially show a blank plot (no stroke color). Use `colorPalette: 'categorical'` inside `options`. For **grouped** bar charts with two datasets, expect **two** legend colors (one per series), not one color per X category — that is correct for the data shape.
- **Import:** `import '@kyndryl-design-system/shidoka-charts/components/chart';` (or the path appropriate to the story file; see considerations.md "Import paths for story files").

### Line graph specifically (user asks for "line graph" or "line chart")

When the user asks for a **line graph** (or "line chart"), generate a **readable line chart**, not an area chart and not a chart without axes.

- **Type:** Always `type="line"`.
- **No area fill:** Each dataset must have **`fill: false`** so the chart shows a line only, not a filled area under the line. Do not use default fill.
- **Visible axes:** Set **`scales`** in options so the chart has visible X and Y axes and labels. Example: `scales: { x: { display: true, title: { display: true, text: 'Category' } }, y: { display: true, title: { display: true, text: 'Value' }, beginAtZero: true } }`. Without this, the chart can render with no axes and be unreadable.
- **Basic dummy data:** Use a **labels** array (e.g. `['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']`) and one or two **datasets** with a **data** array of numbers (e.g. `[12, 19, 8, 15, 22, 18]`). Include a **label** per dataset. For default categorical examples, prefer `Dataset 1` and `Dataset 2` unless the user provides semantic labels.
- **Default data unless user supplies JSON:** If the user does not provide chart data, generate boilerplate `labels`, `datasets`, and `options` inline so the chart renders as a complete example.
- **Minimum default series count:** A default line chart must have **at least two datasets**. Do not emit a single default line unless the user explicitly asks for one series only.
- **Chart chrome (default):** Keep chart header/title + controls visible by default for standalone charts. In widget-grid charts, use a compact widget-chart treatment by default: keep `chartTitle` visible, hide `description` and controls, and avoid adding a second descriptive block that repeats nearby widget copy unless the user explicitly asks for richer chart-owned chrome.
- **Legend placement:** In the canonical full-page shell, do **not** put the legend at the top. The chart controls live in that area. Keep the legend visible by default, but place it at the bottom (`plugins.legend = { display: true, position: 'bottom' }`) so it sits below the x-axis label unless the user explicitly asks for a different placement.
- **Example (conceptual):** `labels: ['Jan','Feb','Mar','Apr','May','Jun']`, `datasets: [{ label: 'Dataset 1', data: [12, 19, 8, 15, 22, 18], fill: false, tension: 0.3 }, { label: 'Dataset 2', data: [9, 14, 15, 18, 21, 20], fill: false, tension: 0.3 }]`, `options: { ... existing ..., colorPalette: 'categorical', scales: { x: { display: true }, y: { display: true, beginAtZero: true } } }`.

### Bar chart specifically (user asks for "bar chart")

- **Type:** Always `type="bar"`.
- **Visible axes:** Set `scales` so X and Y axes are visible and labeled.
- **Minimum default series count:** A default bar chart must have **at least two datasets**. Do not emit a single default bar series unless the user explicitly asks for one series only.
- **Default data unless user supplies JSON:** If the user does not provide bar-chart data, generate a complete example with shared labels and at least two datasets.
- **Legend placement:** In the canonical full-page shell, do **not** put the legend at the top. Keep the legend visible by default, but place it at the bottom (`plugins.legend = { display: true, position: 'bottom' }`) unless the user explicitly asks for a different placement.

## 5. Side drawer (inside main, anchor button)

**kyn-side-drawer** goes **inside** `<main>`. The trigger is a **kyn-button** with **slot="anchor"**. Use **kind="tertiary"** for the anchor when it is a secondary action (e.g. "Open details"). **Drawer header required:** Always set **`titleText`** (headline) and **`labelText`** (subheader) on `kyn-side-drawer` so the drawer panel shows a visible header with title and description. Example:

```html
<kyn-side-drawer size="md" titleText="Details" labelText="Use this drawer for filters, details, or additional actions.">
  <kyn-button slot="anchor" kind="tertiary">Open details</kyn-button>
  <ul style="list-style: none; padding: 0; margin: 0;">
    <li style="padding: 0.5rem 0;">Item 1</li>
  </ul>
</kyn-side-drawer>
```

**Do NOT add the `open` attribute** to kyn-side-drawer unless the user explicitly asks for "drawer open by default" or "drawer expanded on load". By default the drawer is closed and opens when the user clicks the anchor button. Use the exact label text the user asks for; otherwise use a neutral default like `Open details`.

Keep the side-drawer footer/buttons visible by default unless the user explicitly asks to hide them. The Storybook default footer labels are `Ok`, `Cancel`, and `Secondary`.

If the prompt also includes a modal/dialog, keep `kyn-modal` closed by default as well. Do **not** add the `open` attribute unless the user explicitly asks for the modal to be visible on initial render.

For header/nav/workspace-switcher canon and other full-page defaults, use the canonical full-page template, recipe, and focused full-page snippets; this file stays layout-focused.

## 6. Full-page Storybook story (meta + decorator)

For full-page layouts, set **parameters.layout** to `'fullscreen'` and use a **decorator** so the story has full height. The decorator must **not** use negative margin — that would cancel the main content indent and break layout.

**WRONG (forbidden):** `margin: var(--kd-negative-page-gutter);` or `margin: -1rem;` or any negative margin on the decorator div. **CORRECT:** decorator wrapper has only `style="min-height: 100vh; width: 100%;"`.

```javascript
const meta: Meta = {
  title: 'Generated/Pages/Your Page Title',
  parameters: { layout: 'fullscreen' },
  decorators: [
    (story) => html`
      <div style="min-height: 100vh; width: 100%;">
        ${typeof story === 'function' ? story() : story}
      </div>
    `,
  ],
};
```


# Required header-nav snippets (generated from header-nav contract)
Use this payload for header/nav generation and refinement. Do not shorten, simplify, or substitute different patterns.
These notes intentionally focus on the highest-risk implementation details that tend to drift in consuming apps: global-switcher composition, all-four-flyouts behavior, workspace-switcher trigger/wiring, and the right-side flyout defaults.
## Styling policy
- Derived summary only: the authority remains the packaged `context/style-policy.json`, `context/component-rules.json`, and `context/pattern-contracts.json` contracts (authored from `src/content/shared-foundation/` and related source inputs).
- Resolve styling ownership in this order: `component`, `patternLayout`, `appGlueGlobal`.
- Choose the narrowest styling layer that can satisfy the requirement.
- Prefer component defaults, design tokens, documented cssProperties, and documented cssParts before authoring CSS.
- Prefer component API truth first, then authored pattern/layout truth, then app glue.
- Do not style component internals or reskin component hosts unless the shared policy explicitly allows the host hook.
- Do not write custom CSS for Shidoka component internals by default. Avoid descendant/internal selectors, undocumented `::part(...)` hooks, and page-local visual reskins of `kyn-*` hosts.
- `kyn-header` stays componentApiOnly. Prefer component defaults, tokens, and documented host hooks first. Allowed host hooks: `--kyn-header-logo-width`; no documented `cssParts` contract. Forbidden selector categories: `shadowInternalSelectors`, `storyOnlyImplementationClasses`, `pageScopedStackingOverrides`.
- `kyn-header-nav` stays componentApiOnly. Prefer component defaults, tokens, and documented host hooks first. Allowed host hooks: `--kyn-global-switcher-max-height`; no documented `cssParts` contract. Forbidden selector categories: `shadowInternalSelectors`, `storyOnlyImplementationClasses`, `pageScopedStructurePatches`.
- `kyn-header-flyouts` stays appGlueCoordinatedHost. Prefer component defaults, tokens, and documented host hooks first. Allowed host hooks: `z-index`, `position`; no documented `cssParts` contract. Forbidden selector categories: `shadowInternalSelectors`, `pageScopedStackingOverrides`, `storyOnlyImplementationClasses`.
- `kyn-header-flyout` stays componentApiOnly. Prefer component defaults, tokens, and documented host hooks first. Allowed host hooks: component defaults only; no documented `cssParts` contract. Forbidden selector categories: `shadowInternalSelectors`, `storyOnlyImplementationClasses`.
- `kyn-workspace-switcher` stays componentPlusPatternWrapper. Prefer component defaults, tokens, and documented host hooks first. Allowed host hooks: `--kyn-workspace-switcher-max-height`, `--kyn-workspace-switcher-left-panel-width`; no documented `cssParts` contract. Forbidden selector categories: `shadowInternalSelectors`, `pageScopedStructurePatches`.
- Pattern/layout CSS for `header-nav` belongs in wrapper/helper classes and shared pattern assets. Use it for layout, spacing, and positioning only. Allowed scopes: `patternWrapper`, `sharedAppGlue`. Common allowed properties: `display`, `flex-direction`, `gap`, `padding`, `min-width`, `max-width`, `box-sizing`, `white-space`.
- Pattern/layout CSS for `workspace-switcher` belongs in wrapper/helper classes and shared pattern assets. Use it for layout, spacing, and positioning only. Allowed scopes: `patternWrapper`, `sharedAppGlue`. Common allowed properties: `width`, `min-width`, `max-width`, `display`, `gap`, `padding`, `margin`, `font-size`, `line-height`, `color`, `transition`.
- App glue target `shell-global` belongs in one app-level global stylesheet. Use it for shell clearance, overlay stacking, and cross-pattern coordination. Allowed scopes: `sharedAppGlue`.
## 1. Header and flyouts
- Use `kyn-header-nav` with `GlobalSwitcher.stories.js#JSONSwitcher` defaults. Treat the bundled structure as the canonical Slotted HTML / JSON pattern for generation.
- Use `global-switcher-scaffold.json` as the machine-readable scaffold for root sections, root icons, categories, and links. It is the packaged equivalent of `GlobalSwitcher.stories.js#JSONSwitcher`.
- The default global switcher sections are Favorites, Recently Viewed, Console, Services, Catalogs, Administration.
- `kyn-header-nav` is the left/global-nav child of `kyn-header`. In frameworks where slot assignment must be explicit, use `slot="left"` on `kyn-header-nav`. Do not invent `slot="nav"`.
- Do not set `auto-open-flyout` in consuming apps. The switcher should start closed so it does not block the page before the user opens it.
- Keep `appTitle` concise when present (default dashboard pages: `Dashboard`), and do not derive it from route/file labels such as `Dashboard1`.
- **Logo:** Unless otherwise specified, render the Kyndryl bridge logo (`bridge-logo-large.svg`) from @kyndryl-design-system/shidoka-foundation/assets/svg/ in the logo slot, with `--kyn-header-logo-width: 120px;`. render the asset inside a wrapper such as `<span slot="logo" style="--kyn-header-logo-width: 120px; display: inline-flex; align-items: center; width: var(--kyn-header-logo-width); max-width: 100%;">`; in consuming apps, prefer a normal asset import plus `<img src={bridgeLogo} ...>` / `<img :src="bridgeLogo" ...>` for the actual logo asset (`bridge-logo-large.svg` by default; same sizing treatment for approved Kyndryl masthead logo asset) with `display: block; width: 100%; max-width: 100%; height: auto;`; do not rely on the SVG intrinsic width, do not use raw inline SVG as the default logo treatment, and do not render plain text "kyndryl" / "Bridge".
- Visible headings are required in horizontal/tabbed and masonry flyouts.
- **Red category headers:** Every `kyn-header-category` in Console, Services, and Administration MUST have BOTH the `heading` attribute (e.g. `heading="Kyndryl Services"`) AND `<span slot="icon">` with circle-stroke.svg from shidoka-icons. Without both, the red category header text does not display.
- Root global-switcher sections must keep their approved inline icons. If a parent-nav row renders without its root icon, it is wrong.
- Canonical root icon assets are `Favorites` -> `recommend-filled.svg`, `Recently Viewed` -> `history.svg`, `Console` -> `console.svg`, `Services` -> `services.svg`, `Catalogs` -> `catalog-management.svg`, `Administration` -> `user-settings.svg`. Use those exact Shidoka icon assets rather than generic menu, chevron-only, or local app icons.
- Do not satisfy parent-nav icon requirements with plain text in `.icon-slot` such as `Recently`, `Console`, `Services`, `Catalogs`, or `Admin`, and do not use glyphs like `★` or `○` as substitutes. Those are regressions; use approved Shidoka icon assets.
- Unless the user explicitly provides custom nav JSON, preserve the bundled default scaffold exactly. Do not reduce the Services tabs, headed categories, or default links.
- Use the `heading` attribute on `kyn-header-category` and keep the `circle-stroke` placeholder icon in `slot="icon"`. This headed-category rule applies to layout modes `grouped-column`, `masonry`, `tabbed-masonry`.
- **Framework adapter rule:** `kyn-header-category` must end up with a real DOM `heading` attribute in any framework. If template syntax does not preserve it, reflect it after mount. Do not switch to fake heading text nodes or a `slot="heading"` workaround.
- **Regression symptom to fix directly:** If Services or Administration masonry shows circle icons plus links but no red heading labels, the DOM `heading` attribute is still missing. Do not work around it with plain text nodes; reflect the attribute on every headed category instead.
- React/custom-element adapter: if `heading={...}` on `kyn-header-category` does not yield a real DOM `heading` attribute, reflect it explicitly after mount (for example with a ref callback/effect calling `element.setAttribute('heading', heading)`).
- Svelte/Vue/custom-element adapter: same **DOM `heading` attribute** requirement—use a `use:` action, `$effect`, or `onMounted` + `setAttribute` on each headed `kyn-header-category` in masonry/tabbed flyouts or red category headers will not render.
- Never emit `<span slot="heading">...</span>`; that slot does not exist.
- Keep Favorites, Recently Viewed, and Catalogs populated instead of leaving them as empty top-level links.
- Console must use slot="links" content with top links plus categories. Default top links are `Bridge Home`, followed by headed categories `Dashboards` -> `All Dashboards`, `Actionable Insights`, `AIOps IT Health Indicators Dashboard`, `Business Console (legacy)`, `Business Service Insights (legacy)`.
- Services must use kyn-tabs with kyn-tab-panel and headed categories. Default tab examples: `Kyndryl Services`: `Applications, Data, & AI` -> `Business Intelligence`, `Storage Migration`, `Visualization, Exploration and Semantic Analytics`; `Cloud Services` -> `Assessment for Microsoft Azure Stack Hyper Converged Infrastructure`, `Private Cloud IaaS/PaaS`, `Rapid Assessments for Enterprise Sustainability`; `Core Enterprise & Z Cloud` -> `Application Management Services for IBM Z and IBM i`, `Managed Extended Cloud IaaS for IBM i on Skytap`, `Managed Extended Cloud IaaS for IBM Z (zCloud)`; `Digital Workplace` -> `Connected Experience`, `Digital Experience Management`, `Modern Device Management Services`; `Network & Edge` -> `Managed Network Services`; `Security & Resiliency` -> `Continuous Controls Monitoring & Management`, `Enterprise Security Compliance Management`, `Intelligent Recovery Service`, `Mass Recovery Model`, `Recovery Retainer Service`, `Security & Network Operations`, `Security Operations as a Platform`, `Sustainability Advisor`, `Vulnerability Management Service` | `Platform Services`: `Application & Business Services` -> `Application Modernization Intelligence`; `Change Management` -> `Guided Change Manager (legacy)`; `Cloud Management` -> `Container Cluster Management`, `FinOps & Cost Optimization Intelligence`; `Data Analytics` -> `Data Fabric`; `Discovery` -> `Discovered Data`, `Discovered Management`; `Inventory` -> `Applications & Resources (legacy)`, `Application Inventory`, `Infrastructure & Cloud Inventory (legacy)`, `Inventory Insights (legacy)`, `Location Dictionary (legacy)`, `Product Dictionary (legacy)`, `Tagging Compliance Report`, `Topology`, `Workstation Inventory (legacy)`; `Knowledge & AI` -> `Agentic AI Designer`, `Artificial Intelligence for IT Operations (legacy)`, `Bridge AI Assist Configuration`, `Knowledge Foundation`; `Provisioning Orchestration & Automation` -> `Actions (legacy)`, `Automation (legacy)`, `Scheduler (legacy)`, `Workflow Executions`; `Toolchain & Pipeline` -> `DevOps Intelligence`, `Machine Learning Operations Pipeline`, `Tool Chain Management`.
- Administration must use kyn-header-categories layout="masonry" with headed categories such as `Access Management` -> `Access Request Management System (ARMS)`, `Bridge Access Management`, `Service Access Management`; `Policy Service` -> `Policy Management (Bundles)`; `Provisioning Orchestration & Administration` -> `Orchestration Administration`; `Service Operations` -> `Auditing`, `Connections Management`, `Logging & Monitoring`, `Sunrise Insights Administration (legacy)`; `Tag Management` -> `AIOps Tagging (legacy)`, `Bridge Tag Management`.
- Do not replace these section skeletons with generic two-column link lists. The right-hand panel should visibly preserve headings, tabs, and masonry/category structure.
- If the Services flyout opens without a visible tab strip containing both `Kyndryl Services` and `Platform Services`, it is wrong.
- If the Services or Administration flyout is missing any bundled default categories or links when the user did not provide custom nav JSON, it is wrong.
- Do not read local story files to recover this pattern. Translate the bundled HTML reference below directly and treat it as more authoritative than higher-level summaries.
- When header composition needs CSS, keep it in wrapper/helper classes such as `.console-links-column`, `.console-links-category`, `.services-tabs-fill`, `.flyout-action-list`, `.user-flyout-card`, and `.ui-impl-switcher`. Do not style Shidoka component internals directly.
- `kyn-header-flyouts` belongs in the right/default slot of `kyn-header`. Do not add `slot="flyouts"`; if a framework requires explicit slotting, keep the flyouts in the component default slot.
## 1b. Complete global-switcher HTML reference (mirrors GlobalSwitcher.stories.js#JSONSwitcher)
This is the exact HTML structure the AI must translate into the target framework. Every section, category heading, icon slot, and nesting level is intentional. Do NOT simplify, flatten, omit category headings, or reduce the default tabs/categories/links when nav JSON is unspecified. Do not attempt to read the Storybook source file at generation time; use the structure below as the self-contained source of truth.
Use only approved icon assets from `@kyndryl-design-system/shidoka-icons`. Canonical root-section icon map: `Favorites` -> `recommend-filled.svg`, `Recently Viewed` -> `history.svg`, `Console` -> `console.svg`, `Services` -> `services.svg`, `Catalogs` -> `catalog-management.svg`, `Administration` -> `user-settings.svg`. Workspace/flyout icon map: trigger chevron -> `chevron-down.svg`, CURRENT status -> `checkmark-filled.svg`, account copy -> `copy.svg`, copied feedback -> `checkmark-filled.svg`. In the workspace switcher **CURRENT** block (account-meta-info), use **16×16** icons only: `shidoka-icons/svg/monochrome/16/checkmark-filled.svg` and `.../16/copy.svg` (inline or import so the checkmark and copy icons render at 16×16).
```html
<kyn-header-nav truncate-links>
  <!-- FAVORITES — simple section: kyn-header-category slot="links" (no heading needed for single-category simple sections) -->
  <kyn-header-link id="favorites" href="javascript:void(0)" hideSearch>
    <span><!-- recommend-filled.svg from @kyndryl-design-system/shidoka-icons --></span>
    Favorites
    <kyn-header-category slot="links">
      <kyn-header-link href="#"><span>Connections Management</span></kyn-header-link>
      <kyn-header-link href="#"><span>Discovered Data</span></kyn-header-link>
      <kyn-header-link href="#"><span>Visualization, Exploration and Semantic Analytics</span></kyn-header-link>
      <kyn-header-link href="#"><span>Topology</span></kyn-header-link>
      <kyn-header-link href="#"><span>Menu item five</span></kyn-header-link>
      <kyn-header-link href="#"><span>Menu item six</span></kyn-header-link>
      <kyn-header-link href="#"><span>Menu Item seven</span></kyn-header-link>
    </kyn-header-category>
  </kyn-header-link>
  <!-- RECENTLY VIEWED — simple section -->
  <kyn-header-link id="recently-viewed" href="javascript:void(0)" hideSearch>
    <span><!-- history.svg from @kyndryl-design-system/shidoka-icons --></span>
    Recently Viewed
    <kyn-header-category slot="links">
      <kyn-header-link href="#"><span>Topology</span></kyn-header-link>
      <kyn-header-link href="#"><span>Discovered Data</span></kyn-header-link>
      <kyn-header-link href="#"><span>Connections Management</span></kyn-header-link>
      <kyn-header-link href="#"><span>Sustainability Advisor</span></kyn-header-link>
      <kyn-header-link href="#"><span>Discovered Data</span></kyn-header-link>
      <kyn-header-link href="#"><span>Private Cloud IaaS/PaaS</span></kyn-header-link>
      <kyn-header-link href="#"><span>Mass Recovery Model</span></kyn-header-link>
      <kyn-header-link href="#"><span>Assessment for Microsoft Azure Stack Hyper Converged Infrastructure</span></kyn-header-link>
      <kyn-header-link href="#"><span>Private Cloud IaaS/PaaS</span></kyn-header-link>
      <kyn-header-link href="#"><span>Rapid Assessments for Enterprise Sustainability</span></kyn-header-link>
    </kyn-header-category>
  </kyn-header-link>
  <kyn-header-divider></kyn-header-divider>
  <!-- CONSOLE — single-column with top links + headed category -->
  <kyn-header-link id="console" href="javascript:void(0)" hideSearch>
    <span><!-- console.svg from @kyndryl-design-system/shidoka-icons --></span>
    Console
    <div slot="links" class="console-links-column">
      <kyn-header-link href="#"><span>Bridge Home</span></kyn-header-link>
      <kyn-header-category heading="Dashboards" class="console-links-category">
        <span slot="icon"><!-- circle-stroke.svg (16×16) from @kyndryl-design-system/shidoka-icons/svg/monochrome/16/ --></span>
        <kyn-header-link href="#"><span>All Dashboards</span></kyn-header-link>
        <kyn-header-link href="#"><span>Actionable Insights</span></kyn-header-link>
        <kyn-header-link href="#"><span>AIOps IT Health Indicators Dashboard</span></kyn-header-link>
        <kyn-header-link href="#"><span>Business Console (legacy)</span></kyn-header-link>
        <kyn-header-link href="#"><span>Business Service Insights (legacy)</span></kyn-header-link>
      </kyn-header-category>
    </div>
  </kyn-header-link>
  <!-- SERVICES — tabbed layout with masonry categories per tab -->
  <kyn-header-link id="services" href="javascript:void(0)">
    <span><!-- services.svg from @kyndryl-design-system/shidoka-icons --></span>
    Services
    <kyn-tabs tabSize="md" slot="links" class="services-tabs-fill">
      <kyn-tab slot="tabs" id="kyndryl" selected>Kyndryl Services</kyn-tab>
      <kyn-tab slot="tabs" id="platform">Platform Services</kyn-tab>
      <kyn-tab-panel tabId="kyndryl" noPadding visible>
        <kyn-header-categories layout="masonry" .limitRootLinks=${false}>
          <kyn-header-category heading="Applications, Data, & AI">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Business Intelligence</span></kyn-header-link>
            <kyn-header-link href="#"><span>Storage Migration</span></kyn-header-link>
            <kyn-header-link href="#"><span>Visualization, Exploration and Semantic Analytics</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Cloud Services">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Assessment for Microsoft Azure Stack Hyper Converged Infrastructure</span></kyn-header-link>
            <kyn-header-link href="#"><span>Private Cloud IaaS/PaaS</span></kyn-header-link>
            <kyn-header-link href="#"><span>Rapid Assessments for Enterprise Sustainability</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Core Enterprise & Z Cloud">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Application Management Services for IBM Z and IBM i</span></kyn-header-link>
            <kyn-header-link href="#"><span>Managed Extended Cloud IaaS for IBM i on Skytap</span></kyn-header-link>
            <kyn-header-link href="#"><span>Managed Extended Cloud IaaS for IBM Z (zCloud)</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Digital Workplace">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Connected Experience</span></kyn-header-link>
            <kyn-header-link href="#"><span>Digital Experience Management</span></kyn-header-link>
            <kyn-header-link href="#"><span>Modern Device Management Services</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Network & Edge">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Managed Network Services</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Security & Resiliency">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Continuous Controls Monitoring & Management</span></kyn-header-link>
            <kyn-header-link href="#"><span>Enterprise Security Compliance Management</span></kyn-header-link>
            <kyn-header-link href="#"><span>Intelligent Recovery Service</span></kyn-header-link>
            <kyn-header-link href="#"><span>Mass Recovery Model</span></kyn-header-link>
            <kyn-header-link href="#"><span>Recovery Retainer Service</span></kyn-header-link>
            <kyn-header-link href="#"><span>Security & Network Operations</span></kyn-header-link>
            <kyn-header-link href="#"><span>Security Operations as a Platform</span></kyn-header-link>
            <kyn-header-link href="#"><span>Sustainability Advisor</span></kyn-header-link>
            <kyn-header-link href="#"><span>Vulnerability Management Service</span></kyn-header-link>
          </kyn-header-category>
        </kyn-header-categories>
      </kyn-tab-panel>
      <kyn-tab-panel tabId="platform" noPadding>
        <kyn-header-categories layout="masonry" .limitRootLinks=${false}>
          <kyn-header-category heading="Application & Business Services">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Application Modernization Intelligence</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Change Management">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Guided Change Manager (legacy)</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Cloud Management">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Container Cluster Management</span></kyn-header-link>
            <kyn-header-link href="#"><span>FinOps & Cost Optimization Intelligence</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Data Analytics">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Data Fabric</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Discovery">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Discovered Data</span></kyn-header-link>
            <kyn-header-link href="#"><span>Discovered Management</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Inventory">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Applications & Resources (legacy)</span></kyn-header-link>
            <kyn-header-link href="#"><span>Application Inventory</span></kyn-header-link>
            <kyn-header-link href="#"><span>Infrastructure & Cloud Inventory (legacy)</span></kyn-header-link>
            <kyn-header-link href="#"><span>Inventory Insights (legacy)</span></kyn-header-link>
            <kyn-header-link href="#"><span>Location Dictionary (legacy)</span></kyn-header-link>
            <kyn-header-link href="#"><span>Product Dictionary (legacy)</span></kyn-header-link>
            <kyn-header-link href="#"><span>Tagging Compliance Report</span></kyn-header-link>
            <kyn-header-link href="#"><span>Topology</span></kyn-header-link>
            <kyn-header-link href="#"><span>Workstation Inventory (legacy)</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Knowledge & AI">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Agentic AI Designer</span></kyn-header-link>
            <kyn-header-link href="#"><span>Artificial Intelligence for IT Operations (legacy)</span></kyn-header-link>
            <kyn-header-link href="#"><span>Bridge AI Assist Configuration</span></kyn-header-link>
            <kyn-header-link href="#"><span>Knowledge Foundation</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Provisioning Orchestration & Automation">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>Actions (legacy)</span></kyn-header-link>
            <kyn-header-link href="#"><span>Automation (legacy)</span></kyn-header-link>
            <kyn-header-link href="#"><span>Scheduler (legacy)</span></kyn-header-link>
            <kyn-header-link href="#"><span>Workflow Executions</span></kyn-header-link>
          </kyn-header-category>
          <kyn-header-category heading="Toolchain & Pipeline">
            <span slot="icon"><!-- circle-stroke icon SVG --></span>
            <kyn-header-link href="#"><span>DevOps Intelligence</span></kyn-header-link>
            <kyn-header-link href="#"><span>Machine Learning Operations Pipeline</span></kyn-header-link>
            <kyn-header-link href="#"><span>Tool Chain Management</span></kyn-header-link>
          </kyn-header-category>
        </kyn-header-categories>
      </kyn-tab-panel>
    </kyn-tabs>
  </kyn-header-link>
  <!-- CATALOGS — simple section -->
  <kyn-header-link id="catalogs" href="javascript:void(0)" hideSearch>
    <span><!-- catalog-management.svg from @kyndryl-design-system/shidoka-icons --></span>
    Catalogs
    <kyn-header-category slot="links">
      <kyn-header-link href="#"><span>Bridge Private Catalog</span></kyn-header-link>
      <kyn-header-link href="#"><span>Bridge Service Catalog</span></kyn-header-link>
      <kyn-header-link href="#"><span>Enablement Catalog</span></kyn-header-link>
      <kyn-header-link href="#"><span>Orchestration Catalog</span></kyn-header-link>
    </kyn-header-category>
  </kyn-header-link>
  <!-- ADMINISTRATION — masonry layout with headed categories -->
  <kyn-header-link id="administration" href="javascript:void(0)" hideSearch>
    <span><!-- user-settings.svg from @kyndryl-design-system/shidoka-icons --></span>
    Administration
    <kyn-header-categories slot="links" layout="masonry" maxColumns="2" .limitRootLinks=${false}>
      <kyn-header-category heading="Access Management">
        <span slot="icon"><!-- circle-stroke icon SVG --></span>
        <kyn-header-link href="#"><span>Access Request Management System (ARMS)</span></kyn-header-link>
        <kyn-header-link href="#"><span>Bridge Access Management</span></kyn-header-link>
        <kyn-header-link href="#"><span>Service Access Management</span></kyn-header-link>
      </kyn-header-category>
      <kyn-header-category heading="Policy Service">
        <span slot="icon"><!-- circle-stroke icon SVG --></span>
        <kyn-header-link href="#"><span>Policy Management (Bundles)</span></kyn-header-link>
      </kyn-header-category>
      <kyn-header-category heading="Provisioning Orchestration & Administration">
        <span slot="icon"><!-- circle-stroke icon SVG --></span>
        <kyn-header-link href="#"><span>Orchestration Administration</span></kyn-header-link>
      </kyn-header-category>
      <kyn-header-category heading="Service Operations">
        <span slot="icon"><!-- circle-stroke icon SVG --></span>
        <kyn-header-link href="#"><span>Auditing</span></kyn-header-link>
        <kyn-header-link href="#"><span>Connections Management</span></kyn-header-link>
        <kyn-header-link href="#"><span>Logging & Monitoring</span></kyn-header-link>
        <kyn-header-link href="#"><span>Sunrise Insights Administration (legacy)</span></kyn-header-link>
      </kyn-header-category>
      <kyn-header-category heading="Tag Management">
        <span slot="icon"><!-- circle-stroke icon SVG --></span>
        <kyn-header-link href="#"><span>AIOps Tagging (legacy)</span></kyn-header-link>
        <kyn-header-link href="#"><span>Bridge Tag Management</span></kyn-header-link>
      </kyn-header-category>
    </kyn-header-categories>
  </kyn-header-link>
</kyn-header-nav>
```
**Key structural rules from this pattern:**
- **Simple sections** (Favorites, Recently Viewed, Catalogs): `kyn-header-category slot="links"` as a direct child of `kyn-header-link`. No `heading` attribute needed for single-category simple sections.
- **Headed categories / red category headers** (Console, Services, Administration): To get the red category header text to display, each `kyn-header-category` MUST have BOTH (1) the `heading` attribute (e.g. `heading="Kyndryl Services"`) AND (2) `<span slot="icon">` with circle-stroke.svg from @kyndryl-design-system/shidoka-icons. If either is missing, the red categorical header does not display.
- **Framework adapter rule:** Lit reads the **DOM `heading` attribute**. If `heading="…"` / `:heading` / `{heading}` does not produce a real attribute on the element, **reflect it after mount** (`element.setAttribute('heading', heading)`) for every headed category in Console, Services, and Administration. The visible red heading depends on the DOM attribute, not just framework syntax.
- **React implementation preference:** In React consuming apps, do not render headed categories as raw `<kyn-header-category heading={category.heading}>...</kyn-header-category>` and assume the DOM attribute will survive. Use a tiny wrapper/helper that always reflects the `heading` DOM attribute on mount/ref for every masonry/tabbed headed category.
- **Svelte / Vue implementation preference:** In Svelte, use a `use:` action or `$effect` + `bind:this`; in Vue, use `onMounted` + template ref or a small wrapper component. Every masonry/tabbed headed category must keep a real DOM `heading` attribute or the red category header will not render.
**React — paste this wrapper (required if red headings are missing):** Lit reads the **`heading` DOM attribute**; React’s `heading={...}` prop often never sets it. Use one wrapper for all headed categories:
```tsx
import { useLayoutEffect, useRef, type ReactNode } from 'react';
export function HeadedHeaderCategory({
  heading,
  className,
  children,
}: {
  heading: string;
  className?: string;
  children: ReactNode;
}) {
  const ref = useRef<HTMLElement | null>(null);
  useLayoutEffect(() => {
    ref.current?.setAttribute('heading', heading);
  }, [heading]);
  return (
    <kyn-header-category ref={ref} className={className}>
      {children}
    </kyn-header-category>
  );
}
```
Then render Services/Administration/Console categories as `<HeadedHeaderCategory heading="…"><span slot="icon">…circle-stroke…</span>…links…</HeadedHeaderCategory>` instead of raw `<kyn-header-category heading={…}>`.
**Svelte — use this action for headed categories when needed:** If template binding does not leave a real DOM `heading` attribute, reflect it with a `use:` action:
```svelte
function reflectHeading(node, heading) {
  const apply = (value) => {
    if (value != null && value !== '') node.setAttribute('heading', String(value));
    else node.removeAttribute('heading');
  };
  apply(heading);
  return {
    update(nextHeading) {
      apply(nextHeading);
    },
  };
}
```
Then render Services/Administration/Console categories as `<kyn-header-category use:reflectHeading={category.heading}>...</kyn-header-category>` while still keeping `<span slot="icon">…circle-stroke…</span>` inside each category.
- **Category heading icon = circle-stroke SVG only.** For every headed category, `slot="icon"` must contain the **circle-stroke** icon from `@kyndryl-design-system/shidoka-icons/svg/monochrome/16/circle-stroke.svg` rendered from an imported package asset (16×16). **WRONG:** A bullet character (•), a dash, or any text glyph in `slot="icon"` — that produces a bullet instead of the placeholder circle. **WRONG:** Empty `<span slot="icon"></span>` — the component may fall back to a bullet. **WRONG:** `const CIRCLE_ICON = '<svg ...>'`. **CORRECT:** Import circle-stroke.svg from the package and render its SVG markup inside `<span slot="icon">` so the design-system placeholder circle appears next to the red category heading.
- **Console** uses a `div slot="links"` wrapper for single-column layout with top links and a headed category below.
- **Services** uses `kyn-tabs` + `kyn-tab-panel` + `kyn-header-categories layout="masonry"` inside each panel.
- **Administration** uses `kyn-header-categories slot="links" layout="masonry" maxColumns="2"` directly.
- **Do not normalize canonical root sections through one generic renderer.** Console, Services, Catalogs, and Administration have different required DOM shapes; a single generic category/section renderer must not erase those section-specific structures.
- **Acceptance check — Services:** the Services flyout must render a visible tab strip with `Kyndryl Services` and `Platform Services`, and each tab panel must contain masonry headed categories. If Services degrades into a flat list, a single cluster, or a generic category wrapper, it is wrong.
- **Acceptance check — categorical cluster dividers:** the last or only categorical menu cluster in a flyout must not render a trailing divider/border below it. Treat an extra divider under the final Console/Services/Administration cluster as a regression.
- **Icons** use `<span slot="icon">` with inline SVG, NOT `<kd-icon>`. Import icons from `@kyndryl-design-system/shidoka-icons` (or an official Shidoka re-export surface already provided by the consuming app) and never substitute lucide, heroicons, font-awesome, emoji, text glyphs, copied `<svg>` string constants, or custom SVGs.
- **Inline SVG rendering rule:** render approved Shidoka SVG assets inline so they can inherit `currentColor`, but do not globally force both `fill` and `stroke` on those SVGs. Preserve each asset's authored drawing model so icons do not render heavier than designed.
- **Canonical root icon assets:** `Favorites` -> `recommend-filled.svg`, `Recently Viewed` -> `history.svg`, `Console` -> `console.svg`, `Services` -> `services.svg`, `Catalogs` -> `catalog-management.svg`, `Administration` -> `user-settings.svg`.
- **Wrong root-icon treatment:** text placeholders such as `Recently`, `Services`, `Console`, `Admin`, or glyphs like `★` / `○` inside `.icon-slot`. **Correct:** inline/import the matching Shidoka SVG asset for each root section.
- **WRONG:** Links directly inside `slot="links"` without `kyn-header-category` — no grouping or headings. **WRONG:** `<kd-icon>` instead of `<span slot="icon">`. **WRONG:** `<span slot="heading">` — that slot does not exist. **WRONG:** Missing `heading` attribute on `kyn-header-category` in sections that need red headers. **WRONG:** Reducing the default Services or Administration scaffold to fewer categories/links than the bundled reference when the user did not provide custom nav JSON.
Pattern-layout helper CSS:
```css
.console-links-column {
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.console-links-category {
  margin-top: 8px;
}
.services-tabs-fill {
  width: 100%;
  max-width: none;
}
```
## 2. hideMenuLabel where the DS runtime uses it
- Keep `hideMenuLabel` on the workspace, notifications, and user flyouts. The Help flyout is the current DS runtime exception: when Help itself opens on mobile, its panel label remains visible.
- **Mobile flyout labels are required:** set a concise `label` on every `kyn-header-flyout` so the mobile overflow menu renders named top-level rows instead of blank icon-only entries. Default labels: `Workspaces`, `Notifications`, `Help`, `User Profile`.
- Treat that `label` as **mobile-overflow metadata only**. Do not replace, restyle, or remove the desktop `slot="button"` trigger because desktop rendering must remain driven by the existing workspace name + chevron or icon-only trigger.
- Keep `hideMenuLabel` on the panel only where the canonical DS runtime actually hides the panel label. The `label` still drives the mobile overflow menu entry for every flyout.
- **Right-side flyout trigger buttons (notifications, help, user) MUST use these exact Shidoka icon assets from `@kyndryl-design-system/shidoka-icons`:** `notification.svg`, `information.svg`, `user.svg`. Import those package assets and render the SVG markup inline in `slot="button"` (20×20), and keep the user trigger icon visibly rendered in the header even when the flyout panel uses a simpler placeholder treatment. **WRONG:** Generic bell, i-in-circle, person-silhouette substitutions, blank outlined squares/circles in place of the actual trigger icon, lucide/heroicons/font-awesome, hand-drawn inline SVG, any icon not from the Shidoka icon library, plain text inside `.icon-slot`, or pasted `<svg>` string constants.
- Vue: `:hideMenuLabel="true"`
- React: `hideMenuLabel={true}` (never `hide-menu-label` in React JSX)
- Lit/HTML: `hide-menu-label`
- Do not generate ref + onMounted workarounds or `.menu-label` CSS.
- Interactive icons in these flyouts must come from `@kyndryl-design-system/shidoka-icons`, rendered inline from imported package assets. Do not use random SVGs, lucide, heroicons, font-awesome, emoji, text glyphs, pasted `<svg>` string literals, or icons outside the Shidoka icon library.
- React/Vite example: `import notificationIconSvg from '@kyndryl-design-system/shidoka-icons/svg/monochrome/20/notification.svg?raw'` then render that imported markup inline in `slot="button"`. Do not replace that with `const NOTIFICATION_ICON = '<svg ...>'`.
- Do not satisfy these icon requirements by drawing a new local SVG component or by copying package SVG source into a local constant. Use approved package assets from `@kyndryl-design-system/shidoka-icons`, ideally imported raw/inlined in consuming apps.
- Notifications and help should render as compact action menus, not large mostly-empty panels with a single word or single link.
- Keep notifications and help inside one grouped action-list wrapper each. Do not emit bare text nodes, one-word-per-line fragments, or unwrapped loose links inside the flyout panel.
- Default notifications actions: `Notification center`, `Alert preferences`, `Mark all as read`.
- Default help actions: `Documentation`, `Support`, `Release notes`.
- Default user actions: `Profile settings`, `Account settings`, `Sign out` plus the centered profile block.
- Keep the user flyout as one `user-flyout-card`: centered `kyn-header-user-profile` first, then one grouped action list containing all user actions. Do not split `Sign out` into a separate trailing link outside the main action list.
- The user profile block must include a visible centered avatar/placeholder above the user text. When no real photo is provided, a simple 56px circular placeholder is acceptable by default; only add a larger inner user glyph when the prompt explicitly asks for it or when a consuming app wants that richer treatment.
- If a user flyout renders `Profile settings`, `Account settings`, or `Sign out` without `kyn-header-user-profile`, it is wrong. The default user flyout is profile-block-plus-actions, not actions-only.
- In Svelte 5, prefer event attributes for custom-element and DOM events: `onon-flyout-toggle`, `onon-click`, `onclick`, and `onkeydown`. Legacy directive forms such as `on:on-flyout-toggle`, `on:on-click`, `on:click`, and `on:keydown` now emit deprecation warnings. Wrong: malformed names like `onflyout-toggle`, `on-flyout-toggle`, or `on-click`, or omitting handlers so workspace/account items are not clickable.
Required right-side flyout skeleton:
```html
<kyn-header-flyout label="Notifications" hide-menu-label>
  <span slot="button"><!-- notification.svg from @kyndryl-design-system/shidoka-icons (20×20) --></span>
  <div class="flyout-action-list">
    <kyn-header-link href="#"><span>Notification center</span></kyn-header-link>
    <kyn-header-link href="#"><span>Alert preferences</span></kyn-header-link>
    <kyn-header-link href="#"><span>Mark all as read</span></kyn-header-link>
  </div>
</kyn-header-flyout>
<kyn-header-flyout label="Help">
  <span slot="button"><!-- information.svg from @kyndryl-design-system/shidoka-icons (20×20) — help/info flyout --></span>
  <div class="flyout-action-list">
    <kyn-header-link href="#"><span>Documentation</span></kyn-header-link>
    <kyn-header-link href="#"><span>Support</span></kyn-header-link>
    <kyn-header-link href="#"><span>Release notes</span></kyn-header-link>
  </div>
</kyn-header-flyout>
<kyn-header-flyout label="User Profile" hide-menu-label>
  <span slot="button"><!-- user.svg from @kyndryl-design-system/shidoka-icons (20×20) --></span>
  <div class="user-flyout-card">
    <kyn-header-user-profile name="Jordan Lee" subtitle="Platform Operations Lead" email="jordan.lee@kyndryl.com" profileLink="#" profileLinkText="View profile">
      <span class="user-profile-placeholder" aria-hidden="true"></span>
    </kyn-header-user-profile>
    <div class="flyout-action-list">
      <kyn-header-link href="#"><span>Profile settings</span></kyn-header-link>
      <kyn-header-link href="#"><span>Account settings</span></kyn-header-link>
      <kyn-header-link href="#"><span>Sign out</span></kyn-header-link>
    </div>
  </div>
</kyn-header-flyout>
```
Right-side flyout panel CSS (all frameworks — required so "Profile settings" etc. stay on one line):
```css
.flyout-action-list {
  min-width: 280px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 8px 0;
  box-sizing: border-box;
}
.flyout-action-list kyn-header-link span {
  white-space: nowrap;
}
.user-flyout-card {
  min-width: 280px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  box-sizing: border-box;
}
.user-profile-placeholder {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 56px;
  height: 56px;
  border-radius: 50%;
  border: 3px solid var(--kd-color-border-variants-brand);
}
.user-profile-placeholder svg {
  display: block;
  width: 32px;
  height: 32px;
}
.user-flyout-card .flyout-action-list {
  align-items: stretch;
  text-align: left;
}
.user-flyout-card .flyout-action-list kyn-header-link {
  width: 100%;
}
```
## 3. Workspace switcher CURRENT meta info
- Use the packaged workspace-switcher pattern asset `workspace-switcher.pattern.json` as the structured source for trigger markup, CURRENT data, copy feedback, and selection wiring. This is the normalized equivalent of `workspaceSwitcher.stories.js#UIImplementation`.
- Set the workspace flyout `label` to `Workspaces` so the mobile overflow menu preserves the canonical top-level IA while the desktop trigger continues to show the selected account name + chevron in `slot="button"`.
- Preserve the canonical `CURRENT` block instead of collapsing it to a name-only stack.
- Replicate the `workspaceSwitcher.stories.js#UIImplementation` CURRENT section exactly: `.account-meta-info` -> `.account-meta-info__header` -> `.account-meta-info__checkmark` + `.account-meta-info__content` -> `.account-meta-info__name`, copyable account ID `kyn-link`, and `.account-meta-info__country`.
- If `kyn-workspace-switcher` is present but no `.account-meta-info` block is rendered in `slot="left"`, it is wrong. The default workspace switcher must ship with visible account info on first render.
- The account ID should be rendered as a copyable account ID link, not a plain text row or decorative badge.
- **Trigger icon separation is required:** keep `chevron-down.svg` only for `.account-chevron` in the workspace trigger, and keep `copy.svg` / copied-state `checkmark-filled.svg` only inside the account ID `kyn-link`. Do not reuse the copy affordance icon as the flyout trigger icon.
- Do not substitute text glyphs for the `CURRENT` icons. Wrong: `<span class="account-meta-info__checkmark">✓</span>` or `<span slot="icon">⎘</span>`. Correct: imported Shidoka package icons rendered inline at 16×16 for both the status marker and copy affordance.
- Enforce two-pane sizing exactly: add class `ui-impl-switcher` on the switcher host, keep desktop width `625px` (minimum `625px`), keep `--kyn-workspace-switcher-left-panel-width: 275px`, and keep `--kyn-workspace-switcher-max-height: 70vh` on the element.
- Put the desktop sizing on the host element itself, not only in CSS. In React, include `width: '625px'` and `minWidth: '625px'` in the `style={{ ... }}` object on `kyn-workspace-switcher` alongside the CSS variables.
- Do not set a fixed host height. The left pane drives container height by design; the right pane should match that height and scroll independently.
- When a workspace or account item is selected, always use the item display name, never the raw id, when updating the trigger label and `.account-meta-info__name`.
- The trigger label and CURRENT block must reflect the selected account in the active right pane, not the selected workspace label. A workspace name like `Compute Zones` should not replace the account name in CURRENT unless it is itself an account item.
- When the workspace list includes an aggregate option such as `All` or `Global Zone (All)`, treat it as the union of the underlying workspace account lists by default. Do not model the aggregate row as an unrelated sibling workspace with its own isolated right-pane data unless the prompt or supplied data explicitly says otherwise.
- On first render, both workspace columns must already be populated. Default left-list examples: `Global Zone (All)`, `Account Tenants`, `Compute Zones`. Default right-list examples: `North America tenant`, `EMEA tenant`, `APAC tenant`.
- If `kyn-workspace-switcher` is emitted without `slot="left"`, `slot="left-list"`, and `slot="right-list"` children already present in the generated code, it is wrong.
- If only `slot="left"` and `slot="left-list"` are present, the workspace switcher will appear single-pane even on desktop. Emit initial `slot="right-list"` account items in the first render, not only after a later click.
- **Svelte event wiring (required for clicks to work):** Wire workspace flyout and menu-item clicks so left-list (workspace) and right-list (account) are both selectable. In Svelte 5, use event attributes: `onon-flyout-toggle`, `onon-click`, `onclick`, and `onkeydown`. Apply the flyout toggle handler on the flyout and click handlers on each `kyn-workspace-switcher-menu-item` or on the parent `kyn-workspace-switcher` with a single handler that reads `event.detail.value` and calls `selectWorkspace(value)` or `selectAccount(value)`. For the account ID `kyn-link`, keep `onclick` and `onkeydown` (Enter/Space). Set `data-copy-state={copiedAccountId ? 'copied' : 'idle'}` and swap the icon slot to checkmark when copied. The older directive forms (`on:on-flyout-toggle`, `on:on-click`, `on:click`, `on:keydown`) still compile but now emit Svelte 5 deprecation warnings. Without correct event wiring, left-list workspace items and right-list account items are not clickable.
- **React event + boolean wiring (required for clicks and selection state):** React does not map custom events from Lit components. The menu items emit a custom event named `on-click` (not the native `click`). You **must** use a ref on `kyn-workspace-switcher` and in `useEffect` call `switcherRef.current.addEventListener('on-click', handler)`. In the handler, read `event.detail?.value` and `event.target` (e.g. `event.target.getAttribute('slot')`): if slot is `left-list` call `setSelectedWorkspaceId(value)` and replace the active right-list account array from a workspace-to-accounts data map; do not keep one static `slot="right-list"` list for every workspace. When the workspace changes, also reset `selectedAccountId` to a valid account from that newly selected workspace before the next render. If slot is `right-list`, call `setSelectedAccountId(value)` and update trigger/CURRENT from the selected account record. For the flyout chevron use a ref on the first `kyn-header-flyout` and `addEventListener('on-flyout-toggle', (e) => { chevronRef.current.style.transform = e.detail?.open ? 'rotate(180deg)' : 'rotate(0deg)'; })`. For the account ID copy use native `onClick` on the `kyn-link` (or a ref + `addEventListener('click', copyHandler)`). **Initial render requirement:** derive the initial right-list array from the selected default workspace before the first render so the switcher opens with both panes populated; do not wait for a click before rendering the account list. **Selection booleans:** do not rely on `selected={condition}` for custom elements in React because non-selected rows can still render as `selected="false"` (attribute present), which Lit treats as selected. For non-selected rows, omit the attribute/property entirely. Use a conditional spread pattern like `{...(isSelected ? { selected: true } : {})}` and likewise for `favorited` / `showFavorite` when needed. **Host/class/style syntax:** in React use `className="ui-impl-switcher"` (not CSS-module-local class names) and set switcher inline CSS vars with a style object. Also put the desktop host sizing directly on the element with `width: '625px'` and `minWidth: '625px'`; do not rely only on a CSS class for the two-pane width contract. Keep the matching `.ui-impl-switcher` width rules in app-level global CSS, not a CSS module. **React keys:** never use bare display labels as list keys (canonical nav data intentionally includes repeated labels like `Private Cloud IaaS/PaaS`). Use unique ids when available, otherwise compose keys with section/tab/category context plus index (for example `${sectionId}-${tabId ?? "default"}-${categoryIndex}-${linkIndex}`). **Avoid change-in-update warnings:** do not imperatively set `kyn-header-nav`/`kyn-header-link` properties during every render cycle; keep nav data memoized and pass props declaratively, or set imperative properties once in a guarded mount effect.
Required workspace-switcher slot skeleton:
```html
<kyn-workspace-switcher id="workspace-switcher" class="ui-impl-switcher" style="width: 625px; min-width: 625px; --kyn-workspace-switcher-left-panel-width: 275px; --kyn-workspace-switcher-max-height: 70vh;">
  <div slot="left" class="account-meta-info">
    <div class="account-meta-info__header">
      <span class="account-meta-info__checkmark"><!-- checkmark-filled.svg (16×16, monochrome/16/) from @kyndryl-design-system/shidoka-icons --></span>
      <div class="account-meta-info__content">
        <span class="account-meta-info__name">North America tenant</span>
        <kyn-link standalone animationInactive="true" href="#">023497uw02399023509<span slot="icon"><!-- copy.svg (16×16, monochrome/16/) from @kyndryl-design-system/shidoka-icons --></span></kyn-link>
        <span class="account-meta-info__country">United States</span>
      </div>
    </div>
  </div>
  <kyn-workspace-switcher-menu-item slot="left-list" variant="workspace" value="workspace-0" name="Global Zone (All)" count="2"></kyn-workspace-switcher-menu-item>
  <kyn-workspace-switcher-menu-item slot="left-list" variant="workspace" value="workspace-1" name="Account Tenants" count="3" selected></kyn-workspace-switcher-menu-item>
  <kyn-workspace-switcher-menu-item slot="left-list" variant="workspace" value="workspace-2" name="Compute Zones" count="4"></kyn-workspace-switcher-menu-item>
  <kyn-workspace-switcher-menu-item slot="right-list" variant="item" value="account-0" name="North America tenant" selected showFavorite favorited></kyn-workspace-switcher-menu-item>
  <kyn-workspace-switcher-menu-item slot="right-list" variant="item" value="account-1" name="EMEA tenant" showFavorite favorited></kyn-workspace-switcher-menu-item>
  <kyn-workspace-switcher-menu-item slot="right-list" variant="item" value="account-2" name="APAC tenant" showFavorite favorited></kyn-workspace-switcher-menu-item>
</kyn-workspace-switcher>
```
## 4. Workspace switcher CSS
- The trigger label must truncate while the chevron stays fixed-size. That is why `.account-name` uses ellipsis and `.account-chevron` uses `flex-shrink: 0`.
- Keep the workspace switcher as a direct child of the flyout so the panel does not gain extra top padding above CURRENT.
- Mirror the pattern/workspace story CSS for CURRENT exactly instead of approximating it.
- Prefer importing the Studio-managed bundles `@kyndryl-cto/shidoka-studio/styles/header-flyouts.css` and `@kyndryl-cto/shidoka-studio/styles/workspace-switcher.css` in app global CSS instead of reauthoring these selectors in every app.
- If the same header shell also includes drawer, modal, or flyout stacking reinforcement, import `@kyndryl-cto/shidoka-studio/styles/shell-overlays.css` in that same stylesheet instead of adding page-local z-index patches.
```css
@import '@kyndryl-cto/shidoka-studio/styles/header-flyouts.css';
@import '@kyndryl-cto/shidoka-studio/styles/workspace-switcher.css';
/* Add when this shell also needs overlay stacking glue: @import '@kyndryl-cto/shidoka-studio/styles/shell-overlays.css'; */
```
Fallback reference block (use only when a workspace cannot import the Studio bundle directly):
```css
.account-meta-info {
  display: flex;
  flex-direction: column;
  gap: 2px;
  margin: 0 auto 12px;
}
.account-meta-info__header {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  font-size: 14px;
}
.account-meta-info__checkmark {
  display: flex;
  align-items: center;
  flex-shrink: 0;
  margin-top: 4px;
  color: var(--kd-color-badge-heavy-background-success);
}
.account-meta-info__content {
  display: flex;
  flex-direction: column;
}
.account-meta-info__name {
  max-width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 500;
  font-size: 14px;
  line-height: 20px;
  color: var(--kd-color-text-level-primary);
}
.account-meta-info__country {
  font-size: 14px;
  line-height: 20px;
  color: var(--kd-color-text-level-primary);
}
.account-name {
  max-width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  min-width: 0;
  color: inherit;
}
.account-chevron {
  display: flex;
  flex-shrink: 0;
  align-items: center;
  transition: transform 0.2s;
  color: inherit;
}
.ui-impl-switcher {
  width: 625px;
  min-width: 625px;
  --kyn-workspace-switcher-left-panel-width: 275px;
}
@media (max-width: 831px) {
  .ui-impl-switcher {
    max-width: 375px;
    min-width: 0;
  }
}
@media (max-width: 671px) {
  .ui-impl-switcher {
    width: 100%;
    max-width: none;
    min-width: 0;
  }
}
```
The workspace switcher has two panes (left: CURRENT + workspace list; right: account list). Keep desktop width at 625px (minimum 625px) and keep `--kyn-workspace-switcher-left-panel-width: 275px` so both panes remain visible. If desktop width or the left-panel-width host variable is omitted, the right pane can disappear and only the left pane renders. Keep this rule on the host element itself and in app global CSS across Vue, React, Svelte, and Lit.
Use pixel breakpoints for collapse behavior (`831px` and `671px`) so root font-size changes do not accidentally force one-pane mode on desktop widths.
## 4b. Shell layering in consuming apps
- If a consuming app needs to reinforce `kyn-header`, `kyn-local-nav`, or flyout panel stacking/backgrounds, prefer importing `@kyndryl-cto/shidoka-studio/styles/shell-overlays.css` in one app-level global stylesheet such as `src/app.css`.
- Do not generate page-scoped host overrides like `:global(kyn-header) { z-index: ... }` or `:global(kyn-local-nav) { background: ... }` inside a single page component. Those can create fragile stacking contexts that fight the design system overlay/panel stack.
- In Svelte consuming apps, custom elements upgrade asynchronously after mount. Avoid repeated `$effect` loops that keep writing shell-related custom-element properties during render; if a property truly must be set programmatically, do it after mount and then update it from explicit handlers.
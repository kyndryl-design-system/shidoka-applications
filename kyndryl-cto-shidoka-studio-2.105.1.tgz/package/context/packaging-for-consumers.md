# Shidoka Studio — packaging for consuming developers

**Status:** The standalone `shidoka-studio` package is publishable from this repo root. The published package ships `bin/`, `context/`, `shared-foundation/`, `styles/`, `examples/`, `env.example`, and `README.md`.

This doc covers: (1) **consumer perspective** — how external devs would install and use Shidoka Studio in Cursor or VS Code, and (2) **publisher perspective** — how the design system team would build and distribute validated release artifacts. In the source repo, see `docs/PACKAGING-OPTIONS.md` for distribution-channel tradeoffs (GitHub Releases vs GitHub Packages vs Cursor extension vs internal URL).

For Studio maintainers, packaging is now one part of a layered validation loop:

- fast artifact checks in-repo
- consumer fixture app checks in `consumer-fixtures/sveltekit-dashboard/`
- packed-install smoke via `npm run verify:consumer-pack`
- optional external sideload spot-checks

---

## Consumer perspective

### What you get

- Current MCP tool surface:
  - Optional readiness/preflight helper: `assess_shidoka_generation_readiness` (experimental capability-profile-backed aid; does not replace the canonical generation flow)
  - Core generation contract tools: `get_shidoka_design_context`, `get_canonical_full_page_template`, `get_canonical_full_page_recipe`, `get_shidoka_full_page_snippets`, `get_canonical_header_nav_template`, `get_canonical_header_nav_recipe`, `get_shidoka_header_nav_snippets`
  - Operational context tools: `get_shidoka_support_docs`, `get_workspace_ui_context`
  - Standalone prompt-template lane (opt-in): `get_shidoka_prompt_template_catalog`, `get_shidoka_prompt_template`, `resolve_shidoka_prompt_template_alias`
  - Experimental fallback supplements (opt-in, disabled by default): `get_shidoka_fallback_context`, `get_shidoka_header_nav_fallback_context`
  - Auditor tools: `get_shidoka_audit_rules`, `audit_shidoka_usage`
  - Full up-to-date tool catalog: the packaged `README.md` section **Available MCP tools**
- No design system repo required — the package ships with a bundled snapshot of the context, canonical artifacts, shared foundation contracts, and audit surfaces.
- The MCP kill switch applies to the full tool surface. When disabled, all tools, including the auditor tools, return the same short disabled message instead of design-system context or audit results.

### Install (starter-repo bootstrap flow)

Use the private GitHub Packages package `@kyndryl-cto/shidoka-studio` as the primary install surface.

Teammates can install it only if they have:

1. access to this repo/package
2. a GitHub personal access token (classic) with `read:packages` tied to the CTO org
3. that token authorized for the org's SSO

For starter repos and long-lived app repos, commit the copyable bootstrap script from this repo as:

```bash
scripts/install-shidoka-studio.mjs
```

Use `examples/bootstrap/install-shidoka-studio.mjs` as the source copy. The script runs before the npm package exists, writes safe project registry config, installs Studio, and then executes the installed package installer:

```bash
node scripts/install-shidoka-studio.mjs --host cursor
```

For unattended setup, provide the token through an environment variable:

```bash
GITHUB_PACKAGES_TOKEN=YOUR_GITHUB_PAT node scripts/install-shidoka-studio.mjs --host cursor
```

If no token environment variable is present, the bootstrap script prompts once. It uses any supplied token only through a temporary npm config and deletes that config after the install attempt. It never writes tokens to project `.npmrc`.

The bootstrap script accepts `--host vscode-copilot`, `--host codex`, or `--host both`. Its default install is local-only (`--no-save --package-lock=false`) so production app installs and Docker builds do not have to fetch the private MCP package. Add `--save-dev` only for repos that should track Studio in `devDependencies`.

Manual fallback:

1. Add both lines to your user-level `~/.npmrc`:

   `@kyndryl-cto:registry=https://npm.pkg.github.com`

   `//npm.pkg.github.com/:_authToken=YOUR_GITHUB_PAT`

2. Install the package locally from the repo root without changing the app manifest or lockfile:

   `npm install --no-save --package-lock=false @kyndryl-cto/shidoka-studio@latest`

3. If registry auth is not ready for a stakeholder yet, the latest private GitHub release still includes a validated `.tgz` fallback asset.

Preferred activation command after install: `node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor`. The `npx shidoka-studio-install` alias still works after the package is installed, and the older `npx shidoka-studio-install-rule` command remains supported as a compatibility alias.

The installer is not the MCP server. It writes host config and exits. If a user is configuring Cursor or VS Code "Tools and MCP" manually, the server entry should launch the installed local server or generated launcher, not `npx shidoka-studio-install-rule`. Any PAT prompt is an npm/GitHub Packages fetch problem, not a Shidoka Studio MCP runtime requirement.

### Configure Cursor

From the consuming repo root:

```bash
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor
```

That installs the canonical Cursor rule, merges `.cursor/mcp.json`, and also installs a platform-native launcher so Cursor can start the MCP when `node` is not directly visible to the GUI process: `scripts/run-shidoka-studio-mcp.sh` on macOS/Linux and `scripts/run-shidoka-studio-mcp.cmd` on Windows.

If you need to manage the server entry manually, the minimal config is still:

```json
{
  "mcpServers": {
    "shidoka-studio": {
      "command": "node",
      "args": ["./node_modules/@kyndryl-cto/shidoka-studio/bin/server.js"],
      "cwd": "${workspaceFolder}"
    }
  }
}
```

Then reload Cursor.

To print the same direct server config without writing files:

```bash
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor --print-mcp-config
```

### Configure VS Code + GitHub Copilot

From the consuming repo root:

```bash
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host vscode-copilot
```

That installs `.vscode/mcp.json`, `.github/copilot-instructions.md`, `.github/instructions/*.instructions.md`, `.github/prompts/*.prompt.md`, and the same platform-native launcher scripts under `scripts/`.

If you need to manage the server entry manually, the minimal config is:

```json
{
  "servers": {
    "shidoka-studio": {
      "type": "stdio",
      "command": "node",
      "args": ["./node_modules/@kyndryl-cto/shidoka-studio/bin/server.js"],
      "cwd": "${workspaceFolder}"
    }
  }
}
```

Then reload VS Code.

To print the same direct VS Code server config without writing files:

```bash
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host vscode-copilot --print-mcp-config
```

### Configure Codex in VS Code

From the consuming repo root:

```bash
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host codex
```

That installs `.codex/config.toml`, `AGENTS.md`, and the same platform-native launcher scripts under `scripts/`.

Then reload VS Code or start a new Codex session.

### Recommended internal rollout model

For org-internal starter repos, templates, and long-lived product repos, the least-friction path is to prepare the repo for **both** supported editors and commit the generated workspace files:

```bash
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host both
```

That writes:

- Cursor: `.cursor/mcp.json` and `.cursor/rules/*.mdc`
- VS Code / Copilot: `.vscode/mcp.json` and `.github/` workspace files

Commit those files in the consuming repo. Then the normal teammate flow becomes:

1. clone the repo
2. run `npm install`
3. trust/enable the `shidoka-studio` MCP server in the host editor
4. start a fresh chat

If a teammate needs to verify that the generated host config can really launch the stdio server and expose the Shidoka tools, the packaged CLI now includes:

```bash
npx shidoka-studio-doctor --host cursor
```

Replace `cursor` with `vscode-copilot`, `codex`, or `both` depending on which generated host config should be checked.

This keeps the existing Cursor experience intact while making VS Code / Copilot available without requiring each teammate to run a separate installer command after clone.

If the repo also wants Codex in VS Code ready to go, run `node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host codex` and commit `.codex/config.toml` plus `AGENTS.md` too.

### Optional overrides

- **SHIDOKA_STUDIO_CONTEXT_PATH** — Path to a complete built context folder with the base context and full-page assets.
- **SHIDOKA_STUDIO_CONTEXT_URL** — URL that returns a complete context payload (prefer JSON with `content`, `canonicalTemplate`, `canonicalRecipe`, and `fullPageSnippets`). If the URL cannot provide a complete set, the server falls back to the bundled package context.

### What file format will be generated?

**Shidoka Studio does not specify output format.** The MCP context describes _how_ to use Shidoka components (tags, imports, layout rules), not _what_ to emit. The host agent infers format from the **open workspace**:

- **In the design-system repo (e.g. shidoka-applications):** Storybook and `src/stories/` are present, so the model typically generates a **`.stories.js`** (or `.stories.ts`) file and it appears under PAGES in the Storybook sidebar. That's appropriate there.
- **In a consuming app:** Format depends on the project. If the app has **no Storybook**, the model should _not_ emit a story file — it should emit whatever the app uses: e.g. a **Vue SFC** (`.vue`), a **Next.js page** (`app/settings/page.tsx` or `pages/settings.tsx`), or a **React component** (`.tsx`). The AI infers from the repo layout and file patterns.

To avoid wrong format (e.g. a `.stories.js` in an app that doesn't use Storybook), **be explicit in the prompt or in a project instruction layer.** Examples: _"Generate as a Vue component at `src/views/SettingsPage.vue`"_, _"Generate as a Next.js page at `app/settings/page.tsx`"_, or in a rule/instructions file: _"When generating Shidoka pages, output a Vue SFC in `src/views/`"_.

### Where do generated files go?

**Shidoka Studio does not write files.** It only exposes MCP tools. Cursor (or the user) generates and saves the code. The package/extension **should not dictate** where pages or templates live in the consumer’s app — every repo has different structure (Next.js `app/`, SvelteKit `src/routes/`, Angular `src/app/`, plain `src/views/`, etc.).

**Recommendation:**

- **Do not** hard-code a single output path in the extension or in a shared rule. Let the **application repo** decide.
- In the **consuming app**, define a convention once and point the AI at it:
  - **Stories:** e.g. `src/stories/generated/` (if they use Storybook).
  - **Pages/templates:** e.g. `src/pages/`, `src/views/`, or `app/(dashboard)/generated/` — whatever matches the app. Document it in a Cursor rule (e.g. “When generating Shidoka pages, write to `src/pages/`”) or in the project README so the AI and the team stay consistent.
- The **design system package** can suggest defaults in its example rule (e.g. “or to the path the user specifies”) and in this doc, but the final say is the app’s.

That way the extension/package stays app-agnostic; each team gets one place for generated output without the package imposing a layout that doesn’t fit.

### Will Cursor wire the new view so I can see it on localhost?

**Short answer:** Cursor can often infer **where** to put the file from your project structure (e.g. `src/views/` in Vue, `app/` or `pages/` in Next.js). It will **not** reliably infer how to **wire** the new view into your app so it's reachable on localhost unless you ask for that explicitly.

- **Vue:** A new component in `src/views/SettingsPage.vue` is not reachable until something (e.g. Vue Router) has a route that renders it and, optionally, a nav link. Cursor can see your router and add a route if you ask.
- **Next.js (App Router):** A new view is reachable only if it lives in the right place (e.g. `app/settings/page.tsx` → `/settings`). Cursor can create that path if you specify the route.
- **Next.js (Pages Router):** A new file under `pages/` (e.g. `pages/settings.tsx`) is automatically a route. Cursor might put the file there if it sees the `pages/` structure.

**Recommendation — ask for both generation and integration in one prompt:**

- **Vue:** _"Generate a Shidoka Settings view and add it as a route at `/settings` in our Vue Router."_
- **Next.js (App Router):** _"Generate a Shidoka Settings page at the route `/settings` (create the file in `app/settings/page.tsx`)."_
- **Next.js (Pages Router):** _"Generate a Shidoka Settings page at `/settings` (add `pages/settings.tsx`)."_

If you only say "generate a Settings view," you may get a valid Shidoka component that's never connected to routing. One prompt that includes "add it as a route" or "at `/settings`" (and the path if your framework needs it) gets you a view you can open on localhost.

**Optional:** In your app repo, add a Cursor rule (e.g. `.cursor/rules/shidoka-views.mdc`) that states where Shidoka-generated views live and how routing works (e.g. "New Shidoka pages go in `src/views/`; add a route in `src/router/index.js` with path and component."). Then the first-time prompt can be shorter and the AI will still wire the view.

### Styling: required CSS and avoiding overrides

Your app must load Shidoka Foundation (and any applications/charts global CSS) so tokens and layout work. To prevent your application’s styles from overwriting the design system, use **CSS cascade layers** so Shidoka has higher precedence than app globals.

- **Required styles:** `@kyndryl-design-system/shidoka-foundation`: import `css/root.css` and `css/index.css` in your app entry. Add any applications or charts global CSS if you use those packages.
- **Layer order:** Declare `@layer app, shidoka` and load Shidoka into the `shidoka` layer and your app’s global styles into the `app` layer so Shidoka isn’t overwritten.

Full setup and examples: the packaged `context/styling-for-consumers.md` doc. In the source repo, the authored source lives at `docs/STYLING-FOR-CONSUMERS.md`.

---

## Publisher perspective (design system team)

### Build

From repo root:

```bash
npm run build
```

This runs `generate-component-registry`, then copies the source server, packaged docs, canonical full-page assets, shared foundation runtime files, and packaged CSS into the publishable package surface: `bin/`, `context/`, `shared-foundation/`, `styles/`, and the shipped `examples/` docs/config alongside `env.example` and `README.md`.

Before relying on an external sideloaded app, maintainers should also run:

```bash
npm run test:consumer:svelte
npm run test:consumer:svelte:visual
npm run verify:consumer-pack
```

That confirms the committed SvelteKit fixture app still builds and that a packed tarball still installs cleanly into a consumer-like project.

### Publish / distribute (current path)

The release workflow publishes `@kyndryl-cto/shidoka-studio` to GitHub Packages and also uploads the validated `.tgz` as a private GitHub release asset fallback.

Maintainer flow:

1. Merge the release-ready changes to a release branch tracked by semantic-release (`main`, `beta`, or `next`).
2. Ensure the repo variable `ENABLE_SEMANTIC_RELEASE=true`.
3. Ensure the package remains **private**, linked to this repository, and keeps inherited repo access permissions enabled unless you intentionally switch to granular package permissions.
4. Let GitHub Actions run `.github/workflows/release.yml`.
5. Consumers install `@kyndryl-cto/shidoka-studio` from GitHub Packages.
6. If a teammate is blocked on GitHub Packages auth, use the attached `Validated release tarball` as a temporary fallback.

This keeps the steady-state install path on normal npm semantics while preserving a fallback asset for blocked installs or short-lived testing. The release flow deliberately avoids pushing a release-version commit back to the branch, so protected branches are less likely to block the first rollout. Treat the Git tag, GitHub Package version, and GitHub release as the release source of truth.

`npm run prep` remains a local/manual sideload workflow for maintainers. It is not the official release channel and should not be used to create tracked tarballs in this repository.

### Downstream playground updates

Stable releases dispatch updates to the current playground repos so each can update its installed `@kyndryl-cto/shidoka-studio` version automatically:

- `kds-shidoka-studio-playground-react`
- `kds-shidoka-studio-playground-svelte`
- `kds-shidoka-studio-playground-vue`
- `kds-shidoka-studio-playground-vanillajs`

The manual `.github/workflows/dispatch-playground-updates.yml` workflow remains available for resend or backfill. Configure `SHIDOKA_STUDIO_DOWNSTREAM_REPO_TOKEN` in this repo's Actions secrets with access limited to those downstream repos before relying on that automation.

### Package access model

For the npm registry, GitHub Packages supports org-scoped private packages. When the package stays linked to this repository and inherited permissions remain enabled, package access tracks repository access by default. In practice, that gives the desired model: people who can access the repo and who have an SSO-authorized package token can install the package.

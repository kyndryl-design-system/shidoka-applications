---
name: Shidoka
version: alpha
description: Kyndryl Shidoka Design System - brand token projection for DESIGN.md-aware tooling. Not a replacement for the MCP payload; prefer the canonical MCP tools for structural guidance.
colors:
  primary: "#2f808c"
  on-primary: "#ffffff"
  text: "#161616"
typography:
  h1:
    fontFamily: "TWK Everett, Helvetica, Arial, sans-serif"
    fontSize: 3rem
    fontWeight: 700
    lineHeight: 3.5rem
  body-lg:
    fontFamily: "TWK Everett, Helvetica, Arial, sans-serif"
    fontSize: 1.125rem
    fontWeight: 400
    lineHeight: 1.625rem
rounded:
  none: 0
  sm: 4px
  md: 8px
spacing:
  xs: 4px
  sm: 8px
  md: 16px
components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    rounded: "{rounded.sm}"
    padding: 12px
---

## Overview

Shidoka Studio already owns the structural and behavioral authority for page shells, component composition, and framework translation. This DESIGN.md artifact is a deliberately small brand-token projection for tooling that understands the upstream format.

DESIGN.md accepts a single sRGB value per token, so this export resolves Shidoka tokens to light-theme values only. Use the existing MCP payloads and Foundation sources for dark-theme behavior and structural guidance.

## Colors

The palette here stays intentionally small: one primary interactive token, its paired foreground, and the default body-text color. The goal is portable brand grounding, not a complete Foundation token dump.

- **primary** `#2f808c` from `--kd-color-spruce-50`: Default interactive color for primary actions and emphasis.
- **on-primary** `#ffffff` from `--kd-color-white`: Foreground color used on primary surfaces.
- **text** `#161616` from `--kd-color-gray-100`: Default body-text color on light surfaces.

## Typography

Typography stays anchored to the core Shidoka voice: TWK Everett for product UI with a compact, curated scale that is large enough to establish hierarchy without recreating the full design-system type inventory.

- **h1**: font `TWK Everett, Helvetica, Arial, sans-serif`, size `3rem`, weight `700`, line height `3.5rem`.
- **body-lg**: font `TWK Everett, Helvetica, Arial, sans-serif`, size `1.125rem`, weight `400`, line height `1.625rem`.

## Layout

Spacing is represented as a small, deterministic scale that supports common UI rhythm decisions in downstream tools. It does not replace canonical layout recipes, shell spacing rules, or framework-specific adapters.

Spacing scale:

- **xs**: `4px`
- **sm**: `8px`
- **md**: `16px`

## Shapes

Corner rounding remains restrained and utility-oriented. The exported scale captures the common primitives used for buttons and card treatments without redefining component semantics.

Rounded scale:

- **none**: `0`
- **sm**: `4px`
- **md**: `8px`

## Components

- **button-primary**: Baseline token projection for a primary Shidoka button. Uses `backgroundColor` `{colors.primary}`, `textColor` `{colors.on-primary}`, `rounded` `{rounded.sm}`, `padding` `12px`.

## Do's and Don'ts

Do use this file for brand-level questions such as the primary color, typography scale, spacing primitives, and button token grounding. Do not treat it as authority for page composition, shell structure, workspace switcher behavior, or any kyn-* component contract.

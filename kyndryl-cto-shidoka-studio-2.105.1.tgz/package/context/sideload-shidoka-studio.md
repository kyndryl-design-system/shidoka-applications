# Sideloading Shidoka Studio into Another Repo

This is a manual or final-confidence workflow. It is no longer the primary development loop for `shidoka-studio`, and it is not the primary teammate install channel.

Official installs should come from the private GitHub Packages package `@kyndryl-cto/shidoka-studio`. The private GitHub release tarball remains a fallback for blocked or short-lived installs.

For day-to-day Studio development, prefer this order first:

1. `npm run build`
2. `npm run test`
3. `npm run test:visual`
4. `npm run test:consumer:svelte`
5. `npm run test:consumer:svelte:visual`
6. `npm run test:consumer:react:visual`
7. `npm run verify:consumer-pack`
8. `npm run verify:consumer:react-pack`
9. `npm run verify:consumer:framework-baselines`

`npm run test:visual` is the canonical/static Playwright suite only. Consumer-app Playwright coverage lives in the dedicated Svelte and React commands above.

The committed footer screenshot baseline is currently platform-specific; non-macOS environments may still exercise the footer geometry assertions while skipping the screenshot assertion when no matching committed baseline exists.

Only after the in-repo fixture apps are passing should you sideload into an external app for an additional spot-check.

How to use this package in **shidoka-applications** or any other repo’s `node_modules` for testing without publishing to npm.

---

## 1. Build the package (do this first)

From the **shidoka-studio** repo root:

```bash
npm install
npm run build
```

This produces `bin/`, `context/`, and `examples/` at the package root. The MCP server reads `context/` relative to `bin/server.js`, so that layout must stay intact when sideloading.

---

## 2. Sideload options

Pick one. The **consuming repo** is the project where you want Shidoka Studio (e.g. shidoka-applications or a Vue app).

For any option that installs the package into the consuming repo's `node_modules`, use:

```bash
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor
```

That installs the canonical rule, merges `.cursor/mcp.json`, and on macOS/Linux installs the launcher script automatically.

### Option A: `file:` dependency (recommended)

Consuming repo installs the package from the filesystem. Survives `npm install` and keeps the dependency in `package.json`.

1. **Build** shidoka-studio (section 1).

2. **In the consuming repo**, add the dependency and install:

   ```bash
   npm install file:../shidoka-studio
   ```

   If the consuming repo has strict or conflicting peer dependencies, use:

   ```bash
   npm install file:../shidoka-studio --legacy-peer-deps
   ```

   Or use an absolute path:

   ```bash
   npm install file:/path/to/shidoka-studio
   ```

   Or add to `package.json` and run `npm install`:

   ```json
   "@kyndryl-cto/shidoka-studio": "file:../shidoka-studio"
   ```

3. **In the consuming repo**, run:

   ```bash
   node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor
   ```

**Pros:** Tracked in package.json; same path as a real npm install.  
**Cons:** After changing shidoka-studio, run `npm run build` there, then in the consuming repo run `npm install` again (or re-run the `file:...` install) to refresh.

---

### Option B: `npm link`

Good for active development: changes in shidoka-studio are reflected without reinstalling.

1. **In shidoka-studio repo:** build, then register the link:

   ```bash
   npm run build
   npm link
   ```

2. **In the consuming repo:** use the linked package:

   ```bash
   npm link @kyndryl-cto/shidoka-studio
   ```

3. **In the consuming repo**, run `node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor`.

**Pros:** No reinstall when you rebuild shidoka-studio; `node_modules` points at your local clone.  
**Cons:** Global link can be confusing with multiple clones; remember to run `npm run build` in shidoka-studio after edits.

---

### Option C: Direct path in MCP (no install)

Consuming repo points Cursor at the built package on disk. No entry in `node_modules`.

1. **Build** shidoka-studio (section 1).

2. **In the consuming repo’s `.cursor/mcp.json`:**

   ```json
   {
     "mcpServers": {
       "shidoka-studio": {
         "command": "node",
         "args": [
           "/absolute/path/to/shidoka-studio/bin/server.js"
         ],
         "cwd": "${workspaceFolder}"
       }
     }
   }
   ```

   If shidoka-studio is a **sibling** of the consuming repo:

   ```json
   "args": ["../shidoka-studio/bin/server.js"]
   ```

**Pros:** Always uses latest build; no install step.  
**Cons:** Path is machine-specific; consuming repo doesn’t list the dependency.

---

### Option D: Pack and install from tarball

Useful for a one-off snapshot or CI.

1. **In shidoka-studio repo:**

   ```bash
   npm run build
   npm pack
   ```

   This creates e.g. `kyndryl-cto-shidoka-studio-1.0.0.tgz`.

2. **In the consuming repo:**

   ```bash
   npm install /path/to/shidoka-studio/kyndryl-cto-shidoka-studio-1.0.0.tgz
   ```

   Or copy the `.tgz` into the repo and:

   ```bash
   npm install ./kyndryl-cto-shidoka-studio-1.0.0.tgz
   ```

3. **In the consuming repo**, run `node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor`.

**Pros:** Single file; versioned snapshot.  
**Cons:** Must repack and reinstall to get updates.

---

## 3. Checklist

| Step | Action |
|------|--------|
| 1 | In **shidoka-studio**: `npm run build` |
| 2 | In the **consuming repo**: use Option A, B, C, or D above |
| 3 | In the consuming repo: run `node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor` for installed-package flows, or hand-edit `.cursor/mcp.json` only for the direct-path flow |
| 4 | Reload Cursor so the MCP server is picked up |

---

## 4. Optional: Override context source

To make the server read context from a different folder (e.g. a dev copy of `context/`), set **SHIDOKA_STUDIO_CONTEXT_PATH** in the environment Cursor uses for MCP. The folder must contain at least:

- `considerations.md`
- `component-registry.md` (or `design-system-context.md`)
- `page-template-builder.md`

Example:

```bash
export SHIDOKA_STUDIO_CONTEXT_PATH="/path/to/shidoka-studio/context"
```

Then start Cursor (or run the MCP server) with that env set. The server will use this folder instead of its bundled `../context`.

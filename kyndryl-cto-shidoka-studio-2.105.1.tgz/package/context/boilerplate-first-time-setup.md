# Shidoka Studio — first-time setup (your app + host editor)

Use this guide when you open a product app for the first time and want Shidoka Studio working locally in Cursor, VS Code / GitHub Copilot, or Codex in VS Code. It assumes you already have the app repo cloned and Node installed.

---

## What you are setting up

| Piece | Role |
|--------|------|
| **npm package** `@kyndryl-cto/shidoka-studio` | Ships the MCP server, bundled design-system context, and the installer CLI. |
| **host MCP config** (`.cursor/mcp.json`, `.vscode/mcp.json`, or `.codex/config.toml`) | Project-scoped MCP config that tells the host editor how to start the Shidoka Studio server for this workspace. |
| **host instruction files** | Cursor uses `.cursor/rules/*.mdc`; VS Code / Copilot uses `.github/copilot-instructions.md`, `.github/instructions/*.instructions.md`, and `.github/prompts/*.prompt.md`; Codex uses `AGENTS.md`. |
| **launcher script** (`scripts/run-shidoka-studio-mcp.sh` or `scripts/run-shidoka-studio-mcp.cmd`) | Installed automatically so GUI-driven editor sessions can find `node` even when it is not directly visible to the process PATH. |

In starter repos, the preferred setup command is **`node scripts/install-shidoka-studio.mjs --host cursor`**. With `--host vscode-copilot`, it installs `.vscode/mcp.json` plus Copilot workspace files under `.github/`. With `--host codex`, it installs `.codex/config.toml` plus `AGENTS.md`. In each case it installs the matching launcher script automatically for the current platform. The `npx shidoka-studio-install` alias still works after the package is installed, and the older `npx shidoka-studio-install-rule` command remains supported as a compatibility alias.

---

## Prerequisites

- **Node.js 20+** (`node -v` in a terminal; matches the package `engines` floor)
- **Cursor** with MCP support, **VS Code + GitHub Copilot** with MCP support, or **Codex in VS Code**
- Access to the GitHub org/repo that publishes `@kyndryl-cto/shidoka-studio`
- A **GitHub personal access token (classic)** with **`read:packages`**, authorized for the org's SSO, when prompted by the bootstrap script
- The app opened in the host editor **as the workspace root** (the folder that contains this project's `package.json`)

---

## Default starter-repo flow

Do this from the **app project root**.

1. Install app dependencies if you have not already:

   ```bash
   npm install
   ```

2. Run the bootstrap installer:

   ```bash
   node scripts/install-shidoka-studio.mjs --host cursor
   ```

   Use `--host vscode-copilot`, `--host codex`, or `--host both` for other editor targets.

   The script installs `@kyndryl-cto/shidoka-studio` from GitHub Packages, writes safe project npm registry config, and runs the installed editor setup. If no token environment variable is present, it prompts once for a GitHub personal access token (classic) with `read:packages`.

3. If this app will render Shidoka components, make sure it also declares the runtime design-system packages it uses, especially `@kyndryl-design-system/shidoka-applications` plus any Foundation/Charts/Icon packages your app needs.

This auth is only for downloading the private npm package. The Shidoka Studio stdio MCP server runs locally after install and does not use a GitHub PAT at runtime. If a PAT prompt appears while adding an MCP server in Cursor or VS Code, check whether that server entry uses `npx` or another package-fetching command instead of the installed local server/launcher.

---

## Manual GitHub Packages fallback

Use this if the repo does not have `scripts/install-shidoka-studio.mjs`.

1. Add the GitHub Packages scope mapping to your user-level `~/.npmrc` if it is not already there:

   ```bash
   @kyndryl-cto:registry=https://npm.pkg.github.com
   ```

2. Add the token to that same user-level `~/.npmrc`:

   ```bash
   //npm.pkg.github.com/:_authToken=YOUR_GITHUB_PAT
   ```

3. Install Shidoka Studio locally without changing the app manifest or lockfile:

   ```bash
   npm install --no-save --package-lock=false @kyndryl-cto/shidoka-studio@latest
   ```

4. Choose one host setup path:

   **Cursor**

   ```bash
   node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor
   ```

   This writes `.cursor/rules/shidoka-generation.mdc`, `.cursor/mcp.json`, and installs a platform-native `shidoka-studio` server entry: `bash` + `scripts/run-shidoka-studio-mcp.sh` on macOS/Linux, or `cmd.exe` + `scripts/run-shidoka-studio-mcp.cmd` on Windows.

   **VS Code + GitHub Copilot**

   ```bash
   node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host vscode-copilot
   ```

   This writes `.vscode/mcp.json`, `.github/copilot-instructions.md`, `.github/instructions/shidoka-ui.instructions.md`, `.github/prompts/*.prompt.md`, and installs the same launcher script under `scripts/`.

   **Codex in VS Code**

   ```bash
   node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host codex
   ```

   This writes `.codex/config.toml`, `AGENTS.md`, and installs the same launcher script under `scripts/`.

   **Internal repos that want both editors**

   ```bash
   node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host both
   ```

   This writes both the Cursor and VS Code / Copilot workspace surfaces into the repo. For starter repos and long-lived product repos, commit those generated files so teammates only need `npm install`, MCP trust/enable, and a fresh chat.

4. Reload the host editor.

5. Confirm `shidoka-studio` is enabled in the workspace MCP/server UI for your host.

6. Start a fresh chat.

   Important: **enabled in the MCP/server UI** is not the same as **discoverable in the current chat/session**. If the UI shows `shidoka-studio` enabled but the chat still says the tools are unavailable, treat that as a session refresh/discovery issue first: toggle the server off/on, reload the editor, start another fresh chat, and then retry. Do not conclude "no MCP access" from empty MCP resource/template lists alone; the key check is whether the Shidoka tools are actually callable in the current session.

   For a direct runtime check from the consuming repo root, run:

   ```bash
   npx shidoka-studio-doctor --host cursor
   ```

   Replace `cursor` with `vscode-copilot`, `codex`, or `both` depending on which generated host config you want to verify.

7. Run your app if you want to preview generated UI:

   ```bash
   npm run dev
   ```

You can now ask your coding agent to generate or refine Shidoka pages. The model should call tools like `get_shidoka_design_context` and the canonical full-page helpers before generation.

---

## Fallback install if registry auth is not ready yet

The package is now primarily distributed through GitHub Packages, but the repo's latest private GitHub release still carries a validated `.tgz` as a fallback.

From the app repo root:

```bash
npm install -D /path/to/kyndryl-cto-shidoka-studio-0.x.x.tgz
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor
```

Or, for VS Code + GitHub Copilot:

```bash
npm install -D /path/to/kyndryl-cto-shidoka-studio-0.x.x.tgz
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host vscode-copilot
```

That fallback is useful for a blocked teammate or for short-lived testing, but the preferred steady-state path is the recorded `devDependency` from GitHub Packages.

For Codex in VS Code, use:

```bash
npm install -D /path/to/kyndryl-cto-shidoka-studio-0.x.x.tgz
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host codex
```

---

## Working against a local `shidoka-studio` repo

Use this when someone is iterating on Studio itself.

### Option A: `file:` dependency

From the app repo, point at a built checkout of `shidoka-studio`:

```json
"devDependencies": {
  "@kyndryl-cto/shidoka-studio": "file:../shidoka-studio"
}
```

Then:

```bash
npm install
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor
```

Rebuild Studio in the other repo when you change it, then reinstall in the app if npm does not pick up changes.

### Option B: packed tarball

From the `shidoka-studio` repo root:

```bash
npm run prep
```

This runs the full local validation pipeline, then produces a tarball whose filename may include a local prerelease suffix such as `-local.<sha>`.

In the app repo:

```bash
npm install -D /path/to/kyndryl-cto-shidoka-studio-0.x.x.tgz
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor
```

Avoid hardcoding tarball names in shared scripts. Prefer GitHub Packages, `file:`, or `npm pack --json` when you need the latest generated filename.

### Legacy boilerplate wrapper scripts

Older boilerplates may still carry a wrapper such as `npm run shidoka-studio:setup-cursor`. That is now optional convenience only. The supported core flow is:

```bash
npm install --no-save --package-lock=false @kyndryl-cto/shidoka-studio@latest
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor
```

---

## What not to duplicate

- **Do not** add a second parallel Shidoka generation rule such as `shidoka-react.mdc`.
- **Do not** add a second `shidoka-studio` MCP server entry that fights the installer output.
- **Do not** scatter custom PATH fixes around multiple scripts. If you need special startup behavior, keep it in one launcher layer only.

---

## Troubleshooting

| Symptom | What to try |
|--------|----------------|
| `node scripts/install-shidoka-studio.mjs --host cursor` returns 401/403/404 | Confirm your PAT is **classic**, has **`read:packages`**, and is authorized for the org's **SSO**. The bootstrap script writes the safe project registry mapping automatically and never writes the token to the repo. |
| PAT/token prompt appears from the MCP server entry | Do not use `npx`, `shidoka-studio-install`, or `shidoka-studio-install-rule` as the runtime server command. Re-run the installer or print direct config with `node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor --print-mcp-config` / `--host vscode-copilot --print-mcp-config`. |
| MCP tools do not appear | Reload the host editor. Confirm the workspace root is the app folder. Confirm the host MCP config exists (`.cursor/mcp.json` or `.vscode/mcp.json`) and contains a `shidoka-studio` entry. |
| `node: command not found` or ENOENT when starting MCP | Re-run `node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor` so the platform launcher script is restored. If it still fails, install Node so GUI apps can resolve it and verify the launcher file exists under `scripts/`. |
| Tools still missing after install | Run `npm install --no-save --package-lock=false @kyndryl-cto/shidoka-studio@latest`, then `node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor`, then start a new chat. |
| Wrong or empty design context | See `env.example` in the package for optional `SHIDOKA_STUDIO_CONTEXT_PATH` and `SHIDOKA_STUDIO_CONTEXT_URL`. |
| Shidoka tools get in the way of non-UI work | Temporarily disable the MCP in the current host editor, or use the kill switches documented in the package README. |

**Windows:** the default installer writes `scripts/run-shidoka-studio-mcp.cmd` and configures the host MCP entry to start it with `cmd.exe`. If startup still fails, rerun `node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor`, then confirm `node.exe` is available to GUI apps and that the launcher file still exists under `scripts/`.

Deeper alignment guidance is covered in the packaged `context/consuming-app-setup-and-alignment.md` doc. In the source repo, the authored source lives at `docs/CONSUMING-APP-SETUP-AND-ALIGNMENT.md`.

---

## Using this document in a workspace

- **From the installed package** (after `npm install`):
  `node_modules/@kyndryl-cto/shidoka-studio/context/boilerplate-first-time-setup.md`
- **In your app repo**: copy this file into project docs if you want an onboarding page you can `@`-mention for teammates.

The canonical source for this text lives in the `shidoka-studio` repo at `docs/BOILERPLATE-FIRST-TIME-SETUP.md`.

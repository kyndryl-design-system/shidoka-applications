# Correcting generated pages (layout fixes)

If a generated Storybook or Vue page has layout issues, apply these fixes.

## 1. Decorator: remove negative margin

**Wrong (breaks main padding):**
```javascript
<div style="margin: var(--kd-negative-page-gutter); min-height: 100vh;">
  ${story()}
</div>
```

**Correct:**
```javascript
<div style="min-height: 100vh; width: 100%;">
  ${story()}
</div>
```

## 2. Main: add padding

**Wrong:** `<main>` with no style.

**Correct:** `<main style="padding: var(--kd-page-gutter, 1rem);">`

## 3. Main content order and spacing

**Required order inside `<main>`:**
1. **kyn-page-title** (headLine, pageTitle, subTitle) — all three by default for the standard headline → title → subtitle arrangement.
2. **Toolbar row** — one div with `display: flex; justify-content: space-between; align-items: center; gap: 1rem; margin: 1rem 0;` containing:
   - kyn-side-drawer (with kyn-button slot="anchor") + kyn-button kind="ghost" (use user labels or neutral defaults such as `Open details` and `Secondary action`)
3. **Chart wrapper** — `div` with `style="width: 100%; margin-bottom: 1.5rem;"` then kd-chart
4. **Table** — wrapper div with `width: 100%; overflow: auto; max-height: 360px;` then kyn-table-container > kyn-table. Do **not** add a border or border-radius by default unless the user explicitly requests a bordered table treatment.

**Wrong:** Chart first with no page title; drawer after the table; a secondary action button alone between chart and table. **Correct:** Page title → toolbar (drawer anchor + secondary action button in one row) → chart → table. Use uniform `margin-bottom: 1rem` or `1.5rem` (or a wrapper with `gap: 1rem`) between sections.

## 4a. Global switcher: red category headings missing (React)

If **Services** or **Administration** masonry shows **circle icons + links** but **no red category labels**, `kyn-header-category` never received a **DOM `heading` attribute**. React often does not map `heading={...}` to that attribute on custom elements.

**Fix:** add a small wrapper that runs `element.setAttribute('heading', heading)` in `useLayoutEffect`, and use it for **every** headed category (Console, Services tab panels, Administration). See the **“React — paste this wrapper”** block in `header-nav-required-snippets.md` / MCP `get_shidoka_header_nav_snippets` output.

## 4. Table wrapper

Wrap the table in a scrollable div so it doesn’t overflow:
```html
<div style="width: 100%; overflow: auto; max-height: 360px;">
  <kyn-table-container>
    <kyn-table>...</kyn-table>
  </kyn-table-container>
</div>
```

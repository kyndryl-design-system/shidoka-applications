# Shidoka Studio — Architecture

This document maps the current standalone architecture of **Shidoka Studio**: how authored contracts and design-system metadata become bundled MCP context for Cursor.

---

## High-level flow

```text
CEM + authored contract sources
  -> generation scripts
  -> src/generated/ + context-src/
  -> packaged context/ + bin/ + shared-foundation/ + styles/
  -> MCP tools
  -> Cursor generation/refinement
```

The important boundary is:
- authored inputs live in `src/content/`, `src/content/archetypes/`, `src/content/shared-foundation/`, `src/shared-foundation/`, `src/scripts/`, `src/server/`, `src/cli/`, and `docs/`
- generated/package mirrors live in `src/generated/`, `context-src/`, `context/`, `bin/`, the top-level packaged `shared-foundation/`, and `styles/`

For maintainers, the practical rule is simple:
- start in `src/`
- treat `src/generated/`, `context/`, `bin/`, top-level `shared-foundation/`, and `styles/` as outputs
- only edit packaged mirrors when you are intentionally debugging build output, not when making source changes

---

## 1. Authoritative sources

### Component/API authority
- `node_modules/@kyndryl-design-system/shidoka-applications/custom-elements.json` at build time
- read by `src/scripts/generate-component-registry.js`

### Human-authored guidance
- `src/content/considerations.md`
- `src/content/page-template-builder.md`
- `src/content/host-adapters/cursor-rule.template.mdc`

### Canonical contract sources
- `src/content/archetypes/catalog.json`
- `src/content/archetypes/data-table-page.json`
- `src/content/archetypes/header-nav.contract.json`

### Standalone prompt template sources
- `src/content/prompt-templates/catalog.json`

### Generation/runtime source
- `src/scripts/generate-full-page-artifacts.js`
- `src/scripts/canonical-artifacts/`
- `src/server/index.js`
- `src/server/context-loader.js`
- `src/cli/install.js`
- `src/scripts/artifact-manifest.js`
- `src/scripts/build.js`

### Shared foundation source
- `src/content/shared-foundation/`
- `src/content/shared-foundation/orchestration-policy.json`
- `src/shared-foundation/`

---

## 2. Contract families

Shidoka Studio now has two related contract families:

1. `canonical-header-nav`
- isolated source of truth for logo, global switcher, workspace switcher, and right-side flyouts
- used for header-only generation/fixes

2. `canonical-full-page`
- full shell contract for header + main + footer
- composes the standalone Header/Nav contract instead of re-owning that logic inline

Alongside those design-contract families, the shared foundation now also carries:

3. `orchestration-policy`
- host-neutral task-handling policy for canonical full-page and header-nav lanes
- defines durable behavior such as minimum adapter facts, fail-closed tool availability, and MCP-first repo-inspection boundaries
- intended to be consumed by thin host adapters rather than treated as a second design-authority layer

The canonical Cursor rule is now generated from that portable orchestration policy plus the host-specific adapter template at `src/content/host-adapters/cursor-rule.template.mdc`. Durable behavior changes should land in the portable policy first; the adapter template should change only when Cursor-specific frontmatter, wording, or host UX behavior changes.

Generated source artifacts for both families are written to `src/generated/` and then copied into `context/` during build.

---

## 3. Generated artifacts

### Generated source artifacts
These are committed mirrors for review/parity, but should not be edited directly.

- `src/generated/canonical-header-nav.md`
- `src/generated/canonical-header-nav-template.txt`
- `src/generated/canonical-header-nav-recipe.json`
- `src/generated/header-nav-required-snippets.md`
- `src/generated/canonical-full-page.md`
- `src/generated/canonical-full-page-template.txt`
- `src/generated/canonical-full-page-recipe.json`
- `src/generated/full-page-required-snippets.md`
- `src/generated/prompt-template-catalog.json`

### Intermediate build artifacts
- `context-src/`
  - CEM-derived registry/API context plus copied authored guidance
  - ignored by git

### Packaged runtime artifacts
- `context/`
  - runtime MCP payload served by the package, including shared-foundation JSON such as `orchestration-policy.json`
- `bin/`
  - packaged MCP server/runtime entrypoints
- `shared-foundation/`
  - packaged runtime mirror of `src/shared-foundation/`
- `styles/`
  - packaged CSS mirrors copied from `src/shared-foundation/styles/`

---

## 4. MCP tools

The runtime server in `src/server/index.js` exposes:

### Base design context
- `get_shidoka_design_context`
- `get_shidoka_support_docs`
- `get_workspace_ui_context`

### Experimental readiness / preflight tool
- `assess_shidoka_generation_readiness`
- `get_shidoka_prompt_template_catalog`
- `get_shidoka_prompt_template`
- `resolve_shidoka_prompt_template_alias`

### Experimental fallback supplements
- `get_shidoka_fallback_context`
- `get_shidoka_header_nav_fallback_context`

### Header/Nav contract tools
- `get_canonical_header_nav_template`
- `get_canonical_header_nav_recipe`
- `get_shidoka_header_nav_snippets`

### Full-page contract tools
- `get_canonical_full_page_template`
- `get_canonical_full_page_recipe`
- `get_shidoka_full_page_snippets`

### Auditor tools
- `get_shidoka_audit_rules`
- `audit_shidoka_usage`

This lets Cursor use the smaller Header/Nav contract when the task is specifically about the header, instead of always forcing a full-page flow.

The readiness helper is optional and capability-profile-backed. It can suggest clarification questions and a recommended bundled MCP toolchain, but it does not replace the canonical generation tools.

The standalone prompt-template tools are separate from the default generation surface. They are opt-in scaffold shortcuts and should not be treated as replacements for the canonical full-page or header-nav flows.

---

## 5. Build and packaging

### `npm run build`
Runs, in order:

1. `node src/scripts/generate-component-registry.js` — CEM-derived files into `context-src/` and copies authored guidance there.
2. `node src/scripts/generate-full-page-artifacts.js` — canonical header-nav and full-page artifacts into `src/generated/`, prompt library, Cursor rule, prompt-template catalog, and visual fixtures.
3. `node src/scripts/generate-reference-dashboard-fixture.js` — refreshes the reference dashboard fixture used by contract and visual checks.
4. `node src/scripts/generate-design-md.js` — builds and validates the packaged `design.md` artifact.
5. `node src/scripts/build.js` — copies packaged outputs into `context/`, `bin/`, `shared-foundation/`, `styles/`, etc.

The copy map is defined in `src/scripts/artifact-manifest.js`.

---

## 6. Testing strategy

### Contract/parity tests
- `__tests__/header-nav-artifacts.test.js`
- `__tests__/canonical-artifacts.test.js`
- `__tests__/content-consistency.test.js`
- `__tests__/context-load.test.js`

These verify:
- isolated Header/Nav derivation
- full-page composition
- on-disk/generated parity
- context-loader/runtime behavior

### Rendered acceptance
- `e2e/header-nav.contract.spec.js`
- `e2e/canonical-full-page.visual.spec.js`

The key change is that Header/Nav acceptance now renders real `kyn-*` components instead of relying only on string checks or a fake shell.

---

## 7. Edit policy

Edit these directly:
- `src/content/archetypes/`
- `src/content/capability-profiles/`
- `src/content/considerations.md`
- `src/content/design-md-tokens.json`
- `src/content/page-template-builder.md`
- `src/content/shared-foundation/`
- `src/shared-foundation/`
- `src/scripts/`
- `src/server/`
- `src/cli/`
- `docs/`

Do not edit these directly:
- `src/generated/`
- `context-src/`
- `context/`
- `bin/`
- `shared-foundation/`
- `styles/`

After source changes, regenerate with `npm run build`.

# Shidoka Studio in consuming apps — MCP setup and page alignment

For **first-time install on a new machine** (npm install, run the Shidoka installer for your host, reload the editor, enable MCP), start with the packaged `context/boilerplate-first-time-setup.md` doc. In the source repo, the authored source lives at `docs/BOILERPLATE-FIRST-TIME-SETUP.md`.

Shidoka is a **framework-agnostic** design system for consumers; components are implemented primarily in **Lit**. This doc applies to **any** consuming app (Vue, React, Next.js, Svelte, Angular, vanilla JS, etc.). It covers (1) **why** `get_shidoka_design_context` might not be called when building a page, (2) **how to fix it** so the MCP tool is available and used, and (3) a **checklist** to align an existing page with the Shidoka Studio context when it was built without the MCP.

Preferred activation command after install: `node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor`. The `npx shidoka-studio-install` alias still works after the package is installed, and the older `npx shidoka-studio-install-rule` command remains supported as a compatibility alias.

---

## How the external project “knows” to call get_shidoka_design_context first

**This .md file does not make the model call the tool.** It is documentation for the **developer**. The thing that makes the model call `get_shidoka_design_context` first when building a page is the **host instruction layer** that lives **in the project**. In Cursor that is the installed rule file (for example `.cursor/rules/shidoka-generation.mdc`). In VS Code / GitHub Copilot that is the installed workspace guidance under `.github/` (repo-wide instructions, path-specific instructions, and prompt files). In Codex that is the installed `AGENTS.md`. Those host files tell the agent to call the Shidoka MCP tools first and treat the MCP payload as design authority.

So the flow is:

1. **You (or your team) install Studio locally and run the installer once** in the external project: `node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor` for Cursor, `node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host vscode-copilot` for VS Code / Copilot, `node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host codex` for Codex, or `node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host both` for repos that support both Cursor and VS Code / Copilot.
2. **The installer configures the MCP server** in the project's `.cursor/mcp.json`, `.vscode/mcp.json`, or `.codex/config.toml` so the tool is available locally (section 2.1).
3. **The installer also writes the host guidance files** that tell the agent to call `get_shidoka_design_context` and, for full pages, `get_canonical_full_page_template`, `get_canonical_full_page_recipe`, and `get_shidoka_full_page_snippets` so output is generated from the same canonical structure, machine-readable recipe, and focused snippets in all projects. No per-framework or per-page setup is needed.

### GitHub Copilot / VS Code

The preferred Copilot path is now **workspace MCP + Copilot workspace files**, not just a workspace-file fallback.

From the consuming app root, run:

```bash
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host vscode-copilot
```

That installs:

- `.vscode/mcp.json`
- `.github/copilot-instructions.md`
- `.github/instructions/shidoka-ui.instructions.md`
- `.github/prompts/build-shidoka-page.prompt.md`
- `.github/prompts/fix-shidoka-header-nav.prompt.md`
- `.github/prompts/audit-shidoka-usage.prompt.md`

This gives VS Code a native MCP config plus Copilot-native instruction and prompt files, so the preferred path is still MCP-backed Shidoka generation.

If Copilot cannot reach the MCP server in the current environment, it can still read the packaged context directly from `node_modules`. For brand-level token decisions (colors, typography scale, spacing, WCAG contrast), point Copilot at:

- `node_modules/@kyndryl-cto/shidoka-studio/context/design.md`

This is a linted [DESIGN.md](https://github.com/google-labs-code/design.md) file with the Shidoka brand-token projection. It is **not** a replacement for the MCP's canonical generation tools — for full pages or shells always prefer the MCP payloads — but it is useful in environments where the MCP server is not reachable and for one-off color/typography grounding questions.

### Codex / VS Code

Codex uses project `.codex/config.toml` plus `AGENTS.md`, not `.vscode/mcp.json` and `.github/` Copilot files.

From the consuming app root, run:

```bash
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host codex
```

That installs:

- `.codex/config.toml`
- `AGENTS.md`

This gives Codex a project-scoped MCP config plus repo guidance that tells it to call the Shidoka MCP tools first and treat the payload as design authority.

---

## 1. Why the MCP wasn’t called

- **The Shidoka Studio MCP server wasn’t configured** in the project, so the host editor never started it and the tool `get_shidoka_design_context` wasn’t available. Without that tool, the model can only infer from the design system’s npm packages (.d.ts, source) and will miss the layout rules in `page-template-builder.md`, `considerations.md`, and the component registry.
- **No host instruction layer** told the agent to call the tool when generating Shidoka pages, so even if the server was running, the model might not call it.
- **Configured/enabled is not the same as discoverable in the current chat.** A host MCP/server UI can show `shidoka-studio` as configured and enabled, but the current chat/session may still not have the Shidoka tool namespace loaded yet because of stale tool registration, a startup/permission mismatch, or a host-session refresh issue. In that state, the correct diagnosis is **"configured but not discoverable/callable in this session"**, not **"no access"**. Empty MCP resource/template lists alone are not enough to prove that the server is absent; the important check is whether the required Shidoka tools are actually callable in the current session.

Result: the generated page follows package API inference but **not** the template’s shell order, main padding, table wrapper, title/toolbar rhythm, chart options, or global switcher pattern.

---

## 2. Fix: Make the MCP available in your project

### 2.1 Configure the MCP server

The recommended Cursor path in the **project root** is:

```bash
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor
```

On macOS/Linux, the installer usually writes a `bash` launcher entry so Cursor can resolve `node` even when it comes from `nvm`, `fnm`, or `asdf`:

```json
{
  "mcpServers": {
    "shidoka-studio": {
      "command": "bash",
      "args": ["scripts/run-shidoka-studio-mcp.sh"],
      "cwd": "${workspaceFolder}"
    }
  }
}
```

On Windows, the installer writes a `cmd.exe` launcher entry so Cursor can start the same local server even when `node.exe` is not directly available to the GUI process:

```json
{
  "mcpServers": {
    "shidoka-studio": {
      "command": "cmd.exe",
      "args": [
        "/d",
        "/s",
        "/c",
        ".\\scripts\\run-shidoka-studio-mcp.cmd"
      ],
      "cwd": "${workspaceFolder}"
    }
  }
}
```

If you need to create or edit **`.cursor/mcp.json`** manually instead, the minimal direct Node config is:

```json
{
  "mcpServers": {
    "shidoka-studio": {
      "command": "node",
      "args": [
        "./node_modules/@kyndryl-cto/shidoka-studio/bin/server.js"
      ],
      "cwd": "${workspaceFolder}"
    }
  }
}
```

**Important workspace-scope rule:** this `.cursor/mcp.json` only applies when that consuming app is the **active Cursor workspace**. If Cursor is opened to a parent repo, sibling repo, or another workspace root, the consuming app's project-local MCP config will not be loaded and Shidoka MCP tools will appear unavailable in chat even if the files are installed correctly under that app's `node_modules`.

If you sideloaded by copying the built package into `node_modules/@kyndryl-cto/shidoka-studio`, this path is correct. Alternatively:

```json
"command": "npx",
"args": ["-y", "@kyndryl-cto/shidoka-studio"],
"cwd": "${workspaceFolder}"
```

**If `node` fails to start** (`ENOENT`, `node: command not found`), rerun `node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor` first so the packaged launcher is restored. On macOS/Linux this restores the `bash` launcher; on Windows it restores the `cmd.exe`-backed `.cmd` launcher. If it still fails, install Node so GUI apps can see it.

For VS Code, the corresponding command is:

```bash
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host vscode-copilot
```

That writes `.vscode/mcp.json` instead of `.cursor/mcp.json` and installs the Copilot workspace files under `.github/`.

For org-internal starter repos and long-lived product repos that want to support both editors at once, the preferred maintainer path is:

```bash
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host both
```

Commit the generated `.cursor/`, `.vscode/`, and `.github/` workspace files in that consuming repo. That keeps the existing Cursor path intact while making VS Code / Copilot available without requiring every teammate to rerun the installer after clone.

### 2.2 Add host instructions (so the agent calls the tool first)

**Cursor**

Install the rule from the package so the agent is instructed to call the MCP tools first when building pages:

```bash
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor
```

This installs or syncs `.cursor/rules/shidoka-generation.mdc` and `.cursor/mcp.json` in the current project. The MCP config merge preserves unrelated `mcpServers` entries and ensures `shidoka-studio` points at the project-local installed package, using the direct `node` entry or the platform-native launcher flow as needed. If the target project is a design-system repo whose package name matches `@kyndryl-design-system/shidoka-*`, the installer also syncs `.cursor/rules/generated-story-output.mdc` so generated Storybook pages go to the canonical ephemeral output location. If a different local copy already exists, the installer creates a timestamped backup and writes the canonical rule or MCP config from the package.

**VS Code + GitHub Copilot**

Install the VS Code MCP config plus Copilot workspace files:

```bash
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host vscode-copilot
```

This installs or syncs `.vscode/mcp.json`, `.github/copilot-instructions.md`, `.github/instructions/shidoka-ui.instructions.md`, and the packaged prompt files under `.github/prompts/`. Together those files give Copilot the same MCP-first intent as the Cursor rule, but in VS Code's native workspace-file format.

If the direct installer path is missing, refresh the local package first:

```bash
npm install
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor
```

For local `file:` dependency workflows, you can always run the packaged script directly:

```bash
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor
```

**Temporarily disable the MCP (kill switch):** If Shidoka Studio is interfering with other work (e.g. non-Shidoka edits or prompts), you can disable it without removing the server from the host MCP config. Use **one** of: (1) set env `SHIDOKA_STUDIO_MCP_DISABLED=1` or `true`; (2) create `.cursor/shidoka-studio.json` in the project root with `{ "mcpEnabled": false }`; (3) create an empty file `.shidoka-studio-disabled` in the project root. When disabled, all MCP tools return a short message and no design system context. To re-enable, remove the env, set `mcpEnabled: true`, or delete the marker file, then reload the host editor. See the package README section **Temporarily Disable The MCP**.

To target a different project path:

```bash
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --project /path/to/project --host cursor
```

The shipped rule is framework-agnostic (globs cover Storybook, Vue, React, Next, Svelte, etc.). Cursor still infers the correct file type and placement from the workspace and prompt. You can edit `.cursor/rules/shidoka-generation.mdc` to adjust **globs** to your project (e.g. add `src/routes/**/*.svelte` for SvelteKit). The important part is that the rule tells the agent to call the required Shidoka MCP tools before generation **and** to treat those MCP payloads as the sole design authority for page generation.

Do **not** create a second framework-specific Shidoka generation rule such as `shidoka-vue.mdc` or `shidoka-react.mdc`. That creates competing instructions and weakens standardization. The supported pattern is one canonical `shidoka-generation.mdc` rule plus framework inference for syntax/output type.

For page generation, local repo context is allowed only for:

- framework syntax
- output file type
- output destination

It is **not** allowed to use local repo context to decide:

- page composition or shell order
- whether to inspect/replace a home page such as `welcome.mdx`
- whether to mirror an existing repo-specific Storybook page shell
- which unrelated local file should be repurposed as the generated page target

### 2.3 Reload the host editor

Reload Cursor or VS Code so it picks up the MCP server and the new host guidance files. After that, when you ask to build a Shidoka page, the agent should have `get_shidoka_design_context` available and should call it before generation.

### 2.3a Configured in the UI, but still missing in chat

If the host MCP/server UI shows `shidoka-studio` as enabled but the chat still says the server is unavailable, treat that as a **session discovery** problem first, not as proof that the server is missing.

Use this order:

1. Confirm the project-local MCP config is attached to the **active workspace root**.
2. Toggle the `shidoka-studio` server off/on in the host MCP UI.
3. Reload the editor/host.
4. Start a **fresh chat/session** so tool registration refreshes.
5. Retry the same prompt and verify the Shidoka tool namespace is callable.

When diagnosing this state, be precise: **configured/enabled in the UI** and **callable in the current chat** are different checks. Do not conclude "no MCP access" only because an MCP inspector view shows no resources/templates.

For a direct workspace-level verification, run the packaged doctor command from the consuming repo root:

```bash
npx shidoka-studio-doctor --host cursor
```

Replace `cursor` with `vscode-copilot`, `codex`, or `both` to make the doctor command launch the configured stdio server, perform an MCP handshake, list tools, and confirm that the Shidoka tool namespace is actually discoverable.

### 2.4 Why the same prompt can produce different output in the Vue project

The **same page prompt** (e.g. UI shell, global switcher, workspace switcher, 5-row table, side drawer, line graph) should produce the **same structure** in the shidoka-applications repo and in your Vue app—same `kyn-header` (global nav + flyouts), same main (title, toolbar, drawer with **titleText**, table with **kyn-thead** and **kyn-th** headers, chart, footer). If the Vue-generated page looks different (e.g. workspace switcher inside the global nav, no table headers, no drawer title), the model is not fully applying the MCP context.

**Standardization boundary:** File type and destination may differ by repo, but **page composition must come from the MCP payload only**. Local Storybook stories, generated pages, component source files, docs pages, home pages, and example JSON are not supposed to be the design authority for page generation, even inside `shidoka-applications`.

**Common causes:**

1. **Host guidance not firing or tool not called** — The installed Cursor rule or Copilot workspace guidance must tell the agent to call the required Shidoka MCP tools first; without that, the model infers from package types or repo-local files and skips canonical layout/table/drawer rules.
2. **Stale sideload** — If you copied an old build of Shidoka Studio into the Vue project’s `node_modules`, the context (e.g. canonical-full-page, CRITICAL table/drawer/header rules) may be missing or outdated. Rebuild in `shidoka-studio` (`npm run build`) and replace the Vue project’s `node_modules/@kyndryl-cto/shidoka-studio` with the new build, then reload the host editor.
3. **Context not prioritized** — The canonical full-page doc now includes **CRITICAL** blocks for: (a) do not put workspace switcher inside global nav, (b) table must have kyn-thead + kyn-th with text, (c) kyn-side-drawer must have titleText, (d) **workspace/global switcher:** generated stories MUST include the required CSS block in the decorator (`.account-name`, `.account-chevron`, `.ui-impl-switcher` 625px + responsive) so dimensions and layout match the reference. After updating the build, start a **new chat** and run the same prompt so the model gets the full context.

4. **Shidoka Studio in its own repo/package (post-migration):** The MCP context is **only** what is in the built `context/` folder of the `shidoka-studio` package. Generated output can diverge on workspace/global switcher **dimensions and CSS** unless that packaged context is up to date and explicit. After pulling `shidoka-studio`, run **`npm run build`** in the `shidoka-studio` project so `context/` (canonical-full-page.md, page-template-builder.md, etc.) is refreshed. The canonical docs now include the required CSS block and wiring snippets directly, so page generation does not need repo-only story access or local entry-page inspection.

After fixing the host guidance, sideload, and reload, regenerate the page; the output should align with the repo.

**Alternative: Three-prompt workflow for Vue (or other consuming apps)**  
If a single “build the full page” prompt keeps producing the wrong header (e.g. minimal shell, hamburger-only, or app routes in the global switcher), split the work into three prompts so each step has a smaller scope and the MCP payload is easier to apply:

1. **Build the UI shell as a common component** — Ask the model to create a shared component (e.g. `ShidokaShell.vue`) that contains the full canonical structure (header with global switcher + four flyouts, optional local nav, main slot, footer). The model should call the MCP tools and use the canonical template/snippets for the shell only.
2. **Use the shell in the global layout** — Ask to include that component in the app’s root layout (for example `App.vue`, `App.tsx`, or the router layout) so the framework-native route outlet is inside the shell’s main area. In React Router that means `<Outlet />`; in Vue Router that means `<router-view />`; in other frameworks use the normal routed outlet. Every page then gets the correct header and footer without regenerating the shell.
3. **Build the page body** — Ask to create the page view with only the main content (page title, charts, table, drawer, buttons). The model should use the canonical main structure from the MCP and not include the header/shell, since that lives in the layout.

This reduces the chance of the model dropping or copying the wrong header, because step 1 is only about the shell and step 3 is only about the body. In the Shidoka Studio source repo, `docs/prompt-library/GENERATED-PROMPTS.md` has copy-paste prompt text for each step.

**Fixing the wrong header (hamburger + search bar + empty right)**  
If your app still shows a header with: **hamburger menu + input/search bar with "kyndryl" text + empty right side** (no workspace switcher, no notifications/help/user icons or flyouts), that is the **wrong** pattern. The correct Shidoka header has: (1) logo in `slot="logo"` (approved asset, not a search field), (2) **kyn-header-nav** that mirrors `GlobalSwitcher.stories.js#JSONSwitcher`, (3) **kyn-header-flyouts** with **four** flyouts that mirror `workspaceSwitcher.stories.js#UIImplementation`—workspace switcher (trigger + chevron), notifications icon, help icon, user icon. In consuming apps, interactive header icons must use approved inline SVG assets rather than `<img>` so hover and active color tokens flow through `currentColor`. To fix the wrong header:

1. **Replace the layout’s header with the canonical shell.** Use the three-prompt workflow: first prompt — *"Create a shared Shidoka UI shell component (e.g. ShidokaShell.vue) with the full canonical header: logo in slot=logo, kyn-header-nav that mirrors GlobalSwitcher.stories.js#JSONSwitcher, and kyn-header-flyouts with all four flyouts that mirror workspaceSwitcher.stories.js#UIImplementation (workspace switcher, notifications, help, user). For interactive flyout buttons, workspace triggers, and local-nav icons, inline approved Shidoka SVG assets instead of using `<img>` so hover and active color tokens work through `currentColor`. Call get_shidoka_design_context, get_canonical_full_page_template, and get_shidoka_full_page_snippets. Emit only the shell component with a default slot for main content."* Second prompt — *"Use ShidokaShell in the app’s root layout. Put the framework-native route outlet inside the shell’s main area (`<router-view />` in Vue Router, `<Outlet />` in React Router). Remove the current header (hamburger + search bar + empty right) so the shell provides the header and footer for all pages."* That replaces the wrong header with the correct one. After that, page views only need to supply the main body (step 3).

2. **Ensure MCP and host guidance are active.** If the MCP is disabled or the host guidance files are missing, the model may not call the tools and can fall back to the existing layout. Install the host files, configure the workspace MCP entry, and start a **new chat** before running the fix prompts.

3. **Use a fresh Shidoka Studio build.** If the Vue app’s `node_modules/@kyndryl-cto/shidoka-studio` is old, the canonical template and snippets may not include the latest header/flyout rules. Rebuild shidoka-studio and sideload the updated package into the Vue app, then retry.

### 2.5 Why can output still drift between repos?

The MCP server **always** loads context from the **same place**: the `context/` folder **inside the Shidoka Studio package** that is running the server. The difference is **which copy** of that package is used and whether the installed host guidance actually forces the agent to treat that MCP payload as authoritative.

- **In the shidoka-applications repo (“here”):** When the host editor runs the MCP, it starts the server from the package that the repo depends on. That package resolves to the local `node_modules/@kyndryl-cto/shidoka-studio` copy. Its `context/` folder is updated when you rebuild or reinstall that package. This repo may also contain additional Storybook and component files, but those are **not supposed to be the design authority for page generation**.
- **In the Vue project:** The server runs from **the package inside the Vue project**, i.e. `VueProject/node_modules/@kyndryl-cto/shidoka-studio`. That folder is **not** updated when you change the repo. It only changes when you:
  - **Sideload:** copy the freshly built package contents from this repo root (`bin/`, `context/`, `examples/`, `package.json`, and `README.md`) into the Vue project’s `node_modules/@kyndryl-cto/shidoka-studio`, or
  - Reinstall from npm (which gives you whatever is **published**, often older).

So the context can drift because the Vue project may be using a **different, and usually older, snapshot** of the same `context/` files, or because one repo is allowing the agent to lean on local examples instead of the MCP payload. The **code path** is the same (server → load from package `context/`), but the **physical files** in the project’s package copy and the installed host guidance determine whether page generation stays standardized.

To make the Vue project’s context match “here”: run `npm run build` in this repo, then replace the Vue project’s `node_modules/@kyndryl-cto/shidoka-studio` with the freshly built package contents from this repo root, then reload the host editor.

---

## 3. Align an existing page with the context

If you already have a page that was built **without** calling the MCP, you can align it with the Shidoka Studio context by applying the rules below. The structure is the same in any framework; express it in your template syntax (Vue, JSX, Svelte, etc.).

### 3.1 Shell order

Inside **kyn-ui-shell**, children must be in this order:

1. **kyn-header**
2. **kyn-local-nav** (optional)
3. **main**
4. **kyn-footer**

**Fix:** Add **kyn-footer** after `</main>` and before `</kyn-ui-shell>`. Structure:

```html
<kyn-footer rootUrl="/" logoAriaLabel="Home">
  <span slot="copyright">Copyright © … Kyndryl Inc. All rights reserved.</span>
</kyn-footer>
```

Use your framework’s way to inject the current year (e.g. `{{ new Date().getFullYear() }}`, `{new Date().getFullYear()}`, etc.).

### 3.2 Main padding

**Fix:** Set the required main padding so content isn’t edge-to-edge:

```html
<main style="padding: var(--kd-page-gutter, 1rem);">
  <!-- all main content here -->
</main>
```

Remove any section classes or custom margins that replace this; the template requires this exact style on `<main>`.

### 3.3 Layout rhythm: page title → toolbar → content

**Fix:** Add **kyn-page-title** and a **toolbar row** between the title and the main content (drawer anchor, buttons, then table/chart).

- Page title: `<kyn-page-title headLine="…" pageTitle="…" subTitle="…"></kyn-page-title>`. Use all three by default (headLine = section, pageTitle = main title, subTitle = description).
- Toolbar: a single row with `style="display: flex; justify-content: space-between; align-items: center; gap: 1rem; margin: 1rem 0;"` containing the side-drawer (with its anchor button) and any primary buttons.
- Then spacing, then the table/chart.

Do not put the drawer anchor or actions directly under the title with no spacing.

### 3.4 Table wrapper

**Fix:** Wrap the table in a **scrollable outer div** with the required styles, then **kyn-table-container** and **kyn-table** inside. **Include a header row:** `kyn-thead` with one `kyn-header-tr` and one `kyn-th` per column (e.g. Name, Role, Status)—do not leave thead empty. Do **not** add a border or border-radius by default unless the user explicitly requests a bordered table treatment.

```html
<div
  style="width: 100%; overflow: auto; max-height: 360px;"
>
  <kyn-table-container>
    <kyn-table>
      <kyn-thead>
        <kyn-header-tr>
          <kyn-th>Name</kyn-th>
          <kyn-th>Role</kyn-th>
          <kyn-th>Status</kyn-th>
        </kyn-header-tr>
      </kyn-thead>
      <kyn-tbody>…</kyn-tbody>
    </kyn-table>
  </kyn-table-container>
</div>
```

### 3.4b Side drawer title

**Fix:** Set **`titleText`** (headline) and **`labelText`** (subheader) on `kyn-side-drawer` (e.g. `titleText="Details"` and `labelText="Use this drawer for filters, details, or additional actions."`) so the drawer panel shows a visible header with title and description.

### 3.5 Line chart

**Fix:** Apply the template’s chart rules:

- **Wrapper:** `<div style="width: 100%; margin-bottom: 1.5rem;">` around the chart.
- **Chart:** `<kd-chart>` with `style="width: 100%; display: block;"`, `height="360"`, and options: `maintainAspectRatio: false`, `responsive: true`.
- **Line chart specifically:** `type="line"`; each dataset has **`fill: false`**; **scales** in options so X and Y axes are visible, e.g. `scales: { x: { display: true, title: { display: true, text: 'Category' } }, y: { display: true, title: { display: true, text: 'Value' }, beginAtZero: true } }`.

### 3.6 Global switcher

**Fix:** Use **kyn-header-link** in **kyn-header-nav** for the global switcher (not a plain flyout with placeholder text):

- Do **not** set `hideSearch` on the main global switcher **kyn-header-link** so the flyout shows the search input.
- Use **kyn-header-category** with **heading="CATEGORY"** and multiple **kyn-header-link** children in `slot="links"` (e.g. Connections Management, Discovered Data, Visualization & Analytics, Topology, Settings).
- Ensure 6+ child links or set **searchThreshold="2"** so search appears.
- Header: **logo** in `slot="logo"` and a concise app title such as `appTitle="Dashboard"` (avoid route-style labels like `Dashboard1`).

Reference: page-template-builder.md sections 5c and 5d; considerations.md “Workspace switcher and global switcher”.

### 3.7 `kyn-modal` and `kyn-side-drawer` — `open` state (Lit components, any app framework)

Shidoka is implemented in **Lit**; the repo using Shidoka Studio MCP may be **React, Vue, Svelte, Next.js, vanilla JS**, or another stack—the integration pitfall is the same shape.

**Symptom:** Closing the overlay (X, Ok, Cancel, etc.) seems to need **two interactions**, or the overlay **reopens**.

**Cause:** On dismiss the component updates **`open` internally**. If the app also **binds `open` from reactive state**, the next render/update can **re-apply `open=true` from state that has not caught up yet**, which **reopens** the overlay. This is **app-layer state fighting internal close**, not usually anchor bubbling.

**What works (all frameworks):**

- **Prefer uncontrolled:** Do **not** pass `open` from app state; use the **anchor** slot and built-in behavior. Listen to **`on-close`** / **`on-open`** only for side effects (telemetry, focus), not to drive `open` unless you keep state perfectly in sync.
- **If you must control:** Omit `open` when closed so the framework does not re-apply it after an internal close. Only pass **`open` when the overlay should be open**; avoid an always-bound `open` that can lag one tick behind the element after dismiss.

Canonical detail: `full-page-required-snippets.md` (drawers/modals); `considerations.md` (“kyn-modal / kyn-side-drawer open, any framework”).

---

## 4. Summary

| Gap                                | Fix                                                                                                                                   |
| ---------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| No kyn-footer                      | Add kyn-footer after main, before closing kyn-ui-shell.                                                                               |
| Main padding                       | `<main style="padding: var(--kd-page-gutter, 1rem);">`.                                                                               |
| Table wrapper                      | Outer div with `width: 100%; overflow: auto; max-height: 360px;` then kyn-table-container > kyn-table. Add border or border-radius only when the user explicitly asks for a bordered table treatment. |
| Missing table headers              | Include kyn-thead with kyn-header-tr and one kyn-th per column (e.g. Name, Role, Status); do not leave thead empty.                   |
| No kyn-page-title / toolbar rhythm | Add kyn-page-title, then toolbar row (flex, gap, margin 1rem 0), then content.                                                        |
| Side drawer no title/subheader     | Set titleText (headline) and labelText (subheader) on kyn-side-drawer so the drawer shows a visible header with title and description.  |
| Line chart                         | Full-width wrapper; kd-chart with maintainAspectRatio: false, height 360; line: fill: false, scales for axes.                         |
| Global switcher                    | kyn-header-link in kyn-header-nav, search + kyn-header-category with CATEGORY and links.                                              |
| Modal/drawer closes then reopens | Prefer **no** `open` from app state (any framework); use anchor + `on-close` / `on-open` for side effects. If controlling `open`, omit when closed so stale `open=true` does not re-apply after dismiss. See §3.7. |

After applying these and configuring the MCP + host guidance (section 2), future page generation in your project can use `get_shidoka_design_context` and pages will be informed by the Shidoka Studio context regardless of framework.

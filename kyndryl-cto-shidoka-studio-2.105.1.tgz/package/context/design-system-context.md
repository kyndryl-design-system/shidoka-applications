# Shidoka Design System — Context for LLM

**Source of truth: custom-elements.json.** This file is generated from it. Do not edit; run `npm run build` to regenerate.

Only use kyn-* tags and attributes/slots/events listed below. Invented tags or attributes will break the build.

**Import paths:** The "Import (design-system repo)" lines below are for the shidoka-applications repo only. In a consuming app (npm-installed packages), use the package import once; see considerations "Import path resolution".

## Component reference (from CEM)

### `<kyn-accordion>`
- **Import (design-system repo):** `import '../../components/reusable/accordion/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** showNumbers, startNumber, filledHeaders, compact, expandLabel, collapseLabel
- **Slots:** unnamed
  - `unnamed`: Holds Accordion Items (kyn-accordion-item) that make up the accordion
- **Description:** Accordion component.

### `<kyn-accordion-item>`
- **Import (design-system repo):** `import '../../components/reusable/accordion/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** opened, disabled
- **Slots:** icon, body, title, subtitle
  - `icon`: Optional leading icon. 24px, or 16px for compact.
  - `body`: Body of the accordion item.
  - `title`: Title of the accordion item.
  - `subtitle`: Optional subtitle of the accordion item.
- **Events:** on-toggle
- **Description:** Accordion Item component. *

### `<kyn-ai-launch-btn>`
- **Import (design-system repo):** `import '../../components/ai/aiLaunchButton/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** disabled
- **Events:** on-click
- **Description:** AI Assistant Launch Button.

### `<kyn-ai-loader>`
- **Import (design-system repo):** `import '../../components/reusable/loaders/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** size, ariaLabel
- **Description:** AI Loader (pure CSS/SVG).

### `<kyn-ai-sources-feedback>`
- **Import (design-system repo):** `import '../../components/ai/sourcesFeedback/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** sourcesOpened, feedbackOpened, sourcesDisabled, feedbackDisabled, revealAllSources, textStrings, closeText
- **Slots:** copy, sources, feedback-form
  - `copy`: copy button
  - `sources`: source cards in source panel.
  - `feedback-form`: Positive feedback form.
- **Events:** on-feedback-deselected, on-toggle
- **Description:** AISourcesFeedback Component.

### `<kyn-avatar>`
- **Import (design-system repo):** `import '../../components/reusable/avatar/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** initials
- **Slots:** unnamed
  - `unnamed`: Slot for the profile picture img.
- **Description:** User avatar.

### `<kyn-badge>`
- **Import (design-system repo):** `import '../../components/reusable/badge/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** label, size, type, status, noTruncation, iconTitle, hideIcon
- **Slots:** unnamed
  - `unnamed`: Slot for custom icon.
- **Description:** Badge.

### `<kyn-block-code-view>`
- **Import (design-system repo):** `import '../../components/reusable/blockCodeView/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** darkTheme, language, lineNumbers, startLineNumber, maxHeight, flush, codeViewLabel, copyOptionVisible, codeViewExpandable, copyButtonText, copyButtonDescriptionAttr, codeSnippet, textStrings
- **Events:** on-copy
- **Description:** `<kyn-block-code-view>` component to display `<code>` snippets as standalone single-/multi-line block elements.

### `<kyn-breadcrumbs>`
- **Import (design-system repo):** `import '../../components/reusable/breadcrumbs/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Slots:** unnamed
  - `unnamed`: Slot for inserting links.
- **Description:** Breadcrumbs Component.

### `<kyn-button>`
- **Import (design-system repo):** `import '../../components/reusable/button/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** description, type, kind, href, target, size, iconPosition, disabled, value, name, isFloating, showOnScroll, selected, formmethod, splitLayout
- **Slots:** unnamed, icon
  - `unnamed`: Slot for button text.
  - `icon`: Slot for an icon.
- **Events:** on-click
- **Description:** Button component.

### `<kyn-button-float-container>`
- **Import (design-system repo):** `import '../../components/reusable/floatingContainer/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Slots:** unnamed
  - `unnamed`: Slot for kyn-button options.
- **Description:** Floating Container.

### `<kyn-button-group>`
- **Import (design-system repo):** `import '../../components/reusable/buttonGroup/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** kind, vertical, selectedIndex, totalPages, maxVisible, clickIncrementBy, textStrings
- **Slots:** unnamed
  - `unnamed`: Slot for <kyn-button> elements.
- **Events:** on-change
- **Description:** ButtonGroup component.

### `<kyn-card>`
- **Import (design-system repo):** `import '../../components/reusable/card/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** type, href, rel, target, hideBorder, aiConnected, highlight, compact, variant
- **Slots:** unnamed, leftIcon, inlineConfirm
  - `unnamed`: Slot for card contents.
  - `leftIcon`: Slot for left icon when `variant` is `'notification'`.
  - `inlineConfirm`: Slot for right icon when `variant` is `'notification'`.
- **CSS parts:**
  - `card-wrapper`: The wrapper element of the card. Use this part to customize its styles such as padding . Ex: kyn-card::part(card-wrapper)
- **Events:** on-card-click
- **Description:** Card.

### `<kyn-checkbox>`
- **Import (design-system repo):** `import '../../components/reusable/checkbox/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** value, disabled, readonly, notFocusable, visiblyHidden, indeterminate
- **Slots:** unnamed
  - `unnamed`: Slot for label text.
- **Events:** on-checkbox-change
- **Description:** Checkbox.

### `<kyn-checkbox-group>`
- **Import (design-system repo):** `import '../../components/reusable/checkbox/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** value, name, invalidText, required, disabled, readonly, horizontal, selectAll, hideLegend, filterable, label, searchTerm, limitCheckboxes, limitCount, textStrings
- **Slots:** unnamed, tooltip, description
  - `unnamed`: Slot for individual checkboxes.
  - `tooltip`: Slot for tooltip.
  - `description`: Slot for description text.
- **Events:** on-checkbox-group-change, on-search, on-limit-toggle
- **Description:** Checkbox group container.

### `<kyn-checkbox-subgroup>`
- **Import (design-system repo):** `import '../../components/reusable/checkbox/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Slots:** unnamed, parent
  - `unnamed`: Slot for child kyn-checkboxes.
  - `parent`: Slot for parent kyn-checkbox.
- **Description:** Checkbox subgroup

### `<kyn-color-input>`
- **Import (design-system repo):** `import '../../components/reusable/colorInput/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** value, name, invalidText, label, caption, disabled, required, hideLabel, readonly, textStrings, autoComplete
- **Slots:** tooltip
  - `tooltip`: Slot for tooltip.
- **Events:** on-input
- **Description:** Color input.

### `<kyn-date-picker>`
- **Import (design-system repo):** `import '../../components/reusable/datePicker/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** name, invalidText, value, label, hideLabel, locale, dateFormat, default-date, defaultErrorMessage, required, size, warnText, disable, enable, mode, caption, datePickerDisabled, readonly, twentyFourHourFormat, minDate, maxDate, allowManualInput, errorAriaLabel, errorTitle, warningAriaLabel, warningTitle, staticPosition, textStrings
- **Slots:** tooltip
  - `tooltip`: Slot for tooltip.
- **Events:** on-change
- **Description:** Datepicker: uses Flatpickr's datetime picker library -- `https://flatpickr.js.org`

### `<kyn-date-range-picker>`
- **Import (design-system repo):** `import '../../components/reusable/daterangepicker/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** name, value, invalidText, label, hideLabel, locale, dateFormat, default-date, rangeEditMode, defaultErrorMessage, warnText, disable, enable, caption, required, size, dateRangePickerDisabled, readonly, twentyFourHourFormat, minDate, allowManualInput, maxDate, errorAriaLabel, errorTitle, warningAriaLabel, warningTitle, staticPosition, textStrings
- **Slots:** tooltip
  - `tooltip`: Slot for tooltip.
- **Events:** on-change
- **Description:** Date Range Picker: uses Flatpickr library, range picker implementation -- `https://flatpickr.js.org/examples/#range-calendar`

### `<kyn-divider>`
- **Import (design-system repo):** `import '../../components/reusable/divider/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** vertical, drag-handle, decorative, resizeLabel, dragging, hideHairline, inverted-handle
- **Description:** Divider Component.

### `<kyn-dropdown>`
- **Import (design-system repo):** `import '../../components/reusable/dropdown/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** value, name, invalidText, label, size, kind, inline, caption, placeholder, open, searchable, searchThreshold, enhanced, readonly, filterSearch, multiple, required, hideLabel, disabled, hideTags, selectAll, selectAllText, menuMinWidth, openDirection, textStrings, allowAddOption, preventDuplicateAddOption, allowDuplicateSelections, searchText
- **Slots:** unnamed, tooltip, anchor, add-option-input, add-option-button
  - `unnamed`: Slot for dropdown options.
  - `tooltip`: Slot for tooltip.
  - `anchor`: Slot for custom dropdown anchor element. If not provided, defaults to standard input-style anchor.
  - `add-option-input`: Slot for providing a custom “Add new option” input.
  - `add-option-button`: Slot for providing a custom “Add new option” button.
- **Events:** kind-changed, on-change, on-search, on-clear-all, on-add-option
- **Description:** Dropdown, single select.

### `<kyn-dropdown-category>`
- **Import (design-system repo):** `import '../../components/reusable/dropdown/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Slots:** unnamed
  - `unnamed`: Slot for category title text.
- **Description:** Dropdown category.

### `<kyn-dropdown-option>`
- **Import (design-system repo):** `import '../../components/reusable/dropdown/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** value, disabled, allowAddOption, removable, indeterminate, readonly, role, aria-selected
- **Slots:** unnamed, icon
  - `unnamed`: Slot for option text.
  - `icon`: Slot for option icon. Icon size should be 16px only.
- **Events:** on-click, on-remove-option
- **Description:** Dropdown option.

### `<kyn-enhanced-dropdown-option>`
- **Import (design-system repo):** `import '../../components/reusable/dropdown/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** value, disabled, readonly, allowAddOption, removable, indeterminate, role, aria-selected
- **Slots:** icon, title, tag, description, optionType, unnamed
  - `icon`: Slot for option icon. Icon size should be 16px only.
  - `title`: Slot for option title text.
  - `tag`: Slot for inline tag appended to title.
  - `description`: Slot for option description text.
  - `optionType`: Slot for option type label.
  - `unnamed`: Fallback slot for simple text content.
- **Events:** on-click, on-remove-option, on-blur
- **Description:** Enhanced Dropdown option with rich content support.

### `<kyn-error-block>`
- **Import (design-system repo):** `import '../../components/reusable/errorBlock/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** titleText
- **Slots:** unnamed, image, actions
  - `unnamed`: Slot for the error description.
  - `image`: Slot for the error image.
  - `actions`: Slot for the action buttons.
- **Description:** Error block.

### `<kyn-expanded-tr>`
- **Import (design-system repo):** `import '../../components/reusable/table/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** colspan, expanded
- **Slots:** unnamed
  - `unnamed`: The slot for adding content to the expandable details section.
- **Description:** 
`kyn-expanded-tr` Web Component.

Designed to display additional details for a row in a table.
The row is expandable and can be expanded/collapsed by toggling the plus/minus icons.

### `<kyn-file-uploader>`
- **Import (design-system repo):** `import '../../components/reusable/fileUploader/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** name, accept, multiple, textStrings, maxFileSize, disabled, validFiles, invalidFiles
- **Slots:** upload-status
  - `upload-status`: Slot for upload status/notification.
- **Events:** selected-files
- **Description:** File Uploader

### `<kyn-file-uploader-list-container>`
- **Import (design-system repo):** `import '../../components/reusable/fileUploader/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** titleText, textStrings
- **Slots:** unnamed, action-button
  - `unnamed`: Slot for individual file uploader items.
  - `action-button`: Slot for action button.
- **Description:** File Uploader List Container

### `<kyn-footer>`
- **Import (design-system repo):** `import '../../components/global/footer/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** rootUrl, logoAriaLabel
- **Slots:** unnamed, logo, copyright
  - `unnamed`: Default slot, for links.
  - `logo`: Slot for the logo, will overwrite the default logo.
  - `copyright`: Slot for the copyright text.
- **Events:** on-root-link-click
- **Description:** The global Footer component.

### `<kyn-global-filter>`
- **Import (design-system repo):** `import '../../components/reusable/globalFilter/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Slots:** unnamed, actions, tags
  - `unnamed`: Left slot, intended for search input and modal.
  - `actions`: Right slot, intended for action buttons and overflow menu.
  - `tags`: Slot below the filter bar, for tag group.
- **Description:** DEPRECATED. See [Patterns/Search & Action Bar](/docs/patterns-search-action-bar--docs).

### `<kyn-header>`
- **Import (design-system repo):** `import '../../components/global/header/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** rootUrl, appTitle
- **Slots:** unnamed, logo, left, center
  - `unnamed`: The default slot for all empty space right of the logo/title.
  - `logo`: Slot for the logo, will overwrite the default logo.
  - `left`: Slot left of the logo, intended for the header nav.
  - `center`: Slot between logo/title and right flyouts.
- **Events:** on-menu-toggle, on-root-link-click
- **Description:** The global Header component.

### `<kyn-header-categories>`
- **Import (design-system repo):** `import '../../components/global/header/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** activeMegaTabId, activeMegaCategoryId, maxRootLinks, limit-root-links, layout, maxColumns, fixed-column-widths, show-category-icons, hide-category-dividers, textStrings, detailLinksPerColumn
- **Slots:** unnamed
  - `unnamed`: Slot for header category elements. Controlled via `activeMegaTabId` / `activeMegaCategoryId` but encapsulates all categorical/mega-nav view behavior (root/detail, "More", "Back"). Emits `on-nav-change` so parents can mirror state for tabs, routing, etc. Modes: - JSON mode - Provide `tabsConfig` and categories/links are rendered from config. - Each link may specify `href`, `target`, and `rel`. - Optional `linkRenderer` hook can be supplied to fully control the slotted content inside each `<kyn-header-link>`. - Slotted/manual mode - Omit `tabsConfig` and slot `<kyn-header-category>` / `<kyn-header-link>` elements directly in the light DOM. - Slotted `<kyn-header-link>` `href`, `target`, and `rel` attributes are preserved. - Root view will: - limit visible links per category at `maxRootLinks` - inject a "More" link when there are additional links - "More" switches to a detail view for that category, and the Back button returns to the root view.
- **CSS custom properties:**
  - `--kyn-header-category-column-width`: Width of each column. Applies to 1 and 2 column layouts. Also used for 3+ when `fixed-column-widths` is enabled.
  - `--kyn-header-category-column-gap`: Horizontal gap between columns.
- **Events:** on-column-count-change, on-nav-change
- **Description:** Header categories wrapper for mega menu.

### `<kyn-header-category>`
- **Import (design-system repo):** `import '../../components/global/header/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** heading, leftPadding, showDivider
- **Slots:** unnamed, icon, more
  - `unnamed`: Slot for links.
  - `icon`: Slot for icon.
  - `more`: Slot for "More" link (indented with category links).
- **Events:** on-more-click
- **Description:** Header link category

### `<kyn-header-divider>`
- **Import (design-system repo):** `import '../../components/global/header/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Description:** Header divider

### `<kyn-header-flyout>`
- **Import (design-system repo):** `import '../../components/global/header/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** open, anchorLeft, hideArrow, label, hideMenuLabel, hideButtonLabel, assistive-text, href, backText, noPadding
- **Slots:** unnamed, button
  - `unnamed`: Slot for flyout menu content.
  - `button`: Slot for button/toggle content.
- **Description:** Component for header flyout items.

### `<kyn-header-flyouts>`
- **Import (design-system repo):** `import '../../components/global/header/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** open
- **Slots:** unnamed
  - `unnamed`: Slot for header-flyout components.
- **Description:** Container for header-flyout components.

### `<kyn-header-link>`
- **Import (design-system repo):** `import '../../components/global/header/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** href, target, rel, isActive, divider, searchLabel, searchThreshold, linksPerColumn, hideSearch, backText, leftPadding, truncate
- **Slots:** unnamed, links, icon
  - `unnamed`: Slot for link text/content.
  - `links`: Slot for sublinks (up to two levels).
  - `icon`: Slot for icon.
- **Events:** on-click
- **Description:** Component for navigation links within the Header.

### `<kyn-header-nav>`
- **Import (design-system repo):** `import '../../components/global/header/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** auto-open-flyout, truncate-links
- **Slots:** unnamed
  - `unnamed`: This element has a slot.
- **CSS custom properties:**
  - `--kyn-global-switcher-max-height`: Max height for global-switcher flyout panels, including categorical nav wrappers.
- **Events:** on-nav-toggle
- **Description:** Container for header navigation links.

### `<kyn-header-notification-panel>`
- **Import (design-system repo):** `import '../../components/global/header/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** panelTitle, panelFooterBtnText, hidePanelFooter
- **Slots:** menu-slot, unnamed
  - `menu-slot`: Slot for panel menu
  - `unnamed`: Slot for notification content.
- **Events:** on-footer-btn-click
- **Description:** Component for notification panel within the Header.

### `<kyn-header-panel-link>`
- **Import (design-system repo):** `import '../../components/global/header/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** href, target, rel
- **Slots:** unnamed
  - `unnamed`: Slot for link text/content.
- **Events:** on-click
- **Description:** Header fly-out panel link.

### `<kyn-header-tr>`
- **Import (design-system repo):** `import '../../components/reusable/table/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** expandableColumnWidth, multiSelectColumnWidth, rowId, selected, checkboxSelection, dense, unread, locked, expandable, expanded, disabled, preventHighlight, dimmed, textStrings
- **Slots:** unnamed, expand-placeholder
  - `unnamed`: The content slot for adding table cells (`kyn-td` or other relevant cells).
  - `expand-placeholder`: Slot for expand placeholder content (like `kyn-td` or other relevant cells).
- **Events:** on-header-checkbox-toggle, on-row-select, table-row-expando-beingtoggled, table-row-expando-toggled
- **Description:** `kyn-header-tr` Web Component.

The `<kyn-header-tr>` component is designed to function as the
header row within a table that's part of Shidoka's design system.

### `<kyn-header-user-profile>`
- **Import (design-system repo):** `import '../../components/global/header/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** name, subtitle, email, profileLink, profileLinkText
- **Slots:** unnamed
  - `unnamed`: Slot for the profile picture img.
- **Events:** on-profile-link-click
- **Description:** Header user profile.

### `<kyn-icon-selector>`
- **Import (design-system repo):** `import '../../components/reusable/iconSelector/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** checked, value, checkedLabel, uncheckedLabel, disabled, onlyVisibleOnHover, persistWhenChecked, animateSelection
- **Slots:** icon-unchecked, icon-checked
  - `icon-unchecked`: Optional icon for unchecked state. Defaults to star outline.
  - `icon-checked`: Optional icon for checked state. Defaults to filled star.
- **Events:** on-change
- **Description:** Icon Selector - A checkbox-style toggle using icons for visual states.
Primarily designed for favorite/unfavorite functionality.

### `<kyn-icon-selector-group>`
- **Import (design-system repo):** `import '../../components/reusable/iconSelector/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** value, disabled, direction, onlyVisibleOnHover, persistWhenChecked, animateSelection
- **Slots:** unnamed
  - `unnamed`: Slot for icon-selector elements.
- **Events:** on-change
- **Description:** Icon Selector Group - A container for managing multiple icon selectors with multi-select functionality.

### `<kyn-info-card-skeleton>`
- **Import (design-system repo):** `import '../../components/reusable/card/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** lines, thumbnailVisible
- **Description:** `kyn-info-card-skeleton` Web Component.
A skeleton loading state for the informational card component that mirrors its structure.

### `<kyn-inline-code-view>`
- **Import (design-system repo):** `import '../../components/reusable/inlineCodeView/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** darkTheme, snippetFontSize
- **Slots:** unnamed
  - `unnamed`: inline code snippet slot.
- **Description:** `<kyn-inline-code-view>` component to display code snippets inline within HTML content.

### `<kyn-inline-confirm>`
- **Import (design-system repo):** `import '../../components/reusable/inlineConfirm/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** destructive, anchorText, confirmText, cancelText, openRight
- **Slots:** unnamed, confirmIcon
  - `unnamed`: Slot for anchor button icon.
  - `confirmIcon`: Slot for confirm icon button, will be a check icon by default if none provided.
- **Events:** on-confirm
- **Description:** InlineConfirm component.

### `<kyn-link>`
- **Import (design-system repo):** `import '../../components/reusable/link/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** href, target, kind, rel, disabled, standalone, iconLeft, linkFontWeight, animationInactive
- **Slots:** unnamed, icon
  - `unnamed`: Slot for link text.
  - `icon`: Slot for an icon.
- **Events:** on-click
- **Description:** Component for navigation links.

### `<kyn-loader>`
- **Import (design-system repo):** `import '../../components/reusable/loaders/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** stopped, overlay
- **Events:** on-start, on-stop
- **Description:** Loader.

### `<kyn-loader-inline>`
- **Import (design-system repo):** `import '../../components/reusable/loaders/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** status
- **Slots:** unnamed
  - `unnamed`: Slot for text/description.
- **Events:** on-start, on-stop
- **Description:** Inline Loader.

### `<kyn-local-nav>`
- **Import (design-system repo):** `import '../../components/global/localNav/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** pinned, manual-toggle-variant, collapsed-by-default, textStrings
- **Slots:** unnamed, search
  - `unnamed`: The default slot, for local nav links.
  - `search`: Slot for a search input
- **Events:** on-toggle
- **Description:** The global Side Navigation component.

### `<kyn-local-nav-divider>`
- **Import (design-system repo):** `import '../../components/global/localNav/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** heading
- **Description:** Local Nav divider

### `<kyn-local-nav-link>`
- **Import (design-system repo):** `import '../../components/global/localNav/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** href, expanded, active, disabled, backText, leftPadding
- **Slots:** unnamed, icon, links
  - `unnamed`: The default slot, for the link text.
  - `icon`: Slot for an icon. Use 16px size. Required for level 1.
  - `links`: Slot for the next level of links, supports three levels.
- **Events:** on-link-active, on-click
- **Description:** Link component for use in the global Side Navigation component.

### `<kyn-meta-data>`
- **Import (design-system repo):** `import '../../components/reusable/metaData/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** horizontal, noBackground, scrollableContent
- **Slots:** icon, label, unnamed
  - `icon`: Slot for icon.
  - `label`: Slot for label.
  - `unnamed`: Slot for body/other content.
- **Description:** MetaData component.

### `<kyn-modal>`
- **Import (design-system repo):** `import '../../components/reusable/modal/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** open, size, titleText, labelText, okText, cancelText, destructive, okDisabled, secondaryDisabled, hideFooter, secondaryButtonText, showSecondaryButton, hideCancelButton, closeText, gradientBackground, aiConnected, disableScroll
- **Slots:** unnamed, anchor, header-inline, footer
  - `unnamed`: Slot for modal body content.
  - `anchor`: Slot for the anchor button content.
  - `header-inline`: Slot for an inline header action (badge/button) rendered next to the title/label when using the default header.
  - `footer`: Slot for the footer content which replaces the ok, cancel, and second ary buttons.
- **Events:** on-close, on-open
- **Description:** Modal.

### `<kyn-multi-input-field>`
- **Import (design-system repo):** `import '../../components/reusable/multiInputField/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** name, invalidText, label, caption, inputType, required, placeholder, disabled, readonly, hideLabel, autoSuggestionDisabled, validationsDisabled, customSuggestions, maxItems, textStrings, hideIcon, pattern, itemStatusMap
- **Slots:** unnamed
  - `unnamed`: Slot for tag icon.
- **Events:** on-input, on-change
- **Description:** Multi-input field component.

### `<kyn-notification>`
- **Import (design-system repo):** `import '../../components/reusable/notification/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** notificationTitle, notificationSubtitle, timeStamp, href, target, tagStatus, type, textStrings, closeBtnDescription, assistiveNotificationTypeText, notificationRole, statusLabel, unRead, hideCloseButton, timeout
- **Slots:** unnamed, actions, icon
  - `unnamed`: Slot for notification message body.
  - `actions`: Slot for menu.
  - `icon`: Slot for an icon.
- **Events:** on-notification-click, on-close
- **Description:** Notification component.

### `<kyn-notification-container>`
- **Import (design-system repo):** `import '../../components/reusable/notification/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** bottom
- **Slots:** unnamed
  - `unnamed`: Slot for <kyn-notification type="toast"> component.
- **Description:** Notification container component for Toast notification.
Usage is limited for <kyn-notification type="toast">..</kyn-notification>

### `<kyn-number-input>`
- **Import (design-system repo):** `import '../../components/reusable/numberInput/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** name, invalidText, label, size, placeholder, required, disabled, readonly, caption, max, min, step, hideLabel, inline, inlineBorder, textStrings
- **Slots:** tooltip
  - `tooltip`: Slot for tooltip.
- **CSS custom properties:**
  - `--kyn-number-input-inner-max-width`: Maximum width of the number input inner container.
  - `--kyn-number-input-inner-min-width`: Minimum width of the number input inner container.
- **Events:** on-input
- **Description:** Number input.

### `<kyn-overflow-menu>`
- **Import (design-system repo):** `import '../../components/reusable/overflowMenu/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** open, kind, anchorRight, backButtonText, verticalDots, fixed, assistiveText
- **Slots:** unnamed
  - `unnamed`: Slot for overflow menu items.
- **Events:** kind-changed, on-toggle
- **Description:** Overflow Menu.

### `<kyn-overflow-menu-item>`
- **Import (design-system repo):** `import '../../components/reusable/overflowMenu/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** href, destructive, disabled, description, kind
- **Slots:** unnamed, submenu
  - `unnamed`: Slot for menu item text.
  - `submenu`: Provide a nested submenu's markup here (light DOM). Presence auto-detects nesting.
- **Events:** open-submenu, on-click
- **Description:** Overflow Menu Item.

### `<kyn-page-title>`
- **Import (design-system repo):** `import '../../components/reusable/pagetitle/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** headLine, pageTitle, subTitle, type, aiConnected, contextual, open
- **Slots:** icon, unnamed
  - `icon`: Slot for icon. Use size 56 * 56 as per UX guidelines.
  - `unnamed`: Slot for `kyn-pagetitle-option` elements when using the contextual variant.
- **Events:** on-change
- **Description:** Page Title

If the contextual variant is used to trigger navigation, consider using anchor elements instead, as buttons do not convey destination information to assistive technology users.

### `<kyn-pagetitle-option>`
- **Import (design-system repo):** `import '../../components/reusable/pagetitle/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** value, selected
- **Slots:** unnamed
  - `unnamed`: Slot for option text.
- **Description:** Page title contextual dropdown option.

### `<kyn-pagination>`
- **Import (design-system repo):** `import '../../components/reusable/pagination/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** count, pageNumber, pageSize, pageSizeOptions, pageSizeDropdownLabel, pageNumberLabel, hideItemsRange, hidePageSizeDropdown, hideNavigationButtons, openDirection, textStrings
- **Events:** on-page-size-change, on-page-number-change
- **Description:** `kyn-pagination` Web Component.

A component that provides pagination functionality, enabling the user to
navigate through large datasets by splitting them into discrete chunks.
Integrates with other utility components like items range display, page size dropdown,
and navigation buttons.

### `<kyn-pagination-items-range>`
- **Import (design-system repo):** `import '../../components/reusable/pagination/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** count, pageNumber, pageSize
- **Description:** `kyn-pagination-items-range` Web Component.

This component is responsible for displaying the range of items being displayed
in the context of pagination. It shows which items (by number) are currently visible
and the total number of items.

### `<kyn-pagination-navigation-buttons>`
- **Import (design-system repo):** `import '../../components/reusable/pagination/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** pageNumber, numberOfPages, openDirection
- **Events:** on-page-number-change
- **Description:** `kyn-pagination-navigation-buttons` Web Component.

This component provides navigational controls for pagination.
It includes back and next buttons, along with displaying the current page and total pages.

### `<kyn-pagination-page-size-dropdown>`
- **Import (design-system repo):** `import '../../components/reusable/pagination/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** pageSize, openDirection
- **Events:** on-page-size-change
- **Description:** `kyn-pagination-page-size-dropdown` Web Component.

This component provides a dropdown to select the page size for pagination.
It emits events when the selected page size changes.

### `<kyn-pagination-skeleton>`
- **Import (design-system repo):** `import '../../components/reusable/pagination/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** hideItemsRange, hidePageSizeDropdown, hideNavigationButtons
- **Description:** `kyn-pagination-skeleton` Web Component.

### `<kyn-popover>`
- **Import (design-system repo):** `import '../../components/reusable/popover/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** direction, positionType, launchBehavior, linkHref, footerLinkOnly, linkTarget, size, offsetDistance, shiftPadding, triggerType, arrowPosition, animationDuration, top, left, bottom, right, destructive, zIndex, responsivePosition, titleText, labelText, okText, cancelText, closeText, popoverAriaLabel, secondaryButtonText, showSecondaryButton, tertiaryButtonText, showTertiaryButton, footerLinkText, footerLinkHref, footerLinkTarget, hideFooter
- **Slots:** unnamed, anchor, footerLink
  - `unnamed`: The main popover slotted body content
  - `anchor`: The trigger element (icon, button, link, etc.)
  - `footerLink`: Optional link to be displayed in the footer
- **Events:** on-close, on-open
- **Description:** Popover component.

Two positioning modes are available:
- anchor: positioned relative to an anchor slot element
- floating: manually positioned via top/left/bottom/right properties

For anchor mode, the popover will be positioned relative to the anchor element
based on the direction property. The position can be fixed or absolute.

For floating (manual) mode, set triggerType="none" and use top/left/bottom/right
properties to position the popover.

### `<kyn-progress-bar>`
- **Import (design-system repo):** `import '../../components/reusable/progressBar/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** showInlineLoadStatus, showActiveHelperText, progressBarId, status, value, max, label, helperText, unit, hideLabel, hidePercentageValue
- **Slots:** unnamed
  - `unnamed`: Slot for tooltip text content.
- **Description:** Progress bar component.

### `<kyn-qb-group>`
- **Import (design-system repo):** `import '../../components/reusable/queryBuilder/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** group, fields, combinators, path, depth, maxDepth, isRoot, showCloneButton, showLockButton, disableDragAndDrop, disabled, siblingCount, textStrings, size, searchThreshold
- **Events:** on-group-remove, on-group-clone, on-group-lock, on-group-change, on-item-move
- **Description:** Query Builder Group component.
Represents a group of rules with a combinator (AND/OR).

### `<kyn-qb-rule>`
- **Import (design-system repo):** `import '../../components/reusable/queryBuilder/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** rule, fields, isLast, showCloneButton, showLockButton, disableDragAndDrop, disabled, index, parentPath, siblingCount, textStrings, size, searchThreshold
- **Events:** on-rule-change, on-rule-add, on-rule-remove, on-rule-clone, on-rule-lock
- **Description:** Query Builder Rule component.
Represents a single condition in the query (field + operator + value).

### `<kyn-query-builder>`
- **Import (design-system repo):** `import '../../components/reusable/queryBuilder/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** query, fields, showCloneButtons, showLockButtons, maxDepth, disableDragAndDrop, disabled, size, searchThreshold, textStrings
- **Slots:** header
  - `header`: Slot for custom header content
- **Events:** on-query-change
- **Description:** Query Builder component.
A visual query builder for constructing complex filter conditions.

### `<kyn-radio-button>`
- **Import (design-system repo):** `import '../../components/reusable/radioButton/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** value, disabled, readonly
- **Slots:** unnamed
  - `unnamed`: Slot for label text.
- **Events:** on-radio-change
- **Description:** Radio button.

### `<kyn-radio-button-group>`
- **Import (design-system repo):** `import '../../components/reusable/radioButton/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** value, name, invalidText, label, required, disabled, readonly, horizontal, hideLabel, textStrings
- **Slots:** unnamed, description, tooltip
  - `unnamed`: Slot for individual radio buttons.
  - `description`: Slot for description text.
  - `tooltip`: Slot for tooltip.
- **Events:** on-radio-group-change
- **Description:** Radio button group container.

### `<kyn-search>`
- **Import (design-system repo):** `import '../../components/reusable/search/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** name, label, expandable, value, size, disabled, suggestions, searchHistory, expandableSearchBtnDescription, assistiveTextStrings, enableSearchHistory
- **Events:** on-input
- **Description:** Search

### `<kyn-side-drawer>`
- **Import (design-system repo):** `import '../../components/reusable/sideDrawer/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** open, size, titleText, labelText, submitBtnText, cancelBtnText, closeBtnDescription, submitBtnDisabled, gradientBackground, hideFooter, destructive, secondaryButtonText, showSecondaryButton, hideCancelButton, aiConnected, noBackdrop, resizable
- **Slots:** unnamed, anchor
  - `unnamed`: Slot for drawer body content.
  - `anchor`: Slot for the anchor button content.
- **Events:** on-resize, on-close, on-open
- **Description:** Side Drawer.

### `<kyn-skeleton>`
- **Import (design-system repo):** `import '../../components/reusable/loaders/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** shape, size, width, height, lines, inline, aiConnected

### `<kyn-slider-input>`
- **Import (design-system repo):** `import '../../components/reusable/sliderInput/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** value, name, invalidText, label, disabled, caption, max, min, step, hideLabel, enableTickMarker, enableScaleMarker, editableInput, textStrings, customLabels, enableTooltip, enableButtonControls, fullWidth
- **Slots:** tooltip, leftBtnIcon, rightBtnIcon
  - `tooltip`: Slot for tooltip.
  - `leftBtnIcon`: Slot for left button icon.
  - `rightBtnIcon`: Slot for right button icon.
- **Events:** on-input
- **Description:** Slider Input.

### `<kyn-spinner>`
- **Import (design-system repo):** `import '../../components/reusable/loaders/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** variant, status, size, primaryColor, secondaryColor, trackColor
- **Events:** on-start, on-stop
- **Description:** Spinner component

- tag: <kyn-spinner>
- variant: 'ai' (CSS/SVG spinner) or 'inline' (lottie indeterminate animation)
- status: for inline variant -> 'active' | 'inactive' | 'success' | 'error'
- size: for ai variant -> 'default' | 'mini'

Colors can be set via properties: primaryColor, secondaryColor, trackColor
which set CSS variables on the host (--loader-primary, --loader-secondary, --loader-track).

### `<kyn-split-btn>`
- **Import (design-system repo):** `import '../../components/reusable/splitButton/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** description, name, kind, size, iconPosition, label, disabled, destructive, menuMinWidth, open
- **Slots:** unnamed, icon
  - `unnamed`: Slot for split button options.
  - `icon`: Slot for an icon (optional).
- **Events:** on-click
- **Description:** Split Button

### `<kyn-split-view>`
- **Import (design-system repo):** `import '../../components/reusable/splitView/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** startPaneSize, endPaneSize, compactBreakpoint, minPaneSize, minCenterSize, startPaneLabel, primaryPaneLabel, endPaneLabel, startDividerInverted, endDividerInverted, hideBorder, textStrings
- **Slots:** start, unnamed, end
  - `start`: Content for the start (left) pane.
  - `unnamed`: Content for the primary (center) pane.
  - `end`: Content for the end (right) pane. Presence of content enables three-pane mode.
- **Events:** on-resize
- **Description:** Split View — resizable multi-pane layout.

Slot content into `start`, the default (primary), and optionally `end` panes.
Three-pane mode activates automatically when the `end` slot has content.
At narrow container widths the layout collapses to a tabbed compact view
using `kyn-tabs`.

### `<kyn-splitbutton-option>`
- **Import (design-system repo):** `import '../../components/reusable/splitButton/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** value, selected, disabled
- **Slots:** unnamed
  - `unnamed`: Slot for option text.
- **Events:** on-action-click
- **Description:** Split button option.

### `<kyn-status-btn>`
- **Import (design-system repo):** `import '../../components/reusable/statusButton/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** label, disabled, selected, noTruncation, kind
- **Slots:** unnamed
  - `unnamed`: Slot for icon.
- **Events:** on-click
- **Description:** Status Button.

### `<kyn-stepper>`
- **Import (design-system repo):** `import '../../components/reusable/stepper/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** stepperType, vertical, stepperSize, currentIndex
- **Slots:** unnamed
  - `unnamed`: Slot for step items.
- **Events:** on-click
- **Description:** Stepper

### `<kyn-stepper-item>`
- **Import (design-system repo):** `import '../../components/reusable/stepper/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** vertical, stepSize, stepName, stepTitle, stepLink, stepState, disabled, showCounter
- **Slots:** tooltip, child, unnamed
  - `tooltip`: Slot for tooltip.
  - `child`: Children slot. Used for nested children in vertical stepper. Visible only when step state is active. Do not use inside stepperType `'status'`.
  - `unnamed`: Optional slot for content in vertical stepper. Visible only when step state is active.
- **Events:** on-step-click
- **Description:** Stepper Item.

### `<kyn-stepper-item-child>`
- **Import (design-system repo):** `import '../../components/reusable/stepper/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** childTitle, childLink, childSubTitle, childState
- **Slots:** unnamed
  - `unnamed`: Slot for other elements.
- **Events:** on-child-click
- **Description:** Stepper Item child.

### `<kyn-tab>`
- **Import (design-system repo):** `import '../../components/reusable/tabs/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** id, selected, disabled, vertical, data-aiconnected, role, tabIndex, 'aria-selected', 'aria-controls', 'aria-disabled'

### `<kyn-tab-panel>`
- **Import (design-system repo):** `import '../../components/reusable/tabs/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** tabId, visible, noPadding
- **Slots:** unnamed
  - `unnamed`: Slot for tab content.
- **Description:** Tabs.

### `<kyn-table>`
- **Import (design-system repo):** `import '../../components/reusable/table/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** checkboxSelection, striped, stickyHeader, dense, fixedLayout
- **Events:** on-row-selection-change, on-all-rows-selection-change
- **Description:** `kyn-table` Web Component.
This component provides a table with sorting, pagination, and selection capabilities.
It is designed to be used with the `kyn-table-toolbar` and `kyn-table-container` components.

### `<kyn-table-container>`
- **Import (design-system repo):** `import '../../components/reusable/table/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** tabIndex
- **Slots:** unnamed
  - `unnamed`: The content slot for adding table and related elements.
- **Description:** `kyn-table-container` Web Component.

Provides a container for Shidoka's design system tables. It's designed to encapsulate
and apply styles uniformly across the table elements.

### `<kyn-table-footer>`
- **Import (design-system repo):** `import '../../components/reusable/table/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Slots:** unnamed
  - `unnamed`: Default slot.
- **Description:** Table Footer

Intended to contain Legend and Pagination.

### `<kyn-table-legend>`
- **Import (design-system repo):** `import '../../components/reusable/table/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Slots:** unnamed
  - `unnamed`: Default slot for Legend Items.
- **Description:** Table Legend

### `<kyn-table-legend-item>`
- **Import (design-system repo):** `import '../../components/reusable/table/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Slots:** unnamed
  - `unnamed`: Default slot for icon and text.
- **Description:** Table Legend Item

### `<kyn-table-skeleton>`
- **Import (design-system repo):** `import '../../components/reusable/table/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** rows, showPagination, dense, striped, hideTableTitles, fixedLayout, tableTitle, tableSubtitle, showGlobalFilter
- **Description:** `kyn-table-skeleton` Web Component.
A skeleton loading state for the table component that mirrors its structure.

### `<kyn-table-toolbar>`
- **Import (design-system repo):** `import '../../components/reusable/table/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** tableTitle, tableSubtitle
- **Slots:** unnamed
  - `unnamed`: The primary content slot for controls, buttons, or other toolbar content.
- **Description:** `kyn-table-toolbar` Web Component.

This component provides a toolbar for tables, primarily featuring a title and additional content.
The title is rendered prominently, while the slot can be used for controls, buttons, or other interactive elements.

### `<kyn-tabs>`
- **Import (design-system repo):** `import '../../components/reusable/tabs/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** tabSize, vertical, aiConnected, disableAutoFocusUpdate, scrollablePanels
- **Slots:** unnamed, tabs
  - `unnamed`: Slot for kyn-tab-panel components.
  - `tabs`: Slot for kyn-tab components.
- **Events:** on-change
- **Description:** Tabs.

### `<kyn-tag>`
- **Import (design-system repo):** `import '../../components/reusable/tag/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** label, tagSize, disabled, filter, persistentTag, noTruncation, clickable, tagColor, clearTagText
- **Slots:** unnamed
  - `unnamed`: Slot for icon.
- **Events:** on-close, on-click
- **Description:** Tag.

### `<kyn-tag-group>`
- **Import (design-system repo):** `import '../../components/reusable/tag/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** textStrings, limitTags, filter, tagSize, limitCount
- **Slots:** unnamed
  - `unnamed`: Slot for individual tags and tagsskeleton.
- **Description:** Tag & Tag Group

### `<kyn-tag-skeleton>`
- **Import (design-system repo):** `import '../../components/reusable/tag/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** tagSize

### `<kyn-tbody>`
- **Import (design-system repo):** `import '../../components/reusable/table/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** striped
- **Slots:** unnamed
  - `unnamed`: The content slot for adding rows (`<kyn-tr>`) within the table body.
- **Events:** on-rows-change
- **Description:** `kyn-tbody` Web Component.

Represents the body section of Shidoka's design system tables. Designed to provide
a consistent look and feel, and can offer striped rows for enhanced readability.

### `<kyn-td>`
- **Import (design-system repo):** `import '../../components/reusable/table/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** dense, align, width, maxWidth, minWidth, disabled, dimmed
- **Slots:** unnamed
  - `unnamed`: The content slot for adding table data inside the cell.
- **Description:** `kyn-td` Web Component.

Represents a table cell (data cell) within Shidoka's design system tables.
Allows customization of alignment and can reflect the sort direction when
used within sortable columns.

### `<kyn-text-area>`
- **Import (design-system repo):** `import '../../components/reusable/textArea/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** value, name, invalidText, label, caption, placeholder, required, disabled, readonly, maxLength, minLength, notResizeable, hideLabel, rows, aiConnected, maxRowsVisible, textStrings, autoComplete
- **Slots:** tooltip
  - `tooltip`: Slot for tooltip.
- **Events:** on-input
- **Description:** Text area.

### `<kyn-text-input>`
- **Import (design-system repo):** `import '../../components/reusable/textInput/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** value, name, invalidText, label, type, size, caption, placeholder, required, disabled, readonly, pattern, maxLength, minLength, iconRight, hideLabel, textStrings, autoComplete
- **Slots:** icon, tooltip
  - `icon`: Slot for contextual icon.
  - `tooltip`: Slot for tooltip.
- **Events:** on-input
- **Description:** Text input.

### `<kyn-tfoot>`
- **Import (design-system repo):** `import '../../components/reusable/table/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Slots:** unnamed
  - `unnamed`: The content slot for adding table foot rows.
- **Description:** `kyn-tfoot` Web Component.

Represents a custom table foot (`<tfoot>`) for Shidoka's design system tables.
Designed to contain and style table footer rows (`<tr>`) and footer cells (`<td>`).

### `<kyn-th>`
- **Import (design-system repo):** `import '../../components/reusable/table/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** dense, align, sortable, sortDirection, headerLabel, sortKey, visiblyHidden, width, maxWidth, minWidth, resizable, assistiveResizeText, resizeMinWidth, resizeMaxWidth
- **Slots:** unnamed, column-filter
  - `unnamed`: The content slot for adding header text or content.
  - `column-filter`: slot for column filter.
- **Events:** on-sort-changed, on-column-resize
- **Description:** `kyn-th` Web Component.

Represents a custom table header cell (`<th>`) for Shidoka's design system tables.
Provides sorting functionality when enabled and allows alignment customization.

### `<kyn-th-group>`
- **Import (design-system repo):** `import '../../components/reusable/table/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** label, align
- **Slots:** unnamed
  - `unnamed`: Slot for child `kyn-th` elements that belong to this group.
- **Description:** `kyn-th-group` Web Component.
Represents a stacked/grouped header that spans multiple columns.
Uses `display: contents` so it is invisible to the CSS table layout,
allowing its child `kyn-th` elements to participate directly as table-cells.
The group label is passed to children, which render it above their content.

### `<kyn-thead>`
- **Import (design-system repo):** `import '../../components/reusable/table/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** stickyHeader
- **Slots:** unnamed
  - `unnamed`: The content slot for adding table header rows (`<kyn-header-tr>`).
- **Description:** `kyn-thead` Web Component.

Represents a custom table head (`<thead>`) for Shidoka's design system tables.
Designed to contain and style table header rows (`<tr>`) and header cells (`<th>`).

### `<kyn-time-picker>`
- **Import (design-system repo):** `import '../../components/reusable/timepicker/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** name, value, invalidText, label, hideLabel, locale, defaultHour, defaultMinute, defaultSeconds, allowManualInput, defaultErrorMessage, warnText, caption, required, size, timepickerDisabled, readonly, twentyFourHourFormat, enableSeconds, minTime, maxTime, errorAriaLabel, errorTitle, warningAriaLabel, warningTitle, staticPosition, textStrings
- **Slots:** tooltip
  - `tooltip`: Slot for tooltip.
- **Events:** on-change
- **Description:** Timepicker: uses Flatpickr library,time picker implementation  -- `https://flatpickr.js.org/examples/#time-picker`

### `<kyn-toggle-button>`
- **Import (design-system repo):** `import '../../components/reusable/toggleButton/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** value, name, label, checked, checkedText, uncheckedText, small, disabled, readonly, reverse, hideLabel
- **Slots:** tooltip
  - `tooltip`: Slot for tooltip.
- **Events:** on-change
- **Description:** Toggle Button.

### `<kyn-tooltip>`
- **Import (design-system repo):** `import '../../components/reusable/tooltip/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** assistiveText, non-interactive-anchor, compact
- **Slots:** unnamed, anchor
  - `unnamed`: Slot for tooltip content.
  - `anchor`: Slot for custom anchor button content.
- **Events:** on-tooltip-toggle
- **Description:** Tooltip.

### `<kyn-tr>`
- **Import (design-system repo):** `import '../../components/reusable/table/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** rowId, selected, checkboxSelection, dense, unread, locked, expandable, expanded, disabled, preventHighlight, dimmed, textStrings
- **Slots:** unnamed, expand-placeholder
  - `unnamed`: The content slot for adding table cells (`kyn-td` or other relevant cells).
  - `expand-placeholder`: Slot for expand placeholder content (like `kyn-td` or other relevant cells).
- **Events:** on-row-select, table-row-expando-beingtoggled, table-row-expando-toggled
- **Description:** `kyn-tr` Web Component.

Represents a table row (`<tr>`) equivalent for custom tables created with Shidoka's design system.
It primarily acts as a container for individual table cells and behaves similarly to a native `<tr>` element.

### `<kyn-ui-shell>`
- **Import (design-system repo):** `import '../../components/global/uiShell/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Slots:** unnamed
  - `unnamed`: Slot for global elements.
- **Description:** Container to help with positioning and padding of the global elements such as: adds padding for the fixed Header and Local Nav, adds main content gutters, and makes Footer sticky. This takes the onus off of the consuming app to configure these values.

### `<kyn-vital-card-skeleton>`
- **Import (design-system repo):** `import '../../components/reusable/card/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** lines
- **Description:** `kyn-vital-card-skeleton` Web Component.
A skeleton loading state for the vital card component that mirrors its structure.

### `<kyn-widget>`
- **Import (design-system repo):** `import '../../components/reusable/widget/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** widgetTitle, subTitle, dragActive, disabled, selectable, selected, compact, removeHeader, showStatusBadge, statusBadgeLabel, widgetStatus
- **Slots:** unnamed, actions, badge, tooltip, draghandle, subtitle, footer
  - `unnamed`: Slot for widget content.
  - `actions`: Slot for action buttons.
  - `badge`: Slot for badge status.
  - `tooltip`: Slot for tooltip in header.
  - `draghandle`: Slot for drag handle.
  - `subtitle`: Slot for subtitle content.
  - `footer`: Slot for footer content.
- **Events:** on-select
- **Description:** Widget.

### `<kyn-widget-drag-handle>`
- **Import (design-system repo):** `import '../../components/reusable/widget/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** slot
- **Description:** Widget drag handle.

### `<kyn-widget-gridstack>`
- **Import (design-system repo):** `import '../../components/reusable/widget/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** layout, gridstackConfig, compact, wholeWidgetDraggable
- **Slots:** unnamed
  - `unnamed`: Slot for .grid-stack container element.
- **Events:** on-grid-init, on-grid-save
- **Description:** GridStack wrapper that includes Shidoka default config and styles.

### `<kyn-workspace-switcher>`
- **Import (design-system repo):** `import '../../components/global/workspaceSwitcher/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** textStrings, hideCurrentTitle, hideWorkspacesTitle, hide-left-divider
- **Slots:** left, left-list, mobile-trigger-icon, account-status-icon, right, right-list
  - `left`: Legacy non-list content for the left panel when `accountMeta` is not used. Prefer `accountMeta`; this slot is maintained for backward compatibility.
  - `left-list`: List items for the left panel (rendered inside role="list").
  - `mobile-trigger-icon`: Optional icon override for the mobile flyout trigger. Provide an inline SVG or wrapper that contains one.
  - `account-status-icon`: Optional icon override for the current account status indicator used by the built-in account meta block and mobile summary. Provide an inline SVG or wrapper that contains one.
  - `right`: Non-list content for the right panel (e.g. search).
  - `right-list`: List items for the right panel (rendered inside role="list").
- **CSS custom properties:**
  - `--kyn-workspace-switcher-max-height`: Maximum height of the switcher panel.
  - `--kyn-workspace-switcher-left-panel-width`: Width of the left panel in desktop two-panel layout.
- **Events:** on-account-meta-copy
- **Description:** Workspace Switcher shell component providing two-panel layout with mobile drill-down.
Component fits to 100% of the width and height of its container and surfaces two panels for content composition via slots.
Consumers compose workspace and account rows via named slots using
sub-components like `kyn-workspace-switcher-menu-item`.
The account meta block can also be provided via the `accountMeta` property,
which renders the preferred rigid built-in pattern.

### `<kyn-workspace-switcher-menu-item>`
- **Import (design-system repo):** `import '../../components/global/workspaceSwitcher/index';` (in consuming app use `import '@kyndryl-design-system/shidoka-applications';` once)
- **Attributes:** variant, value, name, name-title, count, selected, favorited, showLaunchIndicator, textStrings, showFavorite
- **Events:** on-click, on-favorite-change
- **Description:** Workspace Switcher Menu Item component.
Used for both workspace items (left panel) and account items (right panel).
Item rows support these trailing-action combinations:
- favorite only
- launch indicator only
- launch indicator plus favorite
The launch indicator is part of the primary row button while the favorite
control stays pinned to the far right as a separate action.

#!/usr/bin/env node
/**
 * Copy this file into a consuming app repo as scripts/install-shidoka-studio.mjs.
 *
 * It bootstraps the private @kyndryl-cto/shidoka-studio GitHub Packages install
 * before the package exists in node_modules, then runs the installed editor
 * configuration step.
 */
import { existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'fs';
import { tmpdir } from 'os';
import { join, resolve } from 'path';
import { spawnSync } from 'child_process';
import { pathToFileURL } from 'url';
import readline from 'readline/promises';
import { stdin as defaultInput, stdout as defaultOutput } from 'process';

export const PACKAGE_NAME = '@kyndryl-cto/shidoka-studio';
export const NPMRC_BEGIN = '# BEGIN SHIDOKA STUDIO NPM CONFIG';
export const NPMRC_END = '# END SHIDOKA STUDIO NPM CONFIG';
export const TOKEN_ENV_CANDIDATES = [
  'SHIDOKA_STUDIO_NPM_TOKEN',
  'GITHUB_PACKAGES_TOKEN',
  'NODE_AUTH_TOKEN',
  'NPM_TOKEN',
  'GITHUB_TOKEN',
];

const SUPPORTED_HOSTS = new Set(['cursor', 'vscode-copilot', 'codex', 'both']);
const DEFAULT_REGISTRY = 'https://registry.npmjs.org/';
const GITHUB_PACKAGES_REGISTRY = 'https://npm.pkg.github.com';
export const SHIDOKA_STUDIO_ASCII_ART = [
  ' ____  _     _     _       _             ____  _             _ _',
  '/ ___|| |__ (_) __| | ___ | | ____ _    / ___|| |_ _   _  __| (_) ___',
  "\\___ \\| '_ \\| |/ _` |/ _ \\| |/ / _` |   \\___ \\| __| | | |/ _` | |/ _ \\",
  ' ___) | | | | | (_| | (_) |   < (_| |    ___) | |_| |_| | (_| | | (_) |',
  '|____/|_| |_|_|\\__,_|\\___/|_|\\_\\__,_|   |____/ \\__|\\__,_|\\__,_|_|\\___/',
].join('\n');

export class BootstrapInstallError extends Error {
  constructor(message, exitCode = 1) {
    super(message);
    this.name = 'BootstrapInstallError';
    this.exitCode = exitCode;
  }
}

export function normalizeHost(host = 'cursor') {
  const value = String(host).trim().toLowerCase();
  if (value === 'vscode' || value === 'copilot') return 'vscode-copilot';
  if (value === 'openai-codex' || value === 'vscode-codex') return 'codex';
  if (value === 'all') return 'both';
  return value;
}

export function parseArgs(argv) {
  const args = {
    project: process.cwd(),
    host: 'cursor',
    version: 'latest',
    save: false,
    help: false,
  };

  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if ((arg === '--project' || arg === '-p') && argv[index + 1]) {
      args.project = resolve(argv[index + 1]);
      index += 1;
    } else if (arg === '--host' && argv[index + 1]) {
      args.host = normalizeHost(argv[index + 1]);
      index += 1;
    } else if (arg === '--version' && argv[index + 1]) {
      args.version = argv[index + 1];
      index += 1;
    } else if (arg === '--save-dev') {
      args.save = true;
    } else if (arg === '--no-save') {
      args.save = false;
    } else if (arg === '--help' || arg === '-h') {
      args.help = true;
    }
  }

  return args;
}

export function renderHelp() {
  return [
    'Install Shidoka Studio into this app repo.',
    '',
    'Usage:',
    '  node scripts/install-shidoka-studio.mjs [--host cursor|vscode-copilot|codex|both]',
    '',
    'Options:',
    '  --host <host>       Editor host to configure. Defaults to cursor.',
    '  --project <path>    App repo root. Defaults to the current directory.',
    '  --version <version> Studio package version. Defaults to latest.',
    '  --save-dev         Save Studio as a dev dependency.',
    '  --no-save          Install locally without changing package.json or package-lock.json.',
    '',
    'Auth:',
    `  Set ${TOKEN_ENV_CANDIDATES.join(', ')}, or paste a GitHub Packages token when prompted.`,
  ].join('\n');
}

export function buildProjectNpmrcBlock() {
  return [
    NPMRC_BEGIN,
    `@kyndryl-cto:registry=${GITHUB_PACKAGES_REGISTRY}`,
    '# Credentials intentionally live outside committed project config.',
    '# Local installs use a temporary npm config, user-level ~/.npmrc, or CI secrets.',
    NPMRC_END,
    '',
  ].join('\n');
}

export function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function upsertManagedBlock(current, block) {
  const pattern = new RegExp(
    `${escapeRegExp(NPMRC_BEGIN)}[\\s\\S]*?${escapeRegExp(NPMRC_END)}\\n?`,
    'm'
  );
  if (pattern.test(current)) return current.replace(pattern, block);
  const trimmed = current.trimEnd();
  return trimmed ? `${trimmed}\n\n${block}` : block;
}

export function writeProjectNpmrc(project, log = console.log) {
  const target = join(project, '.npmrc');
  const current = existsSync(target) ? readFileSync(target, 'utf8') : '';
  const next = upsertManagedBlock(current, buildProjectNpmrcBlock());
  if (current !== next) {
    writeFileSync(target, next, 'utf8');
    log(`Wrote safe project npm registry config: ${target}`);
  } else {
    log(`Project npm registry config already up to date: ${target}`);
  }
  return target;
}

export function findTokenEnv(env = process.env) {
  return TOKEN_ENV_CANDIDATES.find((name) => Boolean(env[name]));
}

export function createTempUserconfig(token) {
  if (!token) return null;
  const dir = mkdtempSync(join(tmpdir(), 'shidoka-studio-npm-'));
  const file = join(dir, '.npmrc');
  writeFileSync(
    file,
    [
      `registry=${DEFAULT_REGISTRY}`,
      `@kyndryl-cto:registry=${GITHUB_PACKAGES_REGISTRY}`,
      `//npm.pkg.github.com/:_authToken=${token}`,
      '',
    ].join('\n'),
    { mode: 0o600 }
  );
  return { dir, file };
}

export function commandForPlatform(command, platform = process.platform) {
  if (platform === 'win32' && command === 'npm') return 'npm.cmd';
  return command;
}

export function buildInstallArgs(packageSpec, save, userconfigFile = null) {
  const args = save
    ? ['install', '--save-dev', packageSpec]
    : ['install', '--no-save', '--package-lock=false', packageSpec];
  if (userconfigFile) args.push('--userconfig', userconfigFile);
  return args;
}

export function validateProject(project) {
  const pkgPath = join(project, 'package.json');
  if (!existsSync(pkgPath)) {
    throw new BootstrapInstallError(
      `No package.json found at ${pkgPath}.\nRun this from the consuming app repo root, or pass --project /path/to/app.`
    );
  }
}

export async function promptForToken({
  input = defaultInput,
  output = defaultOutput,
  createInterface = readline.createInterface,
} = {}) {
  output.write(
    [
      'Shidoka Studio installs from private GitHub Packages.',
      'Use a GitHub personal access token classic with read:packages and org SSO authorization.',
      'Paste a token now, or press Enter to use existing npm auth from ~/.npmrc.',
      '',
    ].join('\n')
  );

  const rl = createInterface({ input, output });
  try {
    const answer = await rl.question('GitHub Packages token: ');
    return answer.trim();
  } finally {
    rl.close();
  }
}

export function runChecked(label, command, args, options = {}) {
  const {
    cwd = process.cwd(),
    platform = process.platform,
    spawnSyncImpl = spawnSync,
    log = console.log,
    spawnEnv,
  } = options;
  const resolvedCommand = commandForPlatform(command, platform);
  log(`\n${label}`);
  const spawnOptions = {
    cwd,
    stdio: 'inherit',
    shell: false,
  };
  if (spawnEnv) spawnOptions.env = spawnEnv;

  const result = spawnSyncImpl(resolvedCommand, args, spawnOptions);

  if (result.error) {
    throw new BootstrapInstallError(`${label} failed: ${result.error.message}`);
  }
  if (result.status !== 0) {
    throw new BootstrapInstallError(`${label} failed.`, result.status ?? 1);
  }
}

export function printInstallFailureHelp(error = console.error) {
  error(
    [
      '',
      `Unable to install ${PACKAGE_NAME} from GitHub Packages.`,
      '',
      'Check these items, then rerun the bootstrap script:',
      '- Your GitHub user can access the private package.',
      '- The token is a classic GitHub PAT with read:packages and org SSO authorization.',
      `- The project .npmrc maps @kyndryl-cto to ${GITHUB_PACKAGES_REGISTRY}.`,
      '',
      'The bootstrap script never writes auth tokens to project files.',
    ].join('\n')
  );
}

export async function main(argv = process.argv.slice(2), options = {}) {
  const {
    env = process.env,
    platform = process.platform,
    spawnSyncImpl = spawnSync,
    log = console.log,
    error = console.error,
    promptToken = promptForToken,
    interactive = Boolean(defaultInput.isTTY && defaultOutput.isTTY),
  } = options;
  const args = parseArgs(argv);

  if (args.help) {
    log(renderHelp());
    return;
  }

  if (!SUPPORTED_HOSTS.has(args.host)) {
    throw new BootstrapInstallError(
      `Unsupported host "${args.host}". Supported hosts: ${Array.from(SUPPORTED_HOSTS).join(', ')}`
    );
  }

  const project = resolve(args.project);
  const packageSpec = `${PACKAGE_NAME}@${args.version}`;

  log(SHIDOKA_STUDIO_ASCII_ART);
  log(`Shidoka Studio bootstrap install`);
  log(`Project: ${project}`);
  log(`Package: ${packageSpec}`);
  log(`Host: ${args.host}`);

  validateProject(project);
  writeProjectNpmrc(project, log);

  const tokenEnv = findTokenEnv(env);
  let token = tokenEnv ? env[tokenEnv] : '';
  if (tokenEnv) {
    log(`Using GitHub Packages token from ${tokenEnv}.`);
  } else if (interactive) {
    token = await promptToken();
  }

  if (!token) {
    log('No token supplied to bootstrap; npm will use existing user, project, or CI auth.');
  }

  const tempUserconfig = createTempUserconfig(token);

  try {
    try {
      runChecked(
        `Installing ${packageSpec} from GitHub Packages...`,
        'npm',
        buildInstallArgs(packageSpec, args.save, tempUserconfig?.file),
        { cwd: project, platform, spawnSyncImpl, log }
      );
    } catch (installError) {
      printInstallFailureHelp(error);
      throw installError;
    }

    runChecked(
      `Configuring Shidoka Studio for ${args.host}...`,
      process.execPath,
      ['./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js', '--host', args.host, '--project', project],
      {
        cwd: project,
        platform,
        spawnSyncImpl,
        log,
        spawnEnv: { ...process.env, ...env, SHIDOKA_STUDIO_INSTALL_BANNER: '0' },
      }
    );

    log('\nShidoka Studio install complete. Reload your editor and start a fresh chat.');
  } finally {
    if (tempUserconfig) {
      rmSync(tempUserconfig.dir, { recursive: true, force: true });
    }
  }
}

export function isDirectRun(moduleUrl = import.meta.url, argv1 = process.argv[1]) {
  if (!argv1) return false;
  return pathToFileURL(resolve(argv1)).href === moduleUrl;
}

export async function runCli(argv = process.argv.slice(2)) {
  try {
    await main(argv);
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(error instanceof BootstrapInstallError ? error.exitCode : 1);
  }
}

if (isDirectRun(import.meta.url, process.argv[1])) {
  runCli();
}

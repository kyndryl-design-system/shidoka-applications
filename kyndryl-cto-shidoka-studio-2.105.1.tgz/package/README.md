```text
 ____  _     _     _       _             ____  _             _ _
/ ___|| |__ (_) __| | ___ | | ____ _    / ___|| |_ _   _  __| (_) ___
\___ \| '_ \| |/ _` |/ _ \| |/ / _` |   \___ \| __| | | |/ _` | |/ _ \
 ___) | | | | | (_| | (_) |   < (_| |    ___) | |_| |_| | (_| | | (_) |
|____/|_| |_|_|\__,_|\___/|_|\_\__,_|   |____/ \__|\__,_|\__,_|_|\___/
```

`Shidoka Studio` is a local stdio MCP server that gives Cursor, VS Code / GitHub Copilot, and Codex in VS Code the Shidoka design-system context needed to generate pages correctly.

Instead of asking the model to infer UI structure from local examples, Studio exposes bundled contracts for Shidoka components, page shells, header/navigation, workspace switchers, styling guidance, and audit rules.

## Who This Is For

- **App developers:** install `@kyndryl-cto/shidoka-studio` in the app repo where you want AI-assisted Shidoka page generation.
- **Studio maintainers:** edit this repo when changing the MCP server, installer, bundled context, generated artifacts, or release pipeline.

## Requirements

- Node.js 20+
- Cursor, VS Code + GitHub Copilot, or Codex in VS Code with MCP support
- Access to the private GitHub Packages package `@kyndryl-cto/shidoka-studio`

## Install In An App Repo

For the lowest-friction setup, copy the starter bootstrap script into the
consuming app repo as `scripts/install-shidoka-studio.mjs`, then run it from the
app repo root:

```bash
node scripts/install-shidoka-studio.mjs --host cursor
```

The bootstrap script writes safe project npm registry config, installs Studio
from private GitHub Packages, then runs the Studio installer. It never writes a
token to the repo. If no token environment variable is present, it prompts once
and uses that token only through a temporary npm config.

Use `--host vscode-copilot`, `--host codex`, or `--host both` for other host targets.
By default the bootstrap install is local-only (`--no-save`) so app CI does not
fetch the private MCP package. Add `--save-dev` if the repo should keep Studio in
`devDependencies`.

For unattended setup:

```bash
GITHUB_PACKAGES_TOKEN=YOUR_GITHUB_PAT node scripts/install-shidoka-studio.mjs --host cursor
```

Alternatively, configure GitHub Packages once per machine in your user-level
`~/.npmrc`:

```bash
@kyndryl-cto:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=YOUR_GITHUB_PAT
```

Then use the local-only install flow from the consuming app repo root:

```bash
npm install --no-save --package-lock=false @kyndryl-cto/shidoka-studio@latest
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host cursor
```

The installer writes a managed project `.npmrc` block with the `@kyndryl-cto`
GitHub Packages registry mapping for future local/CI installs. It does not write
tokens; keep credentials in user-level `~/.npmrc`, CI secrets, or Docker build
configuration. The first package install still needs npm auth configured before
the installer can run.

The default installer target is Cursor. Use another host when needed:

```bash
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host vscode-copilot
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host codex
node ./node_modules/@kyndryl-cto/shidoka-studio/bin/install.js --host both
```

After installation, reload the host editor, enable/trust the `shidoka-studio` MCP server if prompted, and start a fresh chat.

To check or update the installed Studio package later:

```bash
npx shidoka-studio-version
npx shidoka-studio-update --host cursor
```

`shidoka-studio-update` reinstalls `@kyndryl-cto/shidoka-studio@latest` from
GitHub Packages, refreshes the generated host configuration, and keeps auth
tokens out of project files. Reload the host editor after updating.

To verify the generated host config can launch the server:

```bash
npx shidoka-studio-doctor --host cursor
npx shidoka-studio-doctor --host vscode-copilot
npx shidoka-studio-doctor --host codex
npx shidoka-studio-doctor --host both
```

If the server appears configured but not discoverable/callable in this session, reload the host editor, enable/trust the `shidoka-studio` MCP server if prompted, and start a fresh chat before running the matching doctor command again.

**Important:** `shidoka-studio-install` writes project configuration and exits. Do not use it as the MCP runtime command. Runtime config should launch the installed server or generated launcher script.

## Using It

Once configured, ask your coding agent for focused Shidoka work, for example:

- `Build a Settings page with a Shidoka shell, page title, and form.`
- `Create an Orders page with a toolbar and data table using Shidoka components.`
- `Refine this existing Shidoka page so the header matches the canonical layout.`

For best results, keep each prompt to one page or one focused refinement. Studio improves design-system accuracy, but normal model limits still apply when a prompt combines many pages, exceptions, and transformations.

## Repo Map

- `src/content/`, `src/content/archetypes/`, and `src/content/shared-foundation/` are authored context and contract inputs.
- `src/server/` and `src/cli/` contain the MCP server and installer source.
- `src/scripts/` contains generation, packaging, and validation scripts.
- `examples/` contains authored host-adapter examples.
- `src/generated/`, `context/`, `bin/`, top-level `shared-foundation/`, and `styles/` are generated or packaged mirrors. Do not hand-edit them.

For the full maintainer map, see `docs/REPO-LAYOUT-AND-EDIT-BOUNDARIES.md`.

## Local Development

If you are working on Studio itself, start with `docs/LOCAL-DEVELOPMENT.md` for setup, common commands, validation rings, and sideload guidance.

## Docs

If you installed the package in an app repo, start with the shipped docs under `node_modules/@kyndryl-cto/shidoka-studio/context/`:

- `context/boilerplate-first-time-setup.md` - first-time app setup
- `context/consuming-app-setup-and-alignment.md` - host setup, app alignment, and troubleshooting
- `context/packaging-for-consumers.md` - packaging and distribution

If you are browsing this source repo, maintainer docs live under `docs/`. Start with:

- `docs/LOCAL-DEVELOPMENT.md`
- `docs/MCP_FEATURES.md`
- `docs/PACKAGING-FOR-CONSUMERS.md`
- `docs/REPO-LAYOUT-AND-EDIT-BOUNDARIES.md`

## Publishing Note

Do not publish this package to the public npm registry without explicit approval. The approved internal distribution path is the private GitHub Packages package `@kyndryl-cto/shidoka-studio`, with the private GitHub release `.tgz` asset retained as a fallback.
